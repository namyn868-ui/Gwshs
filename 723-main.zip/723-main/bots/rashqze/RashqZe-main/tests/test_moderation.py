import importlib
import asyncio
import os
import sys
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import ANY, AsyncMock, Mock, patch

from pyrogram import StopPropagation, enums
from pyrogram.enums import ChatType
from pyrogram.errors import MessageNotModified
from pyrogram.handlers import CallbackQueryHandler, MessageHandler


BOT_ROOT = Path(__file__).resolve().parents[1]
_original_cwd = Path.cwd()
_test_directory = tempfile.TemporaryDirectory(prefix="rashqze-moderation-tests-")
_original_environment = {
    key: os.environ.get(key)
    for key in ("TG_BOT_TOKEN", "APP_ID", "API_HASH", "OWNER_ID")
}

# The plugins open relative SQLite paths while importing. Keep those files out
# of the bot's working directory and avoid needing real Telegram credentials.
os.chdir(_test_directory.name)
Path("RashqMody").symlink_to(BOT_ROOT / "RashqMody", target_is_directory=True)
os.environ.update(
    {
        "TG_BOT_TOKEN": "123456:TEST_ONLY",
        "APP_ID": "1",
        "API_HASH": "0" * 32,
        "OWNER_ID": "999999999",
    }
)
sys.path.insert(0, str(BOT_ROOT))

moderation = importlib.import_module("RashqMody.moderation")
bot_controls = importlib.import_module("RashqMody.bot_controls")
start_msg = importlib.import_module("RashqMody.start_msg")
start_with_code = importlib.import_module("RashqMody.start_with_code")
member = importlib.import_module("RashqMody.member")
engagement = importlib.import_module("RashqMody.engagement")
service_switches = importlib.import_module("RashqMody.service_switches")
points_core = importlib.import_module("RashqMody.points_core")
user_registration = importlib.import_module("RashqMody.user_registration")
adminss = importlib.import_module("RashqMody.adminss")
change_prices = importlib.import_module("RashqMody.change_prices")
clitrans = importlib.import_module("RashqMody.clitrans")
info_requests = importlib.import_module("RashqMody.info_requests")
cliacc = importlib.import_module("RashqMody.cliacc")
order_status = importlib.import_module("RashqMody.order_status")

_imported_databases = []
for _module_name, _module in tuple(sys.modules.items()):
    if not _module_name.startswith("RashqMody."):
        continue
    for _value in vars(_module).values():
        if type(_value).__module__ == "kvsqlite.sync.client" and hasattr(
            _value, "close"
        ):
            _imported_databases.append(_value)

# kvsqlite opens its relative SQLite path on a worker thread. Initialize each
# connection before restoring the caller's working directory.
for _database in {id(database): database for database in _imported_databases}.values():
    try:
        _database.keys()
    except Exception:
        pass

os.chdir(_original_cwd)
for _key, _value in _original_environment.items():
    if _value is None:
        os.environ.pop(_key, None)
    else:
        os.environ[_key] = _value


class MemoryDatabase:
    def __init__(self):
        self.values = {}

    def get(self, key):
        return self.values.get(key)

    def set(self, key, value):
        self.values[key] = value

    def exists(self, key):
        return key in self.values

    def delete(self, key):
        self.values.pop(key, None)

    def keys(self):
        return [(key,) for key in self.values]


def _registered_handler(function, handler_type):
    for handler, group in getattr(function, "handlers", []):
        if isinstance(handler, handler_type):
            return group, handler
    raise AssertionError(
        f"{function.__module__}.{function.__name__} has no "
        f"{handler_type.__name__} registration"
    )


async def _dispatch_registered(handlers, client, update):
    """Run callbacks by Pyrogram group order and honor StopPropagation."""
    handled = []
    for _group, callback in sorted(handlers, key=lambda entry: entry[0]):
        try:
            await callback(client, update)
        except StopPropagation:
            return handled, True
        handled.append(callback)
    return handled, False


class ModerationRegressionTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def tearDownClass(cls):
        for database in _imported_databases:
            try:
                database.close()
            except Exception:
                pass
        _test_directory.cleanup()
        super().tearDownClass()

    def setUp(self):
        self.db = MemoryDatabase()
        moderation.db = self.db
        bot_controls.db = self.db
        start_msg.db = self.db
        start_with_code.db = self.db
        member.db = self.db
        engagement.db = self.db
        service_switches.db = self.db
        user_registration.db = self.db
        adminss.db = self.db
        change_prices.db = self.db
        clitrans.db = self.db
        info_requests.db = self.db
        cliacc.db = self.db
        order_status.db = self.db
        self.previous_database_path = points_core.DATABASE_PATH
        points_core.DATABASE_PATH = Path(_test_directory.name) / (
            f"test-db-{id(self)}.sqlite"
        )
        self.client = SimpleNamespace(send_message=AsyncMock())

    def tearDown(self):
        points_core.DATABASE_PATH = self.previous_database_path

    def _set_transaction_value(self, key, value):
        connection = points_core.open_transaction()
        try:
            points_core.write_value(connection, key, value)
            connection.commit()
        finally:
            connection.close()

    def _get_transaction_value(self, key):
        connection = points_core.open_transaction()
        try:
            return points_core.read_value(connection, key)
        finally:
            connection.rollback()
            connection.close()

    def _user(self, user_id):
        return SimpleNamespace(id=user_id, mention=f"<user {user_id}>", username=None)

    def _message(self, user_id, text):
        return SimpleNamespace(
            from_user=self._user(user_id),
            chat=SimpleNamespace(type=ChatType.PRIVATE),
            text=text,
            reply_text=AsyncMock(),
        )

    def _query(self, user_id, data, *, private=True):
        message = (
            SimpleNamespace(chat=SimpleNamespace(type=ChatType.PRIVATE))
            if private
            else None
        )
        return SimpleNamespace(
            from_user=self._user(user_id),
            message=message,
            data=data,
            answer=AsyncMock(),
            edit_message_text=AsyncMock(),
            edit_message_reply_markup=AsyncMock(),
        )

    async def _dispatch_start(self, message, start_handler):
        guard_group, _ = _registered_handler(
            moderation.enforce_user_bans_and_track_activity, MessageHandler
        )
        start_group, _ = _registered_handler(start_handler, MessageHandler)
        pause_group, _ = _registered_handler(
            bot_controls.pause_user_messages, MessageHandler
        )
        self.assertLess(
            guard_group,
            pause_group,
            "The ban guard must run before the general message gate.",
        )
        self.assertLess(
            guard_group,
            start_group,
            "The ban guard must run before every /start entry point.",
        )
        return await _dispatch_registered(
            [
                (guard_group, moderation.enforce_user_bans_and_track_activity),
                (start_group, start_handler),
            ],
            self.client,
            message,
        )

    async def test_banned_user_cannot_use_start_or_referral_start(self):
        user_id = 101
        self.db.set("ban_list", [user_id])
        self.db.set(f"user_{user_id}", {"coins": 2})

        for text, start_handler in (
            ("/start", start_msg.startm),
            ("/start 202", start_with_code.sm),
        ):
            with self.subTest(command=text):
                message = self._message(user_id, text)
                invoked_start = AsyncMock(wraps=start_handler)
                start_group, _ = _registered_handler(start_handler, MessageHandler)
                guard_group, _ = _registered_handler(
                    moderation.enforce_user_bans_and_track_activity,
                    MessageHandler,
                )
                self.assertLess(guard_group, start_group)
                handled, stopped = await _dispatch_registered(
                    [
                        (guard_group, moderation.enforce_user_bans_and_track_activity),
                        (start_group, invoked_start),
                    ],
                    self.client,
                    message,
                )
                self.assertTrue(stopped)
                self.assertEqual(handled, [])
                invoked_start.assert_not_awaited()
                message.reply_text.assert_awaited_once_with(moderation.BAN_NOTICE)

    async def test_banned_user_cannot_trigger_old_or_new_callbacks(self):
        user_id = 202
        self.db.set("ban_list", [user_id])
        callback = self._query(user_id, "member_confirm:old-button-token")
        invoked_button = AsyncMock()

        guard_group, _ = _registered_handler(
            moderation.enforce_user_bans_and_track_callback_activity,
            CallbackQueryHandler,
        )
        pause_group, _ = _registered_handler(
            bot_controls.pause_user_callbacks, CallbackQueryHandler
        )
        self.assertLess(
            guard_group,
            pause_group,
            "The ban guard must run before the general callback gate.",
        )
        self.assertLess(
            guard_group,
            0,
            "The callback ban guard must precede ordinary button handlers.",
        )
        handled, stopped = await _dispatch_registered(
            [
                (guard_group, moderation.enforce_user_bans_and_track_callback_activity),
                (0, invoked_button),
            ],
            self.client,
            callback,
        )

        self.assertTrue(stopped)
        invoked_button.assert_not_awaited()
        callback.answer.assert_awaited_once_with(moderation.BAN_NOTICE, show_alert=True)

    async def test_unbanning_restores_start_access(self):
        user_id = 303
        self.db.set("ban_list", [user_id])
        self.db.set(f"user_{user_id}", {"coins": 2})

        success, result = await moderation._change_ban(self.client, user_id, False)
        self.assertTrue(success, result)
        self.assertFalse(moderation.is_user_banned(user_id))

        message = self._message(user_id, "/start")
        with (
            patch.object(start_msg, "app", self.client),
            patch.object(start_msg, "is_active_agent", return_value=False),
            patch.object(start_msg, "get_template", return_value="[id]"),
            patch.object(start_msg, "render_template", return_value="Welcome back"),
            patch.object(start_msg, "get_bot_channel_url", return_value=None),
        ):
            handled, stopped = await self._dispatch_start(message, start_msg.startm)

        self.assertFalse(stopped)
        self.assertIn(start_msg.startm, handled)
        self.client.send_message.assert_any_await(
            user_id,
            "Welcome back",
            reply_markup=ANY,
            parse_mode=ANY,
        )

    async def test_only_admin_can_change_bans(self):
        regular_user_id = 404
        self.db.set("admin_list", [900])
        query = self._query(regular_user_id, f"moderation_ban:{regular_user_id}")

        await moderation.change_user_ban_from_info(self.client, query)

        query.answer.assert_awaited_once_with(
            "هذا الإجراء مخصص للأدمن فقط.", show_alert=True
        )
        self.assertFalse(moderation.is_user_banned(regular_user_id))

        self.db.set("admin_list", [900])
        admin_query = self._query(900, f"moderation_ban:{regular_user_id}")
        await moderation.change_user_ban_from_info(self.client, admin_query)
        self.assertTrue(moderation.is_user_banned(regular_user_id))

    async def test_admin_account_cannot_be_banned(self):
        admin_id = 900
        self.db.set("admin_list", [admin_id])

        success, result = await moderation._change_ban(self.client, admin_id, True)

        self.assertFalse(success)
        self.assertEqual(
            result,
            "لا يمكن حظر حساب أدمن. أزل صلاحياته أولاً إذا لزم الأمر.",
        )
        self.assertFalse(moderation.is_user_banned(admin_id))

    async def test_admin_user_and_statistics_sections_render_working_buttons(self):
        self.db.set("admin_list", [900])
        self.db.set("user_101", {"coins": 4.5})
        self.db.set("user_101_buys", 3)
        self.db.set(f"user_activity_day_101", moderation._today())
        self.db.set("agent_registry", {"501": {"wallet": "2"}})

        dashboard_callbacks = [
            button.callback_data
            for row in bot_controls.admin_dashboard_keyboard().inline_keyboard
            for button in row
        ]
        self.assertIn("admin_users", dashboard_callbacks)
        self.assertIn("stats", dashboard_callbacks)

        users_query = self._query(900, "admin_users")
        await moderation.open_user_admin_menu(self.client, users_query)
        users_query.edit_message_text.assert_awaited_once()
        self.assertEqual(
            users_query.edit_message_text.await_args.kwargs["parse_mode"],
            enums.ParseMode.HTML,
        )
        users_markup = users_query.edit_message_text.await_args.kwargs["reply_markup"]
        user_callbacks = [
            button.callback_data
            for row in users_markup.inline_keyboard
            for button in row
        ]
        self.assertEqual(
            user_callbacks,
            ["ban_mes", "unban_mes", "stats", "moderation_banned_list", "back_admin"],
        )

        stats_query = self._query(900, "stats")
        await moderation.show_bot_statistics(self.client, stats_query)
        stats_query.edit_message_text.assert_awaited_once()
        stats_text = stats_query.edit_message_text.await_args.args[0]
        self.assertIn("إجمالي المستخدمين: <b>1</b>", stats_text)
        self.assertIn("المستخدمون النشطون اليوم: <b>1</b>", stats_text)
        self.assertIn("إجمالي عمليات الخدمات الناجحة: <b>3</b>", stats_text)
        self.assertIn("إجمالي النقاط في النظام: <b>6.5</b>", stats_text)
        self.assertEqual(
            stats_query.edit_message_text.await_args.kwargs["parse_mode"],
            enums.ParseMode.HTML,
        )

    async def test_non_admin_cannot_open_statistics(self):
        self.db.set("admin_list", [900])
        query = self._query(901, "stats")

        await moderation.show_bot_statistics(self.client, query)

        query.answer.assert_awaited_once_with(
            "هذا القسم مخصص للأدمن فقط.", show_alert=True
        )
        query.edit_message_text.assert_not_awaited()

    async def test_member_api_timeout_keeps_balance_and_reports_temporary_error(self):
        user_id = 515
        token = "abc123abc123abcd"
        self.db.set("set_domain", "provider.example")
        self.db.set("api_key", "test-only")
        self.db.set("member_service_id", 77)
        self.db.set("member_service_enabled", True)
        self.db.set(f"user_{user_id}", {"coins": 5})
        self.db.set(
            f"member_pending_{user_id}",
            {
                "token": token,
                "user_id": user_id,
                "channel_username": "testchannel",
                "quantity": 1000,
                "cost": "1",
                "created_at": __import__("time").time(),
                "status": "pending",
            },
        )
        query = self._query(user_id, f"member_confirm:{token}")
        query.from_user.username = "testuser"

        with patch.object(member.requests, "get", side_effect=TimeoutError):
            await member.confirm_member_order(self.client, query)

        query.answer.assert_awaited_once()
        self.assertIn("لا تعاود الإرسال", query.answer.await_args.args[0])
        self.assertEqual(self.db.get(f"user_{user_id}")["coins"], 5)
        self.assertEqual(
            self.db.get(f"member_pending_{user_id}")["status"],
            "unknown",
        )
        self.assertEqual(self.db.get(f"user_{user_id}_buys"), None)

        retry_query = self._query(user_id, f"member_confirm:{token}")
        with patch.object(member.requests, "get") as provider_request:
            await member.confirm_member_order(self.client, retry_query)
        provider_request.assert_not_called()
        retry_query.answer.assert_awaited_once()

    async def test_engagement_api_timeout_does_not_charge_user(self):
        user_id = 516
        self.db.set("set_domain", "provider.example")
        self.db.set("api_key", "test-only")
        self.db.set(f"user_{user_id}", {"coins": 5})
        self.db.set(
            engagement.CATALOG_KEY,
            [
                {
                    "id": 1,
                    "name": "مشاهدات اختبارية",
                    "category": "views",
                    "provider_service_id": 77,
                    "price_per_1000": "1",
                    "min_quantity": 1,
                    "max_quantity": 5000,
                    "enabled": True,
                }
            ],
        )
        quantity = SimpleNamespace(text="1000", reply=AsyncMock())
        link = SimpleNamespace(text="https://t.me/testchannel/12", reply=AsyncMock())
        confirmation = SimpleNamespace(text="/ok", reply=AsyncMock())
        query = self._query(user_id, "engage_service:1")
        query.from_user.username = "testuser"

        with (
            patch.object(engagement, "clear_section_message", new=AsyncMock()),
            patch.object(
                engagement,
                "ask_with_back",
                new=AsyncMock(side_effect=[quantity, link, confirmation]),
            ),
            patch.object(engagement.requests, "get", side_effect=TimeoutError),
        ):
            await engagement.order_engagement_service(self.client, query)

        confirmation.reply.assert_awaited_once()
        self.assertIn("لا تعاود الإرسال", confirmation.reply.await_args.args[0])
        self.assertEqual(self.db.get(f"user_{user_id}")["coins"], 5)
        self.assertEqual(self.db.get(f"user_{user_id}_buys"), None)
        self.assertEqual(
            self.db.get(f"engagement_pending_{user_id}")["status"],
            "unknown",
        )

        retry_query = self._query(user_id, "engage_service:1")
        with (
            patch.object(engagement, "ask_with_back", new=AsyncMock()) as ask,
            patch.object(engagement.requests, "get") as provider_request,
        ):
            await engagement.order_engagement_service(self.client, retry_query)
        ask.assert_not_awaited()
        provider_request.assert_not_called()
        retry_query.answer.assert_awaited_once()

    async def test_service_switch_panel_shows_each_service_state(self):
        self.db.set("admin_list", [900])
        self.db.set("main_service_enabled_members", False)

        query = self._query(900, "service_switches")
        await service_switches.open_service_switches(self.client, query)

        query.answer.assert_awaited_once_with()
        query.edit_message_text.assert_awaited_once()
        self.assertEqual(
            query.edit_message_text.await_args.kwargs["parse_mode"],
            enums.ParseMode.HTML,
        )
        keyboard = query.edit_message_text.await_args.kwargs["reply_markup"]
        buttons = {
            button.callback_data: button.text
            for row in keyboard.inline_keyboard
            for button in row
        }
        self.assertIn("service_toggle:members", buttons)
        self.assertIn("🔴", buttons["service_toggle:members"])
        self.assertIn("🟢", buttons["service_toggle:engagement"])
        self.assertEqual(
            buttons["service_toggle:members"].removeprefix("🔴 "),
            service_switches.SERVICES["members"]["label"],
        )

    async def test_admin_can_toggle_service_and_user_is_blocked_immediately(self):
        admin_id = 900
        user_id = 901
        self.db.set("admin_list", [admin_id])
        toggle_query = self._query(admin_id, "service_toggle:members")

        await service_switches.toggle_service(self.client, toggle_query)

        self.assertFalse(self.db.get("main_service_enabled_members"))
        toggle_query.answer.assert_awaited_once()
        self.assertIn("تم تعطيل", toggle_query.answer.await_args.args[0])
        toggle_query.edit_message_text.assert_awaited_once()
        refreshed_keyboard = toggle_query.edit_message_text.await_args.kwargs[
            "reply_markup"
        ]
        refreshed_buttons = [
            button.text
            for row in refreshed_keyboard.inline_keyboard
            for button in row
        ]
        self.assertTrue(any("🔴" in text for text in refreshed_buttons))

        user_query = self._query(user_id, "member_confirm:abc123")
        with self.assertRaises(StopPropagation):
            await service_switches.enforce_service_switches(self.client, user_query)

        user_query.answer.assert_awaited_once_with(
            service_switches.MAINTENANCE_NOTICE,
            show_alert=True,
        )

        self.db.set("main_service_enabled_agents", False)
        agent_query = self._query(user_id, "agent_wallet")
        with self.assertRaises(StopPropagation):
            await service_switches.enforce_service_switches(self.client, agent_query)
        agent_query.answer.assert_awaited_once_with(
            service_switches.MAINTENANCE_NOTICE,
            show_alert=True,
        )

    async def test_admin_and_enabled_services_are_not_blocked(self):
        self.db.set("admin_list", [900])
        self.db.set("main_service_enabled_members", False)
        admin_query = self._query(900, "member")
        await service_switches.enforce_service_switches(self.client, admin_query)
        admin_query.answer.assert_not_awaited()

        self.db.set("main_service_enabled_members", True)
        user_query = self._query(901, "member")
        await service_switches.enforce_service_switches(self.client, user_query)
        user_query.answer.assert_not_awaited()

    async def test_refreshing_service_panel_unchanged_is_a_safe_noop(self):
        query = self._query(900, "service_switches")
        query.edit_message_text.side_effect = MessageNotModified()

        await service_switches._show_panel(query)

        query.edit_message_text.assert_awaited_once()

    async def test_admin_permissions_are_read_fresh_after_changes(self):
        self.db.set("admin_list", [900])
        self.assertTrue(adminss._is_admin(900))

        self.db.set("admin_list", [901])

        self.assertFalse(adminss._is_admin(900))
        self.assertTrue(adminss._is_admin(901))

    async def test_non_admin_cannot_trigger_broadcast_or_change_provider_config(self):
        self.db.set("admin_list", [900])
        query = self._query(901, "brods")

        with (
            patch.object(adminss, "clear_section_message", new=AsyncMock()) as clear,
            patch.object(adminss, "ask_with_back", new=AsyncMock()) as ask,
        ):
            await adminss.brod_ss(self.client, query)

        query.answer.assert_awaited_once_with(
            "هذا القسم مخصص للأدمن فقط.", show_alert=True
        )
        clear.assert_not_awaited()
        ask.assert_not_awaited()

        config_query = self._query(901, "set_api")
        with (
            patch.object(change_prices, "clear_section_message", new=AsyncMock()) as clear,
            patch.object(change_prices, "ask_with_back", new=AsyncMock()) as ask,
        ):
            await change_prices.setapi(self.client, config_query)
        config_query.answer.assert_awaited_once_with(
            "هذا الإجراء مخصص للأدمن فقط.", show_alert=True
        )
        clear.assert_not_awaited()
        ask.assert_not_awaited()

    async def test_admin_balance_adjustments_validate_amount_and_prevent_negative_balance(self):
        self._set_transaction_value("user_510", {"coins": 1.5})

        with self.assertRaises(ValueError):
            adminss._parse_points("-1")
        with self.assertRaises(ValueError):
            adminss._parse_points("NaN")
        with self.assertRaises(ValueError):
            adminss._parse_points("Infinity")

        success, updated = await adminss._adjust_user_points(
            510,
            adminss._parse_points("0.25"),
            True,
        )
        self.assertTrue(success)
        self.assertEqual(updated, Decimal("1.75"))

        success, error = await adminss._adjust_user_points(
            510,
            adminss._parse_points("2"),
            False,
        )
        self.assertFalse(success)
        self.assertIn("أقل", error)
        self.assertEqual(
            self._get_transaction_value("user_510")["coins"],
            1.75,
        )

    async def test_transfers_are_atomic_and_cannot_double_spend(self):
        self._set_transaction_value("user_700", {"coins": 3})
        self._set_transaction_value("user_701", {"coins": 0})
        self._set_transaction_value("user_702", {"coins": 0})

        with self.assertRaises(ValueError):
            clitrans._parse_transfer_amount("NaN")
        with self.assertRaises(ValueError):
            clitrans._parse_transfer_amount("-1")

        results = await asyncio.gather(
            clitrans._apply_transfer(700, 701, Decimal("2")),
            clitrans._apply_transfer(700, 702, Decimal("2")),
        )

        self.assertEqual(sum(1 for success, _ in results if success), 1)
        self.assertEqual(self._get_transaction_value("user_700")["coins"], 1.0)
        self.assertEqual(
            self._get_transaction_value("user_701")["coins"]
            + self._get_transaction_value("user_702")["coins"],
            2.0,
        )
        self.assertEqual(self._get_transaction_value("user_700_trans"), 1)

    async def test_referral_registration_rejects_self_reward_and_is_idempotent(self):
        self._set_transaction_value(
            "user_800",
            {"coins": 1.0, "users": [], "id": 800},
        )
        self._set_transaction_value("invite_price", 0.1)

        created, reward, _ = await user_registration.register_user(801, 801)
        self.assertTrue(created)
        self.assertEqual(reward, Decimal("0"))
        self.assertEqual(self._get_transaction_value("user_801")["coins"], 0.2)

        created, reward, balance = await user_registration.register_user(802, 800)
        self.assertTrue(created)
        self.assertEqual(reward, Decimal("0.1"))
        self.assertEqual(balance, Decimal("1.1"))
        created_again, reward_again, _ = await user_registration.register_user(802, 800)

        self.assertFalse(created_again)
        self.assertEqual(reward_again, Decimal("0"))
        self.assertEqual(self._get_transaction_value("user_800")["coins"], 1.1)
        self.assertEqual(self._get_transaction_value("user_800")["users"], [802])

    async def test_order_status_lookup_is_limited_to_the_order_owner(self):
        self.db.set("set_domain", "provider.example")
        self.db.set("api_key", "test-only")
        self.db.set(
            info_requests.TRACKED_ORDERS_KEY
            if hasattr(info_requests, "TRACKED_ORDERS_KEY")
            else "tracked_provider_orders",
            [{"order_id": "12345", "user_id": 902, "service_name": "test"}],
        )
        query = self._query(901, "id_requests")
        ask = SimpleNamespace(text="12345", reply=AsyncMock())

        with (
            patch.object(info_requests, "clear_section_message", new=AsyncMock()),
            patch.object(info_requests, "ask_with_back", new=AsyncMock(return_value=ask)),
            patch.object(info_requests.requests, "get") as provider_request,
        ):
            await info_requests.dailygiftt(self.client, query)

        provider_request.assert_not_called()
        ask.reply.assert_awaited_once()
        self.assertIn("طلبات حسابك", ask.reply.await_args.args[0])

    async def test_order_owner_status_lookup_uses_a_local_mock_only(self):
        self.db.set("set_domain", "provider.example")
        self.db.set("api_key", "test-only")
        self.db.set(
            "tracked_provider_orders",
            [{"order_id": "12345", "user_id": 901, "service_name": "test"}],
        )
        query = self._query(901, "id_requests")
        ask = SimpleNamespace(text="12345", reply=AsyncMock())
        response = SimpleNamespace(
            raise_for_status=Mock(),
            json=Mock(return_value={"status": "completed", "quantity": 10}),
        )

        with (
            patch.object(info_requests, "clear_section_message", new=AsyncMock()),
            patch.object(info_requests, "ask_with_back", new=AsyncMock(return_value=ask)),
            patch.object(info_requests.requests, "get", return_value=response) as provider_request,
        ):
            await info_requests.dailygiftt(self.client, query)

        provider_request.assert_called_once()
        self.assertEqual(provider_request.call_args.kwargs["timeout"], 20)
        self.assertIn("مكتمل", ask.reply.await_args.args[0])

    async def test_id_command_matches_its_advertised_behavior(self):
        message = SimpleNamespace(
            from_user=self._user(912),
            reply_text=AsyncMock(),
        )

        await cliacc.send_user_id(self.client, message)

        message.reply_text.assert_awaited_once_with("ايدي حسابك هو: `912`")

    async def test_provider_settings_reject_unsafe_values_and_mask_api_key(self):
        self.assertEqual(
            change_prices._normalize_provider_domain("https://provider.example"),
            "provider.example",
        )
        for value in (
            "http://provider.example",
            "provider.example/path",
            "provider.example?redirect=elsewhere",
        ):
            with self.subTest(domain=value), self.assertRaises(ValueError):
                change_prices._normalize_provider_domain(value)
        with self.assertRaises(ValueError):
            change_prices._parse_positive_decimal("Infinity")

        self.db.set("admin_list", [900])
        self.db.set("api_key", "old-provider-secret-value")
        query = self._query(900, "set_api")
        ask = SimpleNamespace(text="new-test-value", reply=AsyncMock())

        with (
            patch.object(change_prices, "clear_section_message", new=AsyncMock()),
            patch.object(change_prices, "ask_with_back", new=AsyncMock(return_value=ask)) as prompt,
        ):
            await change_prices.setapi(self.client, query)

        self.assertNotIn("old-provider-secret-value", prompt.await_args.args[2])
        self.assertEqual(self.db.get("api_key"), "new-test-value")


if __name__ == "__main__":
    unittest.main()
