import os


def _required(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


class Config(object):
    TG_BOT_TOKEN = _required("TG_BOT_TOKEN")
    APP_ID = int(_required("APP_ID"))
    API_HASH = _required("API_HASH")
    OWNER_ID = int(_required("OWNER_ID"))
