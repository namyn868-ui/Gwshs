import asyncio
import os
from contextlib import suppress
from pathlib import Path

os.umask(0o077)
_database_path = Path(__file__).with_name("data.sqlite")
if _database_path.is_symlink():
  raise RuntimeError("The bot database path must not be a symbolic link.")
if _database_path.exists():
  os.chmod(_database_path, 0o600)

from config import Config
import pyrogram , pyromod
from pyromod import listen
from pyrogram import Client, filters, enums, idle
from kvsqlite.sync import Client as dt
from RashqMody.order_status import monitor_provider_orders
p = dict(root='RashqMody')
tok = Config.TG_BOT_TOKEN
db = dt("data.sqlite", 'fuck')
admins = db.get("admin_list") or []
admins = [
    admin_id for admin_id in admins
    if admin_id != Config.APP_ID
]
if Config.OWNER_ID not in admins:
  admins.insert(0, Config.OWNER_ID)
db.set("admin_list", admins)
if db.get('ban_list') is None:
  db.set('ban_list', [])
if not db.get('force'):
  db.set('force', ['ui_xb'])
if db.get("force") == ["ui_xb"]:
  db.set("force", [])
x = Client(name='RashqZe', api_id=Config.APP_ID, api_hash=Config.API_HASH, bot_token=tok, workers=20, plugins=p, parse_mode=enums.ParseMode.DEFAULT)

async def main():
  await x.start()
  status_task = asyncio.create_task(monitor_provider_orders(x))
  try:
    await idle()
  finally:
    status_task.cancel()
    with suppress(asyncio.CancelledError):
      await status_task
    await x.stop()


x.run(main())
