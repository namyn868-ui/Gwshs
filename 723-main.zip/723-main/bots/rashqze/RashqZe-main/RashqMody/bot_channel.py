import re
from html import escape
from urllib.parse import urlparse

from kvsqlite.sync import Client as Database
from pyrogram import Client as app, enums, filters
from pyrogram.types import (
    InlineKeyboardButton as btn,
    InlineKeyboardMarkup as mk,
)

from .navigation import ask_with_back

db = Database("data.sqlite", "fuck")
BOT_CHANNEL_KEY = "bot_channel"


def normalize_channel_url(value):
    raw = (value or "").strip()
    if not raw:
        return None

    if re.fullmatch(r"@?[A-Za-z][A-Za-z0-9_]{4,31}", raw):
        username = raw.removeprefix("@")
        return f"https://t.me/{username}"

    if raw.startswith("t.me/") or raw.startswith("telegram.me/"):
        raw = f"https://{raw}"
    elif raw.startswith("@"):
        return None

    parsed = urlparse(raw)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or host not in {"t.me", "telegram.me"}:
        return None
    if parsed.query or parsed.fragment:
        return None

    path = parsed.path.strip("/")
    if re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{4,31}", path):
        return f"https://t.me/{path}"
    if re.fullmatch(r"\+[A-Za-z0-9_-]{8,}", path):
        return f"https://t.me/{path}"
    if re.fullmatch(r"joinchat/[A-Za-z0-9_-]{8,}", path):
        return f"https://t.me/{path}"
    return None


def get_bot_channel_url():
    return normalize_channel_url(db.get(BOT_CHANNEL_KEY))


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def _manage_keyboard(has_channel):
    rows = [[btn("إضافة أو تغيير القناة", callback_data="bot_channel_set")]]
    if has_channel:
        rows.append([btn("حذف القناة", callback_data="bot_channel_delete")])
    rows.append([btn("رجوع للإعدادات", callback_data="setting_bot")])
    return mk(rows)


async def _show_manage_panel(client, chat_id):
    channel_url = get_bot_channel_url()
    status = f"<code>{escape(channel_url)}</code>" if channel_url else "غير محددة"
    await client.send_message(
        chat_id,
        f"إدارة قناة البوت\n\nالقناة الحالية: {status}",
        reply_markup=_manage_keyboard(bool(channel_url)),
        parse_mode=enums.ParseMode.HTML,
    )


@app.on_callback_query(filters.regex(r"^bot_channel_manage$"))
async def manage_bot_channel(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    channel_url = get_bot_channel_url()
    status = f"<code>{escape(channel_url)}</code>" if channel_url else "غير محددة"
    await query.edit_message_text(
        f"إدارة قناة البوت\n\nالقناة الحالية: {status}",
        reply_markup=_manage_keyboard(bool(channel_url)),
        parse_mode=enums.ParseMode.HTML,
    )


@app.on_callback_query(filters.regex(r"^bot_channel_set$"))
async def set_bot_channel(client, query):
    user_id = query.from_user.id
    if not _is_admin(user_id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    await query.answer()
    if query.message is not None:
        await query.message.delete()

    answer = await ask_with_back(
        client,
        user_id,
        "أرسل يوزر القناة مثل @mychannel أو رابط t.me، أو اضغط «رجوع».",
        "bot_channel_manage",
        filters=filters.user(user_id),
    )
    if not answer or not answer.text:
        return

    raw_value = answer.text.strip()
    if raw_value.lower() in {"/cancel", "رجوع"}:
        await answer.reply(
            "تم الرجوع دون تغيير القناة.",
            reply_markup=mk(
                [[btn("رجوع إلى إدارة القناة", callback_data="bot_channel_manage")]]
            ),
        )
        return

    channel_url = normalize_channel_url(raw_value)
    if not channel_url:
        await answer.reply(
            "الرابط غير صالح. أرسل يوزر قناة عام أو رابط قناة t.me صالح.",
            reply_markup=mk(
                [[btn("رجوع إلى إدارة القناة", callback_data="bot_channel_manage")]]
            ),
        )
        await _show_manage_panel(client, user_id)
        return

    db.set(BOT_CHANNEL_KEY, channel_url)
    await answer.reply(
        "تم حفظ قناة البوت بنجاح.",
        reply_markup=mk(
            [[btn("رجوع إلى إدارة القناة", callback_data="bot_channel_manage")]]
        ),
    )
    await _show_manage_panel(client, user_id)


@app.on_callback_query(filters.regex(r"^bot_channel_delete$"))
async def delete_bot_channel(client, query):
    user_id = query.from_user.id
    if not _is_admin(user_id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    db.set(BOT_CHANNEL_KEY, None)
    await query.answer("تم حذف قناة البوت.")
    await query.edit_message_text(
        "إدارة قناة البوت\n\nالقناة الحالية: غير محددة",
        reply_markup=_manage_keyboard(False),
        parse_mode=enums.ParseMode.HTML,
    )


@app.on_callback_query(filters.regex(r"^bot_channel_missing$"))
async def missing_bot_channel(client, query):
    await query.answer("لم يحدد الأدمن قناة البوت بعد.", show_alert=True)
