import re
import time

from pyrogram import Client as app, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from .navigation import ask_with_back, clear_section_message
from .order_lock import ORDER_LOCK
from .points_core import db, get_active_coupon, get_gift_config, is_admin


def _admin_keyboard(coupon):
    rows = [
        [
            btn("🎁 مدى نقاط الهدية", callback_data="points_gift_range"),
            btn("⏱️ وقت الهدية", callback_data="points_gift_interval"),
        ],
        [btn("🎟️ إنشاء أو تغيير كوبون", callback_data="points_coupon_create")],
    ]
    if coupon and coupon.get("active", True):
        rows.append([btn("⏸️ إيقاف الكوبون", callback_data="points_coupon_disable")])
    rows.append([btn("↩️ رجوع للإعدادات", callback_data="setting_bot")])
    return mk(rows)


def _admin_text():
    gift = get_gift_config()
    lines = [
        "إعدادات تجميع النقاط",
        "",
        f"نقاط الهدية العشوائية: {gift['min_points']} إلى {gift['max_points']}",
        f"الوقت بين الهدايا: {gift['interval_hours']} ساعة",
    ]

    coupon = get_active_coupon()
    if not coupon:
        lines.extend(["", "الكوبون: لا يوجد كوبون مُعد حالياً."])
    else:
        status = "فعّال"
        if not coupon.get("active", True):
            status = "متوقف"
        elif time.time() >= float(coupon.get("expires_at", 0)):
            status = "منتهي الصلاحية"
        lines.extend(
            [
                "",
                f"الكوبون: {coupon.get('code', '—')} ({status})",
                f"النقاط: {coupon.get('reward_points', 0)}",
                f"المستخدمون: {coupon.get('uses', 0)}/{coupon.get('max_uses', 0)}",
            ]
        )
    return "\n".join(lines)


async def _show_admin_panel(query):
    coupon = get_active_coupon()
    await query.edit_message_text(
        _admin_text(),
        reply_markup=_admin_keyboard(coupon),
    )


async def _require_admin(query):
    if is_admin(query.from_user.id):
        return True
    await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
    return False


def _parse_positive_int(text, maximum=1_000_000):
    if not re.fullmatch(r"\s*\d+\s*", text or ""):
        raise ValueError("يجب إدخال رقم صحيح.")
    value = int(text)
    if value < 1 or value > maximum:
        raise ValueError("الرقم خارج الحدود المسموحة.")
    return value


def _parse_range(text):
    match = re.fullmatch(r"\s*(\d+)\s*-\s*(\d+)\s*", text or "")
    if not match:
        raise ValueError("أرسل الحد الأدنى والأعلى بهذا الشكل: 100-200.")
    minimum, maximum = map(int, match.groups())
    if minimum < 1 or maximum < minimum or maximum > 1_000_000:
        raise ValueError("تحقق من أن الحدين موجبان وأن الأعلى لا يقل عن الأدنى.")
    return minimum, maximum


def _parse_coupon_code(text):
    code = (text or "").strip()
    if not code or len(code) > 32:
        raise ValueError("أدخل من حرف واحد إلى 32 حرفاً أو رقماً.")
    if not all(character.isalnum() or character in "_-" for character in code):
        raise ValueError("استخدم الحروف أو الأرقام فقط، ويمكن إضافة _ أو -.")
    return code.upper()


async def _ask_value(client, user_id, prompt, back_callback, parser, error_text):
    current_prompt = prompt
    while True:
        answer = await ask_with_back(
            client,
            user_id,
            current_prompt,
            back_callback,
            filters=filters.user(user_id),
        )
        if not answer:
            return None
        try:
            value = parser(answer.text or "")
        except ValueError:
            for message in (getattr(answer, "sent_message", None), answer):
                if message is not None:
                    try:
                        await message.delete()
                    except Exception:
                        pass
            current_prompt = f"{prompt}\n\n{error_text}"
        else:
            for message in (getattr(answer, "sent_message", None), answer):
                if message is not None:
                    try:
                        await message.delete()
                    except Exception:
                        pass
            return value


def _confirmation_keyboard():
    return mk([[btn("العودة لإعدادات التجميع", callback_data="points_admin")]])


@app.on_callback_query(filters.regex(r"^points_admin$"))
async def points_admin_panel(client, query):
    if not await _require_admin(query):
        return
    await query.answer()
    await _show_admin_panel(query)


@app.on_callback_query(filters.regex(r"^points_gift_range$"))
async def set_gift_range(client, query):
    if not await _require_admin(query):
        return
    await clear_section_message(query)
    value = await _ask_value(
        client,
        query.from_user.id,
        "أرسل أقل وأعلى عدد للنقاط بهذا الشكل: 100-200",
        "points_admin",
        _parse_range,
        "مثال صحيح: 100-200.",
    )
    if value is None:
        return

    minimum, maximum = value
    async with ORDER_LOCK:
        config = get_gift_config()
        config["min_points"] = minimum
        config["max_points"] = maximum
        db.set("points_gift_config", config)

    await client.send_message(
        query.from_user.id,
        f"تم تحديث مدى الهدية إلى {minimum}-{maximum} نقطة ✅",
        reply_markup=_confirmation_keyboard(),
    )


@app.on_callback_query(filters.regex(r"^points_gift_interval$"))
async def set_gift_interval(client, query):
    if not await _require_admin(query):
        return
    await clear_section_message(query)
    hours = await _ask_value(
        client,
        query.from_user.id,
        "أرسل عدد الساعات التي ينتظرها المستخدم قبل أخذ هدية جديدة (1-8760).",
        "points_admin",
        lambda text: _parse_positive_int(text, maximum=8760),
        "أرسل عدداً صحيحاً من 1 إلى 8760 ساعة.",
    )
    if hours is None:
        return

    async with ORDER_LOCK:
        config = get_gift_config()
        config["interval_hours"] = hours
        db.set("points_gift_config", config)

    await client.send_message(
        query.from_user.id,
        f"تم ضبط وقت الهدية على كل {hours} ساعة ✅",
        reply_markup=_confirmation_keyboard(),
    )


@app.on_callback_query(filters.regex(r"^points_coupon_create$"))
async def create_coupon(client, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)

    code = await _ask_value(
        client,
        user_id,
        "أرسل كود الكوبون؛ يُقبل حرف واحد أو أكثر بالعربية أو الإنجليزية أو الأرقام.",
        "points_admin",
        _parse_coupon_code,
        "يُقبل من حرف واحد إلى 32 حرفاً أو رقماً، ويمكن إضافة _ أو -.",
    )
    if code is None:
        return

    reward = await _ask_value(
        client,
        user_id,
        "أرسل عدد النقاط التي يمنحها الكوبون.",
        "points_admin",
        _parse_positive_int,
        "أرسل عدداً صحيحاً أكبر من صفر.",
    )
    if reward is None:
        return

    valid_hours = await _ask_value(
        client,
        user_id,
        "أرسل مدة صلاحية الكوبون بالساعات (1-8760).",
        "points_admin",
        lambda text: _parse_positive_int(text, maximum=8760),
        "أرسل عدداً صحيحاً من 1 إلى 8760 ساعة.",
    )
    if valid_hours is None:
        return

    max_uses = await _ask_value(
        client,
        user_id,
        "أرسل الحد الأقصى لعدد المستخدمين الذين يمكنهم استخدام الكوبون.",
        "points_admin",
        _parse_positive_int,
        "أرسل عدداً صحيحاً أكبر من صفر.",
    )
    if max_uses is None:
        return

    created_at = time.time()
    coupon = {
        "code": code,
        "reward_points": reward,
        "created_at": created_at,
        "expires_at": created_at + valid_hours * 3600,
        "valid_hours": valid_hours,
        "max_uses": max_uses,
        "uses": 0,
        "users": [],
        "active": True,
    }
    async with ORDER_LOCK:
        db.set("points_active_coupon", coupon)

    await client.send_message(
        user_id,
        f"تم إنشاء الكوبون بنجاح ✅\n"
        f"الكود: {code}\n"
        f"النقاط لكل مستخدم: {reward}\n"
        f"مدة الصلاحية: {valid_hours} ساعة\n"
        f"عدد المستخدمين المسموح: {max_uses}",
        reply_markup=_confirmation_keyboard(),
    )


@app.on_callback_query(filters.regex(r"^points_coupon_disable$"))
async def disable_coupon(client, query):
    if not await _require_admin(query):
        return
    coupon = get_active_coupon()
    if coupon:
        coupon["active"] = False
        async with ORDER_LOCK:
            db.set("points_active_coupon", coupon)
    await query.answer("تم إيقاف الكوبون.")
    await _show_admin_panel(query)
