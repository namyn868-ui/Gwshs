import asyncio
import re
from html import escape
from types import SimpleNamespace

import pyrogram.errors
from kvsqlite.sync import Client as Database
from pyrogram import Client as app, StopPropagation, enums, filters
from pyrogram.enums import ChatMemberStatus, ChatType
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from config import Config
from .text_templates import render_template

db = Database("data.sqlite", "fuck")
TARGETS_KEY = "force_targets"
SUBSCRIPTION_LOCK = asyncio.Lock()
GATE_MESSAGES = {}
PENDING_STARTS = {}
GATE_REQUIRED_CHANNELS = {}


def _channel_names():
    channels = db.get("force") or []
    if not isinstance(channels, list):
        return []
    names = []
    for channel in channels:
        name = str(channel).strip().removeprefix("@").lower()
        if name and name not in names:
            names.append(name)
    return names


async def _record_verified_subscriber(client, channel_name, user_id):
    completed = False
    async with SUBSCRIPTION_LOCK:
        targets = db.get(TARGETS_KEY)
        if not isinstance(targets, dict):
            return
        entry = targets.get(channel_name)
        if not isinstance(entry, dict):
            return
        try:
            target = int(entry.get("target", 0))
            count = int(entry.get("count", 0))
        except (TypeError, ValueError):
            return
        if target <= 0:
            return

        counted_users = entry.get("users")
        if not isinstance(counted_users, list):
            counted_users = []
        if user_id in counted_users:
            return

        counted_users.append(user_id)
        count += 1
        entry["users"] = counted_users
        entry["count"] = count

        channels = _channel_names()
        if count >= target:
            db.set("force", [name for name in channels if name != channel_name])
            targets.pop(channel_name, None)
            completed = True
        else:
            targets[channel_name] = entry
        db.set(TARGETS_KEY, targets)

    if completed:
        try:
            await client.send_message(
                Config.OWNER_ID,
                f"✅ تم اكتمال عدد الاشتراك الإجباري للقناة @{channel_name}.",
            )
        except Exception as error:
            print(f"Could not notify bot owner about completed required channel: {error}")


async def check_channel_member(app, chat_id, user_id, record=False):
    channel_name = str(chat_id).strip().removeprefix("@").lower()
    try:
        member = await app.get_chat_member(chat_id=channel_name, user_id=user_id)
        is_member = member.status in [
            ChatMemberStatus.OWNER,
            ChatMemberStatus.ADMINISTRATOR,
            ChatMemberStatus.MEMBER,
        ] or (
            member.status == ChatMemberStatus.RESTRICTED
            and bool(getattr(member, "is_member", False))
        )
        if is_member:
            if record:
                await _record_verified_subscriber(app, channel_name, user_id)
            return True
        return False
    except pyrogram.errors.exceptions.bad_request_400.ChatAdminRequired:
        targets = db.get(TARGETS_KEY)
        configured_target = targets.get(channel_name) if isinstance(targets, dict) else None
        if isinstance(configured_target, dict) and configured_target.get("target"):
            return False
        return True
    except Exception as e:
        return False


async def _missing_channels(client, user_id, count_verified=False):
    missing = []
    prompted = _prompted_channels(user_id)
    for channel_name in _channel_names():
        is_member = await check_channel_member(client, channel_name, user_id)
        if is_member:
            if count_verified and channel_name in prompted:
                await _record_verified_subscriber(client, channel_name, user_id)
        else:
            missing.append(channel_name)
    return missing


def _prompted_channels(user_id):
    prompted = GATE_REQUIRED_CHANNELS.get(user_id)
    if prompted is None:
        saved = db.get(f"force_prompted_{user_id}") or []
        prompted = set(saved) if isinstance(saved, list) else set()
        GATE_REQUIRED_CHANNELS[user_id] = prompted
    return prompted


def _gate_content(missing, user_id, user):
    if not missing:
        return "تم رصد اشتراكك بجميع القنوات المطلوبة.\nاضغط «تحقق من الاشتراك» للمتابعة."
    intro = render_template("force", user_id, user=user)
    lines = [intro, "", "اشترك في القنوات الظاهرة، ثم اضغط «تحقق من الاشتراك»."]
    for channel_name in missing:
        lines.append(f"• @{escape(channel_name)}")
    return "\n".join(lines)


def _gate_keyboard(missing):
    rows = [
        [
            InlineKeyboardButton(
                f"الاشتراك في @{channel_name}",
                url=f"https://t.me/{channel_name}",
            )
        ]
        for channel_name in missing
    ]
    rows.append(
        [InlineKeyboardButton("تحقق من الاشتراك", callback_data="force_verify")]
    )
    return InlineKeyboardMarkup(rows)


async def _show_gate(client, user_id, missing, message=None, user=None):
    if missing:
        prompted = _prompted_channels(user_id)
        prompted.update(missing)
        db.set(f"force_prompted_{user_id}", sorted(prompted))
    content = _gate_content(missing, user_id, user)
    keyboard = _gate_keyboard(missing)
    target_message = message or GATE_MESSAGES.get(user_id)
    if target_message:
        try:
            await target_message.edit_text(
                content,
                reply_markup=keyboard,
                parse_mode=enums.ParseMode.HTML,
            )
            GATE_MESSAGES[user_id] = target_message
            return
        except pyrogram.errors.MessageNotModified:
            GATE_MESSAGES[user_id] = target_message
            return
        except Exception:
            GATE_MESSAGES.pop(user_id, None)

    sent_message = await client.send_message(
        user_id,
        content,
        reply_markup=keyboard,
        parse_mode=enums.ParseMode.HTML,
    )
    GATE_MESSAGES[user_id] = sent_message


async def _clear_gate_message(user_id):
    gate_message = GATE_MESSAGES.pop(user_id, None)
    if gate_message:
        try:
            await gate_message.delete()
        except Exception:
            pass


def _pending_channels(user_id):
    pending = _prompted_channels(user_id)
    if not pending:
        return set()
    pending.intersection_update(_channel_names())
    if not pending:
        GATE_REQUIRED_CHANNELS.pop(user_id, None)
        db.set(f"force_prompted_{user_id}", [])
        return set()
    return pending


def _set_pending_start(user_id, text):
    PENDING_STARTS[user_id] = text


def _clear_pending_start(user_id):
    PENDING_STARTS.pop(user_id, None)


def _pop_pending_start(user_id):
    return PENDING_STARTS.pop(user_id, "/start")


async def _resume_start(client, user):
    user_id = user.id
    start_text = _pop_pending_start(user_id)

    async def reply(text, *args, **kwargs):
        return await client.send_message(user_id, text, *args, **kwargs)

    fake_message = SimpleNamespace(from_user=user, text=start_text, reply=reply)
    referral = re.fullmatch(r"/start\s+(\d+)", start_text.strip())

    if referral:
        from .start_with_code import sm

        await sm(client, fake_message)
        return

    from .adminss import ade
    from .start_msg import startm

    await ade(client, fake_message)
    await startm(client, fake_message)


@app.on_message(filters.private, group=-100)
async def enforce_required_channels_on_messages(client, message):
    user = message.from_user
    if not user:
        return
    missing = await _missing_channels(client, user.id)
    if not missing:
        if not _pending_channels(user.id):
            _clear_pending_start(user.id)
            await _clear_gate_message(user.id)
            return
        await _show_gate(client, user.id, [], user=user)
        raise StopPropagation

    if message.text and re.match(r"^/start(?:\s|$)", message.text):
        _set_pending_start(user.id, message.text)
    await _show_gate(client, user.id, missing, user=user)
    raise StopPropagation


@app.on_callback_query(group=-100)
async def enforce_required_channels_on_callbacks(client, query):
    if not query.message or query.message.chat.type != ChatType.PRIVATE:
        return
    if query.data == "force_verify":
        return

    missing = await _missing_channels(client, query.from_user.id)
    if not missing:
        if not _pending_channels(query.from_user.id):
            _clear_pending_start(query.from_user.id)
            await _clear_gate_message(query.from_user.id)
            return
        await query.answer()
        await _show_gate(
            client,
            query.from_user.id,
            [],
            query.message,
            user=query.from_user,
        )
        raise StopPropagation
    await query.answer()
    await _show_gate(
        client,
        query.from_user.id,
        missing,
        query.message,
        user=query.from_user,
    )
    raise StopPropagation


@app.on_callback_query(filters.regex(r"^force_verify$"), group=-99)
async def verify_required_channels(client, query):
    missing = await _missing_channels(
        client,
        query.from_user.id,
        count_verified=True,
    )
    if missing:
        GATE_REQUIRED_CHANNELS[query.from_user.id] = set(missing)
        db.set(f"force_prompted_{query.from_user.id}", missing)
        await query.answer("باقي عليك الاشتراك في القنوات الظاهرة.", show_alert=True)
        await _show_gate(
            client,
            query.from_user.id,
            missing,
            query.message,
            user=query.from_user,
        )
        return

    await query.answer("تم التحقق من الاشتراك ✅")
    GATE_REQUIRED_CHANNELS.pop(query.from_user.id, None)
    db.set(f"force_prompted_{query.from_user.id}", [])
    GATE_MESSAGES.pop(query.from_user.id, None)
    try:
        await query.message.delete()
    except Exception:
        pass
    await _resume_start(client, query.from_user)
