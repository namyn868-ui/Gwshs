import logging
import random
import re

from pyrogram import Client as app, filters
from .start_msg import startm
from kvsqlite.sync import Client as mody
from .navigation import ask_with_back
from .bot_controls import entry_notifications_enabled
from .agents import is_active_agent
from .user_registration import register_user
db = mody("data.sqlite", 'fuck')
logger = logging.getLogger(__name__)


@app.on_message(filters.private & filters.regex(r"^/start(?:@[A-Za-z0-9_]+)?\s+\S+"))
async def sm(app, msg):
    user_id = msg.from_user.id
    if is_active_agent(user_id):
        await startm(app, msg)
        return

    parts = (msg.text or "").split(maxsplit=1)
    referrer_id = None
    if len(parts) > 1 and parts[1].isdigit():
        parsed_referrer_id = int(parts[1])
        if parsed_referrer_id > 0:
            referrer_id = parsed_referrer_id

    ban_list = db.get("ban_list")
    if not isinstance(ban_list, (list, tuple, set)):
        ban_list = []
        db.set("ban_list", ban_list)
    if user_id in ban_list:
        return

    if db.exists(f"user_{user_id}"):
        if user_id == referrer_id:
            await app.send_message(user_id, "لا يمكنك الدخول عبر الرابط الخاص بك ❌")
        await startm(app, msg)
        return

    code = random.randint(100000, 999999)
    ask1 = await ask_with_back(
        app,
        user_id,
        f"•︙ارسل الان كود التحقق هذا للتاكد من انك لست روبوت : {code} ",
        "back_invite",
        filters=filters.user(user_id),
    )
    if not ask1:
        return

    while True:
        try:
            user_code = int((ask1.text or "").strip())
        except ValueError:
            ask1 = await ask_with_back(
                app,
                user_id,
                "• يرجي إرسال قيمة رقمية فقط (أرقام فقط)\n• اعد ارسال الكود مره اخرى",
                "back_invite",
                filters=filters.user(user_id),
            )
            if not ask1:
                return
            continue

        if user_code != code:
            ask1 = await ask_with_back(
                app,
                user_id,
                "• عذرا الكود الذي ارسلته غير صحيح\n• اعد ارسال الكود مره اخرى",
                "back_invite",
                filters=filters.user(user_id),
            )
            if not ask1:
                return
            continue

        try:
            created, reward, referrer_balance = await register_user(
                user_id,
                referrer_id,
            )
        except Exception as error:
            logger.error("User registration failed (%s)", type(error).__name__)
            await ask1.reply("تعذر إكمال التسجيل حالياً. حاول مرة أخرى.")
            return
        if not created:
            await startm(app, msg)
            return

        await ask1.reply("• تم التحقق بنجاح من أنك لست روبوت ✅\n\n• ارسل /start")
        if reward > 0 and referrer_id and referrer_balance is not None:
            try:
                await app.send_message(
                    referrer_id,
                    f"• قام : {msg.from_user.mention} بالدخول الى الرابط الخاص "
                    f"وحصلت على {format(reward.normalize(), 'f')} نقطه ✨\n"
                    f"• عدد نقاطك الان : {format(referrer_balance.normalize(), 'f')}",
                )
            except Exception as error:
                logger.warning(
                    "Referral notification failed (%s)",
                    type(error).__name__,
                )

        if entry_notifications_enabled():
            admin_ids = sorted(set(db.get("admin_list") or []))
            count = sum(
                1
                for key in db.keys()
                if re.fullmatch(r"user_\d+", str(key[0]))
            )
            for admin_id in admin_ids:
                try:
                    await app.send_message(
                        admin_id,
                        "تم دخول شخص جديد الى البوت الخاص بك 👾\n\n"
                        "معلومات العضو الجديد:\n"
                        f"الاسم: {msg.from_user.mention}\n"
                        f"المعرف: @{msg.from_user.username or 'لا يوجد'}\n"
                        f"الايدي: {msg.from_user.id}\n"
                        f"عدد الأعضاء الكلي: {count}",
                    )
                except Exception as error:
                    logger.warning(
                        "Admin entry notification failed (%s)",
                        type(error).__name__,
                    )
        await startm(app, msg)
        return