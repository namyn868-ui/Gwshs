import re
from datetime import datetime
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

from kvsqlite.sync import Client as Database
from pyrogram import Client as app, StopPropagation, enums, filters
from pyrogram.enums import ChatType
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from .navigation import ask_with_back, clear_section_message


db = Database("data.sqlite", "fuck")
LOCAL_TIMEZONE = ZoneInfo("Asia/Baghdad")
BAN_NOTICE = "تم حظرك من استخدام البوت من قبل الإدارة."
USER_ID_PATTERN = re.compile(r"^\d{1,20}$")


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def _ban_list():
    value = db.get("ban_list")
    if not isinstance(value, list):
        return []
    return list(dict.fromkeys(int(item) for item in value if str(item).isdigit()))


def is_user_banned(user_id):
    return int(user_id) in _ban_list()


def _today():
    return datetime.now(LOCAL_TIMEZONE).date().isoformat()


def _registered_user_ids():
    user_ids = set()
    for item in db.keys():
        key = item[0] if isinstance(item, (tuple, list)) else item
        match = re.fullmatch(r"user_(\d+)", str(key))
        if match:
            user_ids.add(int(match.group(1)))
    return user_ids


def _user_admin_keyboard(user_id):
    banned = is_user_banned(user_id)
    action_button = (
        btn("رفع الحظر ✅", callback_data=f"moderation_unban:{user_id}")
        if banned
        else btn("حظر المستخدم 🚫", callback_data=f"moderation_ban:{user_id}")
    )
    return mk(
        [
            [action_button],
            [btn("رجوع لإدارة المستخدمين", callback_data="admin_users")],
        ]
    )


def _users_menu():
    banned_count = len(_ban_list())
    return mk(
        [
            [
                btn("🚫 حظر مستخدم", callback_data="ban_mes"),
                btn("✅ رفع الحظر", callback_data="unban_mes"),
            ],
            [
                btn("📊 الإحصائيات", callback_data="stats"),
                btn(
                    f"📋 المحظورون ({banned_count})",
                    callback_data="moderation_banned_list",
                ),
            ],
            [btn("↩️ رجوع للوحة الأدمن", callback_data="back_admin")],
        ]
    )


def _dashboard_stats():
    user_ids = _registered_user_ids()
    active_today = sum(
        1
        for user_id in user_ids
        if db.get(f"user_activity_day_{user_id}") == _today()
    )
    service_operations = 0
    user_points = Decimal("0")
    for user_id in user_ids:
        try:
            service_operations += max(0, int(db.get(f"user_{user_id}_buys") or 0))
        except (TypeError, ValueError):
            pass
        user = db.get(f"user_{user_id}")
        if isinstance(user, dict):
            try:
                points = Decimal(str(user.get("coins", 0)))
                if points.is_finite():
                    user_points += points
            except (InvalidOperation, TypeError, ValueError):
                pass

    agent_points = Decimal("0")
    agents = db.get("agent_registry")
    if isinstance(agents, dict):
        for agent in agents.values():
            if not isinstance(agent, dict):
                continue
            try:
                wallet = Decimal(str(agent.get("wallet", 0)))
                if wallet.is_finite():
                    agent_points += wallet
            except (InvalidOperation, TypeError, ValueError):
                pass
    total_points = user_points + agent_points
    user_points_text = format(user_points.normalize(), "f")
    agent_points_text = format(agent_points.normalize(), "f")
    total_points_text = format(total_points.normalize(), "f")
    return (
        "📈 <b>لوحة إحصائيات البوت</b>\n\n"
        f"👥 إجمالي المستخدمين: <b>{len(user_ids):,}</b>\n"
        f"🟢 المستخدمون النشطون اليوم: <b>{active_today:,}</b>\n"
        f"⚙️ إجمالي عمليات الخدمات الناجحة: <b>{service_operations:,}</b>\n"
        f"👤 نقاط المستخدمين: <b>{user_points_text}</b>\n"
        f"🛡️ نقاط محافظ الوكلاء: <b>{agent_points_text}</b>\n"
        f"💰 إجمالي النقاط في النظام: <b>{total_points_text}</b>\n\n"
        f"🕒 آخر تحديث: {_today()} (توقيت بغداد)"
    )


async def _change_ban(client, user_id, banned):
    if banned and _is_admin(user_id):
        return False, "لا يمكن حظر حساب أدمن. أزل صلاحياته أولاً إذا لزم الأمر."

    ban_list = _ban_list()
    if banned:
        if user_id in ban_list:
            return False, "هذا المستخدم محظور بالفعل."
        ban_list.append(user_id)
        db.set("ban_list", ban_list)
        return True, "تم حظر المستخدم من استخدام البوت."

    if user_id not in ban_list:
        return False, "هذا المستخدم غير موجود في قائمة الحظر."
    ban_list.remove(user_id)
    db.set("ban_list", ban_list)
    try:
        await client.send_message(
            user_id,
            "تم رفع الحظر عن حسابك. يمكنك استخدام البوت مجدداً بإرسال /start.",
        )
    except Exception:
        pass
    return True, "تم رفع الحظر عن المستخدم."


@app.on_message(filters.private, group=-102)
async def enforce_user_bans_and_track_activity(client, message):
    user = message.from_user
    if not user:
        return
    if not _is_admin(user.id) and is_user_banned(user.id):
        if message.text and re.match(r"^/start(?:@\w+)?(?:\s|$)", message.text.strip()):
            await message.reply_text(BAN_NOTICE)
        raise StopPropagation
    db.set(
        f"user_activity_day_{user.id}",
        _today(),
    )


@app.on_callback_query(group=-102)
async def enforce_user_bans_and_track_callback_activity(client, query):
    user = query.from_user
    if not user:
        return
    if not _is_admin(user.id) and is_user_banned(user.id):
        await query.answer(BAN_NOTICE, show_alert=True)
        raise StopPropagation
    if not query.message or query.message.chat.type != ChatType.PRIVATE:
        return
    db.set(
        f"user_activity_day_{user.id}",
        _today(),
    )


@app.on_callback_query(filters.regex(r"^admin_users$"))
async def open_user_admin_menu(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    await query.edit_message_text(
        "🚫 <b>إدارة المستخدمين</b>\n\n"
        "احظر الحسابات المخالفة أو ارفع الحظر عنها، وتابع مؤشرات البوت من لوحة الإحصائيات.",
        reply_markup=_users_menu(),
        parse_mode=enums.ParseMode.HTML,
    )
    await query.answer()


async def _prompt_for_user_id(client, query, banned):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    await clear_section_message(query)
    action = "حظره" if banned else "رفع الحظر عنه"
    answer = await ask_with_back(
        client,
        query.from_user.id,
        f"أرسل آيدي المستخدم الذي تريد {action}.",
        "admin_users",
    )
    if not answer or not answer.text:
        return
    raw_id = answer.text.strip()
    if not USER_ID_PATTERN.fullmatch(raw_id) or int(raw_id) < 1:
        await answer.reply(
            "آيدي غير صالح. أرسل أرقام الآيدي فقط.",
            reply_markup=mk([[btn("رجوع لإدارة المستخدمين", callback_data="admin_users")]]),
        )
        return
    user_id = int(raw_id)
    success, result = await _change_ban(client, user_id, banned)
    await answer.reply(
        f"{result}\nآيدي المستخدم: <code>{user_id}</code>",
        reply_markup=mk([[btn("رجوع لإدارة المستخدمين", callback_data="admin_users")]]),
        parse_mode=enums.ParseMode.HTML,
    )


@app.on_callback_query(filters.regex(r"^ban_mes$"))
async def prompt_ban_user(client, query):
    await _prompt_for_user_id(client, query, True)


@app.on_callback_query(filters.regex(r"^unban_mes$"))
async def prompt_unban_user(client, query):
    await _prompt_for_user_id(client, query, False)


@app.on_callback_query(filters.regex(r"^moderation_(ban|unban):(\d+)$"))
async def change_user_ban_from_info(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا الإجراء مخصص للأدمن فقط.", show_alert=True)
        return
    action, user_id_text = query.data.split(":")
    user_id = int(user_id_text)
    success, result = await _change_ban(client, user_id, action == "moderation_ban")
    await query.answer(result, show_alert=not success)
    await query.edit_message_reply_markup(reply_markup=_user_admin_keyboard(user_id))


@app.on_callback_query(filters.regex(r"^moderation_banned_list$"))
async def show_banned_users(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    banned = _ban_list()
    text = "🚫 <b>المستخدمون المحظورون</b>\n\n"
    if banned:
        text += "\n".join(f"• <code>{user_id}</code>" for user_id in banned[:100])
        if len(banned) > 100:
            text += f"\n\n... وهناك {len(banned) - 100} حسابات أخرى."
    else:
        text += "لا يوجد مستخدمون محظورون حالياً."
    await query.edit_message_text(
        text,
        parse_mode=enums.ParseMode.HTML,
        reply_markup=mk(
            [
                [btn("تحديث", callback_data="moderation_banned_list")],
                [btn("رجوع لإدارة المستخدمين", callback_data="admin_users")],
            ]
        ),
    )
    await query.answer()


@app.on_callback_query(filters.regex(r"^stats$"))
async def show_bot_statistics(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    await query.edit_message_text(
        _dashboard_stats(),
        parse_mode=enums.ParseMode.HTML,
        reply_markup=mk(
            [
                [btn("تحديث الإحصائيات 🔄", callback_data="stats")],
                [btn("رجوع لإدارة المستخدمين", callback_data="admin_users")],
                [btn("رجوع للوحة الأدمن", callback_data="back_admin")],
            ]
        ),
    )
    await query.answer()
