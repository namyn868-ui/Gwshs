from kvsqlite.sync import Client as Database
from pyrogram import Client as app, StopPropagation, enums, filters
from pyrogram.enums import ChatType
from pyrogram.errors import MessageNotModified
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk


db = Database("data.sqlite", "fuck")
MAINTENANCE_NOTICE = "عذراً، هذه الخدمة معطلة مؤقتاً للصيانة 🛠️"

SERVICES = {
    "members": {
        "label": "رشق الأعضاء",
        "exact": {"member"},
        "prefixes": ("member_confirm:", "member_cancel:"),
    },
    "engagement": {
        "label": "المشاهدات والتفاعلات",
        "exact": {"engagement_home"},
        "prefixes": ("engage_category:", "engage_service:"),
    },
    "transfer": {
        "label": "تحويل الرصيد",
        "exact": {"tran"},
        "prefixes": (),
    },
    "points": {
        "label": "تجميع النقاط",
        "exact": {"collect_points", "daily_gift", "coupon_redeem", "sharelink"},
        "prefixes": (),
    },
    "account": {
        "label": "معلومات الحساب",
        "exact": {"account"},
        "prefixes": (),
    },
    "order_status": {
        "label": "معلومات الطلب",
        "exact": {"id_requests"},
        "prefixes": (),
    },
    "balance": {
        "label": "عرض الرصيد",
        "exact": {"lol"},
        "prefixes": (),
    },
    "agents": {
        "label": "لوحة الوكلاء",
        "exact": set(),
        "prefixes": ("agent_",),
    },
}


def _enabled(service_id):
    value = db.get(f"main_service_enabled_{service_id}")
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip().casefold() not in {"", "0", "false", "off", "no"}
    return bool(value)


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def _panel_text():
    return (
        "<b>إدارة أزرار الخدمات</b>\n"
        "🟢 مفعّلة  •  🔴 متوقفة\n"
        "اضغط على الزر لتغيير الحالة."
    )


def _panel_keyboard():
    service_ids = list(SERVICES)
    rows = []
    for index in range(0, len(service_ids), 2):
        row = []
        for service_id in service_ids[index:index + 2]:
            service = SERVICES[service_id]
            status = "🟢" if _enabled(service_id) else "🔴"
            row.append(
                btn(
                    f"{status} {service['label']}",
                    callback_data=f"service_toggle:{service_id}",
                )
            )
        rows.append(row)
    rows.append(
        [
            btn("🔄 تحديث", callback_data="service_switches"),
            btn("↩️ رجوع للإعدادات", callback_data="setting_bot"),
        ]
    )
    return mk(rows)


async def _show_panel(query):
    try:
        await query.edit_message_text(
            _panel_text(),
            reply_markup=_panel_keyboard(),
            parse_mode=enums.ParseMode.HTML,
        )
    except MessageNotModified:
        # Telegram raises this when an admin presses refresh without changing
        # the panel. The callback is already acknowledged; there is nothing to edit.
        return


@app.on_callback_query(filters.regex(r"^service_switches$"))
async def open_service_switches(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    await query.answer()
    await _show_panel(query)


@app.on_callback_query(
    filters.regex(
        r"^service_toggle:(members|engagement|transfer|points|account|order_status|balance|agents)$"
    )
)
async def toggle_service(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    service_id = query.data.split(":", 1)[1]
    enabled = not _enabled(service_id)
    db.set(f"main_service_enabled_{service_id}", enabled)

    state = "تم تفعيل" if enabled else "تم تعطيل"
    await query.answer(f"{state} خدمة {SERVICES[service_id]['label']}.")
    await _show_panel(query)


def _service_for_callback(callback_data):
    for service_id, service in SERVICES.items():
        if callback_data in service["exact"] or callback_data.startswith(
            service["prefixes"]
        ):
            return service_id
    return None


@app.on_callback_query(group=-103)
async def enforce_service_switches(client, query):
    user = query.from_user
    message = query.message
    if (
        not user
        or not message
        or message.chat.type != ChatType.PRIVATE
        or _is_admin(user.id)
    ):
        return

    service_id = _service_for_callback(query.data or "")
    if service_id and not _enabled(service_id):
        await query.answer(MAINTENANCE_NOTICE, show_alert=True)
        raise StopPropagation
