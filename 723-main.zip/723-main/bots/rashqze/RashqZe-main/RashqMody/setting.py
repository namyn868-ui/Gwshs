from pyrogram import Client as app, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import time
from kvsqlite.sync import Client as mody
from config import Config
db = mody("data.sqlite", 'fuck')
@app.on_callback_query(filters.regex("^setting_bot$"))
async def dailygiftt(app,query):
    user_id = query.from_user.id
    if user_id not in (db.get("admin_list") or []):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    keys = mk(
        [
            [
                btn('➕ إضافة نقاط', 'add_coins'),
                btn('➖ خصم نقاط', 'less_coin'),
            ],
            [btn('🔎 معلومات مستخدم', 'get_infos')],
            [
                btn('🔑 مفتاح API', 'set_api'),
                btn('🌐 الدومين', 'set_domain'),
            ],
            [
                btn('👥 رشق الأعضاء', 'member_admin'),
                btn('📈 المشاهدات والتفاعلات', 'engage_admin'),
            ],
            [
                btn('💸 أقل تحويل', 'transfer'),
                btn('🔗 نقاط الدعوة', 'invite_coin'),
            ],
            [
                btn('🎁 إعدادات النقاط', 'points_admin'),
                btn('🎛️ أزرار الخدمات', 'service_switches'),
            ],
            [
                btn('📝 النصوص', 'set_start'),
                btn('📢 قناة البوت', 'bot_channel_manage'),
            ],
        ]
    )
    if user_id == Config.OWNER_ID:
        keys.inline_keyboard.append(
            [btn("🛡️ إدارة الوكلاء", callback_data="agent_owner")]
        )
    keys.inline_keyboard.append([btn('↩️ رجوع للوحة الأدمن', 'back_admin')])
    rk = f"""- مرحباً عزيزي المطور ︎{query.from_user.mention} 🔥

- يمكن للعضو ارسال /id لارسال الايدي الخاص به"""
    await query.edit_message_text(rk, reply_markup=keys)
