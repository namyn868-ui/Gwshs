import sqlite3
import time
from pathlib import Path

from kvsqlite import PickleEncoder
from kvsqlite.sync import Client as Database
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk


db = Database("data.sqlite", "fuck")
DATABASE_PATH = Path(__file__).resolve().parents[1] / "data.sqlite"
ENCODER = PickleEncoder()

DEFAULT_GIFT_CONFIG = {
    "min_points": 100,
    "max_points": 200,
    "interval_hours": 24,
}


def open_transaction():
    connection = sqlite3.connect(
        str(DATABASE_PATH),
        timeout=15,
        isolation_level=None,
    )
    connection.execute("PRAGMA busy_timeout = 15000")
    connection.execute(
        'CREATE TABLE IF NOT EXISTS "fuck" '
        "(k VARCHAR(4096) PRIMARY KEY, v BLOB, expire_time INTEGER DEFAULT NULL) "
        "WITHOUT ROWID"
    )
    connection.execute("BEGIN IMMEDIATE")
    return connection


def read_value(connection, key):
    row = connection.execute(
        'SELECT v FROM "fuck" WHERE k = ? '
        "AND (expire_time IS NULL OR expire_time > ?) LIMIT 1",
        (key, time.time()),
    ).fetchone()
    return ENCODER.decode(row[0]) if row else None


def write_value(connection, key, value):
    connection.execute(
        'REPLACE INTO "fuck" (k, v, expire_time) VALUES (?, ?, NULL)',
        (key, ENCODER.encode(value)),
    )


def is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def get_gift_config():
    stored = db.get("points_gift_config") or {}
    config = {}
    for key, default in DEFAULT_GIFT_CONFIG.items():
        try:
            config[key] = int(stored.get(key, default))
        except (TypeError, ValueError):
            config[key] = default

    if config["min_points"] < 1 or config["max_points"] < config["min_points"]:
        config["min_points"] = DEFAULT_GIFT_CONFIG["min_points"]
        config["max_points"] = DEFAULT_GIFT_CONFIG["max_points"]
    if config["interval_hours"] < 1:
        config["interval_hours"] = DEFAULT_GIFT_CONFIG["interval_hours"]
    return config


def get_active_coupon():
    coupon = db.get("points_active_coupon")
    return coupon if isinstance(coupon, dict) else None


def collection_keyboard(back_callback="back"):
    return mk(
        [
            [btn("مشاركة الرابط 📤", callback_data="sharelink")],
            [btn("الهدية اليومية 🎁", callback_data="daily_gift")],
            [btn("كوبون الهدية 🎟️", callback_data="coupon_redeem")],
            [btn("رجوع", callback_data=back_callback)],
        ]
    )


def format_points(value):
    from decimal import Decimal, InvalidOperation

    try:
        amount = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        amount = Decimal("0")
    return format(amount.normalize(), "f")
