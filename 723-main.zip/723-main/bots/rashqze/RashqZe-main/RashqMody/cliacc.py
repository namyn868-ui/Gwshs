from html import escape

from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import time
from kvsqlite.sync import Client as mody
from .text_templates import render_template
db = mody("data.sqlite", 'fuck')


@app.on_message(filters.private & filters.command("id"), group=5)
async def send_user_id(client, message):
    if not message.from_user:
        return
    await message.reply_text(f"ايدي حسابك هو: `{message.from_user.id}`")


def trend():
    k = db.keys("user_%")
    users = []
    for i in k:
        try:
            g = db.get(i[0])
            d = g["id"]
            users.append(g)
        except:
            continue
    data = users
    sorted_users = sorted(data, key=lambda x: len(x["users"]), reverse=True)
    result_string = "⌁︙- المستخدمين الاكثر مشاركة للرابط  :  \n\n"
    for user in sorted_users[:5]:
        user_id = int(user["id"])
        safe_id = escape(str(user_id))
        result_string += (
            f"🏅: ({len(user['users'])}) ↫ "
            f'<a href="tg://user?id={safe_id}">{safe_id}</a>\n'
        )
    return (result_string)
@app.on_callback_query(filters.regex("^account$"))
async def dailygiftt(app,query):
    user_id = query.from_user.id
    info = db.get(f"user_{query.from_user.id}")
    keys = mk(
        [
            [btn(text='رجوع', callback_data='back')]
        ]
    )
    if info:
        coins = float(info['coins'])
        users = len(info['users'])
        buys = int(db.get(f"user_{user_id}_buys")) if db.exists(f"user_{user_id}_buys") else 0
        trans = int(db.get(f"user_{user_id}_trans")) if db.exists(f"user_{user_id}_trans") else 0
        y = trend()
        rk = render_template(
            "account",
            user_id,
            user=query.from_user,
            referrals=users,
            orders=buys,
            transfers=trans,
        )
        if y:
            rk += f"\n\n{y}"
        await query.edit_message_text(
            rk,
            reply_markup=keys,
            parse_mode=enums.ParseMode.HTML,
        )