import logging
import re

from pyrogram import Client as app, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
from kvsqlite.sync import Client as mody
import random
from .navigation import ask_with_back, clear_section_message
from .bot_controls import entry_notifications_enabled
from .user_registration import register_user
db = mody("data.sqlite", 'fuck')
logger = logging.getLogger(__name__)

@app.on_callback_query(filters.regex("^send_code$"))
async def dailygiftt(app,query):
    user_id = query.from_user.id
    if db.exists(f"user_{user_id}"):
        await query.answer('تم التحقق بالفعل انك لست روبوت ✅', show_alert=True)
        return
    code = random.randint(100000, 999999)
    await clear_section_message(query)
    ask1 = await ask_with_back(
        app,
        user_id,
        f"•︙ارسل الان كود التحقق هذا للتاكد من انك لست روبوت : {code} ",
        "back_invite",
        filters=filters.user(user_id),
    )
    if not ask1:
        return

    while True:
        try:
            user_code = int((ask1.text or "").strip())
        except ValueError:
            ask1 = await ask_with_back(
                app,
                user_id,
                "يرجى إرسال أرقام فقط.",
                "back_invite",
                filters=filters.user(user_id),
            )
            if not ask1:
                return
            continue

        if user_code != code:
            ask1 = await ask_with_back(
                app,
                user_id,
                "• عذرا الكود الذي ارسلته غير صحيح\n• اعد ارسال الكود مره اخرى",
                "back_invite",
                filters=filters.user(user_id),
            )
            if not ask1:
                return
            continue

        try:
            created, _reward, _referrer_balance = await register_user(user_id)
        except Exception as error:
            logger.error("User registration failed (%s)", type(error).__name__)
            await ask1.reply("تعذر إكمال التسجيل حالياً. حاول مرة أخرى.")
            return
        if not created:
            await ask1.reply("تم التحقق من حسابك مسبقاً ✅\n\n• ارسل /start")
            return

        await ask1.reply("• تم التحقق بنجاح من أنك لست روبوت ✅\n\n• ارسل /start")
        if entry_notifications_enabled():
            admin_ids = sorted(set(db.get("admin_list") or []))
            count = sum(
                1
                for key in db.keys()
                if re.fullmatch(r"user_\d+", str(key[0]))
            )
            for admin_id in admin_ids:
                try:
                    await app.send_message(
                        admin_id,
                        "٭ تم دخول شخص جديد الى البوت الخاص بك 👾\n\n"
                        "• معلومات العضو الجديد .\n\n"
                        f"• الاسم : {query.from_user.mention}\n"
                        f"• المعرف : @{query.from_user.username or 'لا يوجد'}\n"
                        f"• الايدي : {query.from_user.id}\n\n"
                        f"• عدد الاعضاء الكلي : {count}",
                    )
                except Exception as error:
                    logger.warning(
                        "Admin entry notification failed (%s)",
                        type(error).__name__,
                    )
        return