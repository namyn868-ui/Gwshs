from html import escape

from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from .navigation import ask_with_back, clear_section_message
from .text_templates import TEXT_TEMPLATES, db, get_template


TEXT_LIMIT = 3500
TEMPLATES_BACK = mk([[btn("رجوع لقسم الكلايش", callback_data="set_start")]])
VARIABLE_HELP = (
    "المتغيرات: [name] أو [first_name]، [id]، [balance]\n"
    "لرشق الأعضاء: [min_quantity] و[max_quantity]\n"
    "لمعلومات الحساب: [referrals] و[orders] و[transfers]"
)


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def _template_keyboard(template_id):
    return mk(
        [
            [btn("تعديل النص ✍️", callback_data=f"text_edit:{template_id}")],
            [btn("استعادة الافتراضي 🔄", callback_data=f"text_reset:{template_id}")],
            [btn("رجوع إلى الأقسام", callback_data="set_start")],
        ]
    )


async def show_text_manager(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    rows = [
        [btn("كليشة البداية /start", callback_data="text_template:start")],
        [btn("كليشة الاشتراك الإجباري", callback_data="text_template:force")],
        [btn("كليشة قسم رشق الأعضاء", callback_data="text_template:member")],
        [btn("كليشة معلومات الحساب", callback_data="text_template:account")],
        [btn("رجوع إلى لوحة الأدمن", callback_data="back_admin")],
    ]
    await query.answer()
    await query.edit_message_text(
        "تغيير الكلايش والنصوص\n\nاختر الكليشة التي تريد تعديلها:",
        reply_markup=mk(rows),
    )


async def _show_template_preview(query, template_id, notice=None):
    template = TEXT_TEMPLATES[template_id]
    current = escape(get_template(template_id), quote=False)
    heading = f"<b>{escape(template['title'])}</b>"
    if notice:
        heading = f"{escape(notice)}\n\n{heading}"
    await query.edit_message_text(
        f"{heading}\n\n<pre>{current}</pre>\n\n{VARIABLE_HELP}",
        parse_mode=enums.ParseMode.HTML,
        reply_markup=_template_keyboard(template_id),
    )


@app.on_callback_query(filters.regex(r"^text_template:(start|force|member|account)$"))
async def view_text_template(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    template_id = query.data.split(":", 1)[1]
    await query.answer()
    await _show_template_preview(query, template_id)


@app.on_callback_query(filters.regex(r"^text_edit:(start|force|member|account)$"))
async def edit_text_template(client, query):
    user_id = query.from_user.id
    if not _is_admin(user_id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    template_id = query.data.split(":", 1)[1]
    await clear_section_message(query)
    answer = await ask_with_back(
        client,
        user_id,
        f"أرسل النص الجديد لـ{TEXT_TEMPLATES[template_id]['title']}.\n"
        f"يمكنك استخدام المتغيرات التالية:\n{VARIABLE_HELP}\n\n"
        f"الحد الأقصى {TEXT_LIMIT} حرفاً، أو اضغط «رجوع».",
        "set_start",
        filters=filters.user(user_id),
    )
    if not answer or not answer.text:
        return
    if not _is_admin(user_id):
        await answer.reply("لم تعد تملك صلاحية الأدمن.")
        return
    if not answer.text.strip():
        await answer.reply(
            "النص لا يمكن أن يكون فارغاً.",
            reply_markup=TEMPLATES_BACK,
        )
        return
    if len(answer.text) > TEXT_LIMIT:
        await answer.reply(
            f"النص أطول من الحد المسموح ({TEXT_LIMIT} حرفاً). أعد المحاولة.",
            reply_markup=TEMPLATES_BACK,
        )
        return

    db.set(TEXT_TEMPLATES[template_id]["db_key"], answer.text)
    await answer.reply(
        "تم تحديث الكليشة بنجاح ✅",
        reply_markup=mk(
            [
                [btn("معاينة الكليشة", callback_data=f"text_template:{template_id}")],
                [btn("رجوع إلى الأقسام", callback_data="set_start")],
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"^text_reset:(start|force|member|account)$"))
async def reset_text_template(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    template_id = query.data.split(":", 1)[1]
    db.set(
        TEXT_TEMPLATES[template_id]["db_key"],
        TEXT_TEMPLATES[template_id]["default"],
    )
    await query.answer("تمت استعادة النص الافتراضي ✅")
    await _show_template_preview(
        query,
        template_id,
        notice="تمت استعادة النص الافتراضي ✅",
    )
