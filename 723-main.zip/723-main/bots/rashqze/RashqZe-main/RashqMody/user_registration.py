import time
from decimal import Decimal, InvalidOperation

from kvsqlite.sync import Client as Database

from .order_lock import ORDER_LOCK
from .points_core import open_transaction, read_value, write_value


db = Database("data.sqlite", "fuck")
MAX_POINTS = Decimal("1000000000")
DEFAULT_INVITE_REWARD = Decimal("0.1")


def _invite_reward(connection):
    stored = read_value(connection, "invite_price")
    try:
        reward = Decimal(str(stored or DEFAULT_INVITE_REWARD))
    except (InvalidOperation, TypeError, ValueError):
        return None
    if not reward.is_finite() or reward <= 0 or reward > MAX_POINTS:
        return None
    return reward


async def register_user(user_id, referrer_id=None):
    user_id = int(user_id)
    if user_id < 1:
        raise ValueError("user_id_must_be_positive")
    try:
        referrer_id = int(referrer_id) if referrer_id is not None else None
    except (TypeError, ValueError):
        referrer_id = None

    async with ORDER_LOCK:
        connection = open_transaction()
        try:
            user_key = f"user_{user_id}"
            if read_value(connection, user_key) is not None:
                connection.commit()
                return False, Decimal("0"), None

            profile = {
                "coins": 0.2,
                "id": user_id,
                "premium": False,
                "admin": False,
                "phone": [],
                "users": [],
                "date": str(time.time()),
            }
            write_value(connection, user_key, profile)

            reward = Decimal("0")
            referrer_balance = None
            if referrer_id and referrer_id != user_id:
                referrer_key = f"user_{referrer_id}"
                referrer = read_value(connection, referrer_key)
                if isinstance(referrer, dict):
                    referred_users = referrer.get("users")
                    if not isinstance(referred_users, list):
                        referred_users = []
                    if user_id not in referred_users:
                        proposed_reward = _invite_reward(connection)
                        try:
                            current = Decimal(str(referrer.get("coins")))
                        except (InvalidOperation, TypeError, ValueError):
                            current = None
                        if (
                            proposed_reward is not None
                            and current is not None
                            and current.is_finite()
                            and 0 <= current <= MAX_POINTS
                            and current + proposed_reward <= MAX_POINTS
                        ):
                            referred_users.append(user_id)
                            referrer["users"] = referred_users
                            current += proposed_reward
                            referrer["coins"] = float(current)
                            write_value(connection, referrer_key, referrer)
                            reward = proposed_reward
                            referrer_balance = current

            connection.commit()
            return True, reward, referrer_balance
        except Exception:
            if connection.in_transaction:
                connection.rollback()
            raise
        finally:
            connection.close()
