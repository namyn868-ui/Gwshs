import re
from decimal import Decimal, InvalidOperation
from urllib.parse import urlsplit

from pyrogram import Client as app, filters
from pyrogram import Client as temp
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import time
from kvsqlite.sync import Client
from .navigation import ask_with_back, clear_section_message
from .manage_texts import show_text_manager

db = Client("data.sqlite", 'fuck')
ADMIN_BACK = mk([[btn("رجوع", callback_data="back_admin")]])


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


async def _require_admin(query):
    if _is_admin(query.from_user.id):
        return True
    await query.answer("هذا الإجراء مخصص للأدمن فقط.", show_alert=True)
    return False


def _parse_positive_decimal(text):
    value = (text or "").strip()
    if not re.fullmatch(r"\d{1,10}(?:\.\d{1,4})?", value):
        raise ValueError("أرسل رقماً موجباً حتى 4 منازل عشرية.")
    try:
        amount = Decimal(value)
    except InvalidOperation as error:
        raise ValueError("القيمة غير صحيحة.") from error
    if not amount.is_finite() or amount <= 0 or amount > Decimal("1000000000"):
        raise ValueError("القيمة خارج الحدود المسموحة.")
    return amount


def _normalize_provider_domain(text):
    value = (text or "").strip()
    if not value:
        raise ValueError("أرسل نطاقاً صحيحاً.")
    candidate = value if "://" in value else f"https://{value}"
    try:
        parsed = urlsplit(candidate)
        port = parsed.port
    except ValueError as error:
        raise ValueError("النطاق غير صحيح.") from error
    if (
        parsed.scheme.casefold() != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.path not in {"", "/"}
        or parsed.query
        or parsed.fragment
        or not re.fullmatch(
            r"(?i)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?(?::\d{1,5})?",
            parsed.netloc,
        )
        or (port is not None and not 1 <= port <= 65535)
    ):
        raise ValueError("أرسل نطاق HTTPS فقط، دون مسار أو بيانات إضافية.")
    return parsed.netloc

@app.on_callback_query(filters.regex("^set_start$"), group=14)
async def startmsg(app, query):
    await show_text_manager(app, query)
@app.on_callback_query(filters.regex("^set_api$"), group=14)
async def setapi(app, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    code = "api_key"
    current_key = str(db.get(code) or "")
    key_preview = (
        "مضبوط"
        if current_key
        else "لا يوجد"
    )
    ask2 = await ask_with_back(
        app,
        user_id,
        f"• مفتاح API الحالي : `{key_preview}`\n\n• ارسل api جديد :",
        "back_admin",
    )
    if not ask2:
        return
    new_key = (ask2.text or "").strip()
    if not new_key or len(new_key) > 512:
        await ask2.reply("مفتاح API غير صالح.", reply_markup=ADMIN_BACK)
        return
    db.set("api_key", new_key)
    await ask2.reply("تم تعيين مفتاح API بنجاح ✅", reply_markup=ADMIN_BACK)
@app.on_callback_query(filters.regex("^id_service$"), group=14)
async def id(app, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    code = "id_service"
    np = db.get(code)
    if np is None:
        np = "لا يوجد"
    else:
        np = db.get(code)
    ask2 = await ask_with_back(app, user_id, f'• ايدي الخدمة الحالي : `{np}`\n\n• ارسل اي دي الخدمة الجديد', "back_admin")
    if not ask2:
        return
    if ask2.text:
        try:
            value = (ask2.text or "").strip()
            if not re.fullmatch(r"\d{1,20}", value) or int(value) < 1:
                raise ValueError("invalid service id")
            service_id = int(value)
            db.set("id_service", service_id)
            db.set("member_service_id", service_id)
            await ask2.reply(f"**تم تعيين ايدي الخدمة بنجاح ✅**", reply_markup=ADMIN_BACK)
        except ValueError:
            await ask2.reply("أرسل معرف خدمة رقمي صحيح.", reply_markup=ADMIN_BACK)
            return
@app.on_callback_query(filters.regex("^set_domain$"), group=14)
async def dom(app, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    code = "set_domain"
    np = db.get(code)
    if np is None:
        np = "لا يوجد"
    else:
        np = db.get(code)
    ask2 = await ask_with_back(app, user_id, f'• الدومين الحالي : `{np}`\n\n• ارسل الكليشة الجديدة', "back_admin")
    if not ask2:
        return
    if ask2.text:
        try:
            domain = _normalize_provider_domain(ask2.text)
        except ValueError as error:
            await ask2.reply(str(error), reply_markup=ADMIN_BACK)
            return
        try:
            db.set("set_domain", domain)
            await ask2.reply(f"**تم تعيين الدومين بنجاح ✅**", reply_markup=ADMIN_BACK)
        except Exception:
            await ask2.reply("تعذر حفظ النطاق حالياً.", reply_markup=ADMIN_BACK)
            return
@app.on_callback_query(filters.regex("^invite_coin$"), group=14)
async def invit(app, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    code = "invite_price"
    np = 1 if not db.get(code) else db.get(code)
    ask2 = await ask_with_back(app, user_id, f'• سعر كل دعوة : `{np}`$\n\n• ارسل السعر الجديد , يمكنك ارسال رقم عشري', "back_admin")
    if not ask2:
        return
    if ask2.text:
        try:
            amount = _parse_positive_decimal(ask2.text)
            db.set("invite_price", float(amount))
            await ask2.reply("تم تعيين السعر بنجاح", reply_markup=ADMIN_BACK)
        except ValueError as error:
            await ask2.reply(str(error), reply_markup=ADMIN_BACK)
            return
@app.on_callback_query(filters.regex("^transfer$"), group=14)
async def trans(app, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    code = "transfer"
    np = 100 if not db.get(code) else db.get(code)
    ask2 = await ask_with_back(app, user_id, f'• الحد الادني من التحويل : `{np}`$\n\n• ارسل الحد الادني الجديد', "back_admin")
    if not ask2:
        return
    if ask2.text:
        try:
            value = (ask2.text or "").strip()
            if not re.fullmatch(r"\d{1,10}", value) or int(value) < 1:
                raise ValueError("invalid transfer minimum")
            db.set("transfer", int(value))
            await ask2.reply(f"**تم تعيين الحد الادني بنجاح ✅**", reply_markup=ADMIN_BACK)
        except ValueError:
            await ask2.reply("أرسل حداً أدنى صحيحاً أكبر من صفر.", reply_markup=ADMIN_BACK)
            return
@app.on_callback_query(filters.regex("^member_price$"), group=14)
async def memb(app, query):
    if not await _require_admin(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    code = "member_price_per_1000"
    current = db.get(code)
    if current is None:
        current = float(db.get("member_price") or 0.2) * 1000
    ask2 = await ask_with_back(app, user_id, f'• السعر الحالي لكل 1000 عضو : `{current}`$\n\n• ارسل السعر الجديد لكل 1000 عضو، ويمكنك إرسال رقم عشري', "back_admin")
    if not ask2:
        return
    if ask2.text:
        try:
            price_per_1000 = _parse_positive_decimal(ask2.text)
            db.set(code, float(price_per_1000))
            db.set("member_price", float(price_per_1000 / 1000))
            await ask2.reply("تم تعيين السعر بنجاح", reply_markup=ADMIN_BACK)
        except ValueError as error:
            await ask2.reply(str(error), reply_markup=ADMIN_BACK)
            return
@app.on_callback_query(filters.regex("^force_msg$"), group=14)
async def forcemsk(app, query):
    await show_text_manager(app, query)