from kvsqlite.sync import Client as Database
from pyrogram import Client as app, StopPropagation, filters
from pyrogram.enums import ChatType
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk


db = Database("data.sqlite", "fuck")


def _enabled(key):
    value = db.get(key)
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip().casefold() not in {"", "0", "false", "off", "no"}
    return bool(value)


def entry_notifications_enabled():
    return _enabled("entry_notifications_enabled")


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def admin_dashboard_keyboard():
    bot_status = "✅" if _enabled("bot_enabled") else "❌"
    notification_status = "✅" if entry_notifications_enabled() else "❌"
    return mk(
        [
            [
                btn(f"🤖 البوت: {bot_status}", callback_data="toggle_bot"),
                btn(
                    f"🔔 تنبيهات الدخول: {notification_status}",
                    callback_data="toggle_entry_notifications",
                ),
            ],
            [
                btn("📝 النصوص", "set_start"),
                btn("📢 الاشتراك الإجباري", "setforce"),
            ],
            [
                btn("🛡️ الأدمنية", "admins_bot"),
                btn("📊 الإحصائيات", "stats"),
            ],
            [
                btn("👥 المستخدمون والحظر", callback_data="admin_users"),
                btn("📣 الإذاعة", "brods"),
            ],
            [btn("⚙️ إعدادات البوت", "setting_bot")],
        ]
    )


async def _update_toggle(query, key, label):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    enabled = not _enabled(key)
    db.set(key, enabled)
    state = "تم تشغيل" if enabled else "تم إيقاف"
    await query.answer(f"{state} {label}.")
    if query.message is not None:
        await query.edit_message_reply_markup(
            reply_markup=admin_dashboard_keyboard()
        )


@app.on_callback_query(filters.regex(r"^toggle_bot$"))
async def toggle_bot(client, query):
    await _update_toggle(query, "bot_enabled", "البوت للمستخدمين")


@app.on_callback_query(filters.regex(r"^toggle_entry_notifications$"))
async def toggle_entry_notifications(client, query):
    await _update_toggle(
        query,
        "entry_notifications_enabled",
        "إشعارات دخول الأعضاء",
    )


@app.on_message(filters.private, group=-101)
async def pause_user_messages(client, message):
    user = message.from_user
    if not user or _enabled("bot_enabled") or _is_admin(user.id):
        return

    await message.reply_text("البوت متوقف مؤقتاً. يرجى المحاولة لاحقاً.")
    raise StopPropagation


@app.on_callback_query(group=-101)
async def pause_user_callbacks(client, query):
    if (
        not query.from_user
        or not query.message
        or query.message.chat.type != ChatType.PRIVATE
        or _enabled("bot_enabled")
        or _is_admin(query.from_user.id)
    ):
        return

    await query.answer("البوت متوقف مؤقتاً. يرجى المحاولة لاحقاً.", show_alert=True)
    raise StopPropagation
