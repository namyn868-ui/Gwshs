import asyncio
import logging
import re
import time
import uuid
from decimal import Decimal, InvalidOperation
from html import escape
from urllib.parse import urlparse

import requests
from kvsqlite.sync import Client as Database
from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
from .navigation import ask_with_back, clear_section_message
from .order_lock import ORDER_LOCK
from .order_status import register_provider_order
from .service_switches import _enabled as service_switch_enabled

db = Database("data.sqlite", "fuck")
logger = logging.getLogger(__name__)
HOME_BACK = mk([[btn("رجوع", callback_data="back")]])
ADMIN_BACK = mk([[btn("رجوع", callback_data="engage_admin")]])
CATALOG_KEY = "engagement_services"
SERVICE_CATEGORIES = {
    "views": "مشاهدات المنشورات",
    "reactions": "تفاعلات الإيموجي",
}
MAX_SERVICES = 30
ORDER_FLOW_TTL_SECONDS = 1800


def _catalog():
    services = db.get(CATALOG_KEY)
    if not isinstance(services, list):
        return []
    return [service for service in services if isinstance(service, dict)]


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def _find_service(service_id):
    for service in _catalog():
        if service.get("id") == service_id and service.get("enabled", True):
            return service
    return None


def _order_flow_key(user_id):
    return f"engagement_pending_{user_id}"


async def _begin_order_flow(user_id, service):
    async with ORDER_LOCK:
        key = _order_flow_key(user_id)
        existing = db.get(key)
        if isinstance(existing, dict):
            status = existing.get("status")
            if (
                status == "collecting"
                and time.time() - float(existing.get("created_at", 0))
                > ORDER_FLOW_TTL_SECONDS
            ):
                db.delete(key)
            elif (
                status == "completed"
                and time.time() - float(existing.get("completed_at", 0)) < 5
            ):
                return None
            elif status in {"collecting", "submitting", "unknown"}:
                return None

        token = uuid.uuid4().hex
        db.set(
            key,
            {
                "token": token,
                "status": "collecting",
                "service_id": service["id"],
                "service_name": service["name"],
                "created_at": time.time(),
            },
        )
        return token


def _update_order_flow(user_id, token, status, **updates):
    key = _order_flow_key(user_id)
    state = db.get(key)
    if not isinstance(state, dict) or state.get("token") != token:
        return False
    state.update(updates)
    state["status"] = status
    db.set(key, state)
    return True


def _clear_order_flow(user_id, token):
    key = _order_flow_key(user_id)
    state = db.get(key)
    if (
        isinstance(state, dict)
        and state.get("token") == token
        and state.get("status") == "collecting"
    ):
        db.delete(key)


def _parse_post_link(value):
    link = (value or "").strip()
    if not link:
        return None
    if not link.startswith(("https://", "http://")):
        link = "https://" + link
    parsed = urlparse(link)
    if parsed.scheme not in {"https", "http"}:
        return None
    if (parsed.hostname or "").lower() not in {"t.me", "telegram.me"}:
        return None

    parts = [part for part in parsed.path.split("/") if part]
    if len(parts) == 3 and parts[0] == "c":
        valid_path = parts[1].isdigit() and parts[2].isdigit()
    elif len(parts) == 3 and parts[0] == "s":
        valid_path = bool(re.fullmatch(r"[A-Za-z0-9_]{4,}", parts[1])) and parts[2].isdigit()
    else:
        valid_path = (
            len(parts) == 2
            and bool(re.fullmatch(r"[A-Za-z0-9_]{4,}", parts[0]))
            and parts[1].isdigit()
        )
    return link if valid_path else None


def _admin_panel_text():
    services = _catalog()
    lines = ["<b>إدارة خدمات المشاهدات والتفاعلات</b>"]
    if not services:
        lines.append("لا توجد خدمات مضافة بعد.")
    else:
        for service in services:
            category = SERVICE_CATEGORIES.get(service.get("category"), "خدمة")
            name = escape(str(service.get("name", "بدون اسم")))
            lines.append(
                f"#{service.get('id')} — {category}: {name}\n"
                f"معرّف المزود: {service.get('provider_service_id')} | "
                f"السعر لكل 1000: {service.get('price_per_1000')}"
            )
    return "\n".join(lines)


def _admin_panel_keyboard():
    services = _catalog()
    rows = [
        [
            btn("➕ إضافة مشاهدات", callback_data="engage_add:views"),
            btn("➕ إضافة تفاعلات", callback_data="engage_add:reactions"),
        ]
    ]
    for service in services:
        name = str(service.get("name", "خدمة"))
        rows.append(
            [
                btn(
                    f"🗑️ حذف #{service.get('id')} {name[:20]}",
                    callback_data=f"engage_delete:{service.get('id')}",
                )
            ]
        )
    rows.append([btn("↩️ رجوع للإعدادات", callback_data="setting_bot")])
    return mk(rows)


async def _show_admin_panel(query):
    await query.edit_message_text(
        _admin_panel_text(),
        reply_markup=_admin_panel_keyboard(),
        parse_mode=enums.ParseMode.HTML,
    )


async def _show_category(client, query, category):
    if not db.get("set_domain") or not db.get("api_key"):
        await query.edit_message_text(
            "خدمة الطلبات غير مهيأة حالياً.",
            reply_markup=HOME_BACK,
        )
        return

    services = [
        service
        for service in _catalog()
        if service.get("category") == category and service.get("enabled", True)
    ]
    if not services:
        await query.edit_message_text(
            f"لا توجد خيارات متاحة في قسم {SERVICE_CATEGORIES[category]} حالياً.",
            reply_markup=mk(
                [[btn("رجوع", callback_data="engagement_home")]]
            ),
        )
        return

    rows = []
    for service in services:
        name = str(service.get("name", "خدمة"))[:36]
        rows.append(
            [
                btn(
                    name,
                    callback_data=f"engage_service:{service['id']}",
                )
            ]
        )
    rows.append([btn("رجوع", callback_data="engagement_home")])
    await query.edit_message_text(
        f"اختر الخدمة من قسم {SERVICE_CATEGORIES[category]}:",
        reply_markup=mk(rows),
    )


@app.on_callback_query(filters.regex(r"^engagement_home$"))
async def engagement_home(client, query):
    await query.edit_message_text(
        "اختر نوع الخدمة:",
        reply_markup=mk(
            [
                [
                    btn("مشاهدات المنشورات", callback_data="engage_category:views"),
                    btn("تفاعلات الإيموجي", callback_data="engage_category:reactions"),
                ],
                [btn("رجوع", callback_data="back")],
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"^engage_category:(views|reactions)$"))
async def show_engagement_category(client, query):
    category = query.data.rsplit(":", 1)[1]
    await _show_category(client, query, category)


@app.on_callback_query(filters.regex(r"^engage_admin$"))
async def manage_engagement_services(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("غير مصرح لك باستخدام لوحة الإدارة", show_alert=True)
        return
    await _show_admin_panel(query)


@app.on_callback_query(filters.regex(r"^engage_add:(views|reactions)$"))
async def add_engagement_service(client, query):
    user_id = query.from_user.id
    if not _is_admin(user_id):
        await query.answer("غير مصرح لك باستخدام لوحة الإدارة", show_alert=True)
        return
    if len(_catalog()) >= MAX_SERVICES:
        await query.answer(f"الحد الأقصى هو {MAX_SERVICES} خدمة", show_alert=True)
        return

    category = query.data.rsplit(":", 1)[1]
    await clear_section_message(query)
    prompts = [
        ("أرسل اسم الخيار الذي سيظهر للمستخدمين (أو /cancel للإلغاء):", "name"),
        ("أرسل معرّف الخدمة من لوحة المزود:", "provider_service_id"),
        ("أرسل السعر لكل 1000 مشاهدة أو تفاعل:", "price_per_1000"),
        ("أرسل أقل كمية يسمح بها المزود:", "min_quantity"),
        ("أرسل أعلى كمية يسمح بها المزود:", "max_quantity"),
    ]
    answers = {}
    for prompt, key in prompts:
        message = await ask_with_back(
            client,
            user_id,
            prompt,
            "engage_admin",
            filters=filters.user(user_id),
        )
        if not message or not message.text:
            return
        value = message.text.strip()
        if value.lower() == "/cancel":
            await message.reply("تم إلغاء إضافة الخدمة.", reply_markup=ADMIN_BACK)
            return
        answers[key] = value

    name = answers["name"]
    if not 2 <= len(name) <= 40:
        await message.reply("اسم الخدمة يجب أن يكون بين حرفين و40 حرفاً.", reply_markup=ADMIN_BACK)
        return
    try:
        provider_service_id = int(answers["provider_service_id"])
        price_per_1000 = Decimal(answers["price_per_1000"].replace(",", "."))
        min_quantity = int(answers["min_quantity"])
        max_quantity = int(answers["max_quantity"])
    except (ValueError, InvalidOperation):
        await message.reply("تأكد من إرسال أرقام صحيحة للسعر والكمية والمعرّف.", reply_markup=ADMIN_BACK)
        return
    if (
        provider_service_id <= 0
        or not price_per_1000.is_finite()
        or price_per_1000 <= 0
        or price_per_1000 > Decimal("1000000")
    ):
        await message.reply(
            "معرّف الخدمة غير صالح، أو السعر خارج النطاق المسموح.",
            reply_markup=ADMIN_BACK,
        )
        return
    if min_quantity <= 0 or max_quantity < min_quantity or max_quantity > 100_000_000:
        await message.reply("تحقق من الحد الأدنى والأعلى للكمية.", reply_markup=ADMIN_BACK)
        return

    services = _catalog()
    next_id = max((int(service.get("id", 0)) for service in services), default=0) + 1
    services.append(
        {
            "id": next_id,
            "category": category,
            "name": name,
            "provider_service_id": provider_service_id,
            "price_per_1000": float(price_per_1000),
            "min_quantity": min_quantity,
            "max_quantity": max_quantity,
            "enabled": True,
        }
    )
    db.set(CATALOG_KEY, services)
    await message.reply(
        f"تمت إضافة الخدمة {escape(name)} بنجاح.",
        parse_mode=enums.ParseMode.HTML,
        reply_markup=ADMIN_BACK,
    )
    await _show_admin_panel(query)


@app.on_callback_query(filters.regex(r"^engage_delete:(\d+)$"))
async def delete_engagement_service(client, query):
    user_id = query.from_user.id
    if not _is_admin(user_id):
        await query.answer("غير مصرح لك باستخدام لوحة الإدارة", show_alert=True)
        return
    service_id = int(query.data.rsplit(":", 1)[1])
    service = next(
        (item for item in _catalog() if item.get("id") == service_id),
        None,
    )
    if not service:
        await query.answer("الخدمة غير موجودة", show_alert=True)
        return

    await clear_section_message(query)
    message = await ask_with_back(
        client,
        user_id,
        f"حذف الخدمة رقم #{service_id}؟ أرسل /yes للتأكيد أو /cancel للإلغاء.",
        "engage_admin",
        filters=filters.user(user_id),
    )
    if not message or not message.text or message.text.strip().lower() != "/yes":
        if message:
            await message.reply("لم يتم حذف الخدمة.", reply_markup=ADMIN_BACK)
        return

    remaining = [
        item for item in _catalog()
        if item.get("id") != service_id
    ]
    db.set(CATALOG_KEY, remaining)
    await message.reply("تم حذف الخدمة.", reply_markup=ADMIN_BACK)
    await _show_admin_panel(query)


async def _place_provider_order(service, quantity, link):
    domain = str(db.get("set_domain") or "").strip()
    domain = domain.removeprefix("https://").removeprefix("http://").strip("/")
    api_key = str(db.get("api_key") or "").strip()
    if not domain or not api_key:
        raise RuntimeError("provider_not_configured")

    response = await asyncio.to_thread(
        requests.get,
        f"https://{domain}/api/v2",
        params={
            "key": api_key,
            "action": "add",
            "service": service["provider_service_id"],
            "quantity": quantity,
            "link": link,
        },
        timeout=30,
    )
    response.raise_for_status()
    result = response.json()
    if (
        not isinstance(result, dict)
        or result.get("error")
        or not result.get("order")
    ):
        raise ValueError("provider_rejected_order")
    return result["order"]


@app.on_callback_query(filters.regex(r"^engage_service:(\d+)$"))
async def order_engagement_service(client, query):
    user_id = query.from_user.id

    service_id = int(query.data.rsplit(":", 1)[1])
    service = _find_service(service_id)
    if not service:
        await query.answer("الخدمة لم تعد متاحة", show_alert=True)
        return
    if not db.get("set_domain") or not db.get("api_key"):
        await query.edit_message_text(
            "خدمة الطلبات غير مهيأة حالياً.",
            reply_markup=HOME_BACK,
        )
        return
    if not db.exists(f"user_{user_id}"):
        await query.edit_message_text(
            "أرسل /start أولاً لإنشاء حسابك.",
            reply_markup=HOME_BACK,
        )
        return

    flow_token = await _begin_order_flow(user_id, service)
    if not flow_token:
        await query.answer(
            "لديك طلب سابق قيد الإكمال أو المراجعة. لا ترسل طلباً مكرراً.",
            show_alert=True,
        )
        return
    await query.answer()

    await clear_section_message(query)
    quantity_message = await ask_with_back(
        client,
        user_id,
        f"{service['name']}\nأرسل الكمية بين {service['min_quantity']} و"
        f"{service['max_quantity']}، أو /cancel للإلغاء.",
        "back",
        filters=filters.user(user_id),
    )
    if not quantity_message or not quantity_message.text:
        _clear_order_flow(user_id, flow_token)
        return
    raw_quantity = quantity_message.text.strip()
    if raw_quantity.lower() == "/cancel":
        _clear_order_flow(user_id, flow_token)
        await quantity_message.reply("تم إلغاء الطلب.", reply_markup=HOME_BACK)
        return
    try:
        quantity = int(raw_quantity)
    except ValueError:
        _clear_order_flow(user_id, flow_token)
        await quantity_message.reply("أرسل كمية رقمية صحيحة.", reply_markup=HOME_BACK)
        return
    if not service["min_quantity"] <= quantity <= service["max_quantity"]:
        _clear_order_flow(user_id, flow_token)
        await quantity_message.reply(
            f"الكمية يجب أن تكون بين {service['min_quantity']} و"
            f"{service['max_quantity']}.",
            reply_markup=HOME_BACK,
        )
        return

    link_message = await ask_with_back(
        client,
        user_id,
        "أرسل رابط المنشور على تيليجرام (أو /cancel للإلغاء).",
        "back",
        filters=filters.user(user_id),
    )
    if not link_message or not link_message.text:
        _clear_order_flow(user_id, flow_token)
        return
    raw_link = link_message.text.strip()
    if raw_link.lower() == "/cancel":
        _clear_order_flow(user_id, flow_token)
        await link_message.reply("تم إلغاء الطلب.", reply_markup=HOME_BACK)
        return
    post_link = _parse_post_link(raw_link)
    if not post_link:
        _clear_order_flow(user_id, flow_token)
        await link_message.reply(
            "الرابط غير صالح. أرسل رابط منشور يتضمن رقم الرسالة.",
            reply_markup=HOME_BACK,
        )
        return

    try:
        price_per_1000 = Decimal(str(service["price_per_1000"]))
        cost = (Decimal(quantity) * price_per_1000 / Decimal(1000)).quantize(
            Decimal("0.000001")
        )
        if not cost.is_finite() or cost <= 0:
            raise InvalidOperation
    except (InvalidOperation, KeyError, TypeError, ValueError):
        _clear_order_flow(user_id, flow_token)
        await link_message.reply(
            "تعذر حساب تكلفة الخدمة. يرجى إبلاغ الأدمن.",
            reply_markup=HOME_BACK,
        )
        return

    confirmation = await ask_with_back(
        client,
        user_id,
        f"تأكيد طلب {service['name']}\n"
        f"الكمية: {quantity}\n"
        "أرسل /ok للتأكيد أو /cancel للإلغاء.",
        "back",
        filters=filters.user(user_id),
    )
    if not confirmation or not confirmation.text:
        _clear_order_flow(user_id, flow_token)
        return
    if confirmation.text.strip().lower() != "/ok":
        _clear_order_flow(user_id, flow_token)
        await confirmation.reply("تم إلغاء الطلب.", reply_markup=HOME_BACK)
        return

    async with ORDER_LOCK:
        if not service_switch_enabled("engagement"):
            _clear_order_flow(user_id, flow_token)
            await confirmation.reply(
                "تم إيقاف الخدمة قبل تأكيد الطلب.",
                reply_markup=HOME_BACK,
            )
            return
        user_info = db.get(f"user_{user_id}") or {}
        try:
            balance = Decimal(str(user_info.get("coins", 0)))
        except (InvalidOperation, TypeError, ValueError):
            balance = Decimal("0")
        if not balance.is_finite() or balance < cost:
            _clear_order_flow(user_id, flow_token)
            await confirmation.reply("رصيدك لا يكفي لإتمام هذا الطلب.", reply_markup=HOME_BACK)
            return
        if not _update_order_flow(
            user_id,
            flow_token,
            "submitting",
            quantity=quantity,
            target=post_link,
            cost=str(cost),
            updated_at=time.time(),
        ):
            await confirmation.reply(
                "تعذر التحقق من حالة الطلب. لم يتم إرسال طلب جديد.",
                reply_markup=HOME_BACK,
            )
            return

        try:
            order_id = await _place_provider_order(service, quantity, post_link)
        except Exception as error:
            _update_order_flow(
                user_id,
                flow_token,
                "unknown",
                unknown_at=time.time(),
                provider_error_type=type(error).__name__,
            )
            logger.warning(
                "Engagement service provider request failed (%s)",
                type(error).__name__,
            )
            await confirmation.reply(
                "تعذر تأكيد نتيجة الطلب من المزوّد. قد يكون الطلب قد وصل إليه؛ "
                "لا تعاود الإرسال وتواصل مع الأدمن للمراجعة. لم يتم خصم نقاط.",
                reply_markup=HOME_BACK,
            )
            return

        user_info["coins"] = float(balance - cost)
        db.set(f"user_{user_id}", user_info)
        buys_key = f"user_{user_id}_buys"
        buys = int(db.get(buys_key) or 0) + 1
        db.set(buys_key, buys)
        register_provider_order(
            order_id,
            user_id,
            service["name"],
            quantity=quantity,
            target=post_link,
        )
        _update_order_flow(
            user_id,
            flow_token,
            "completed",
            completed_at=time.time(),
        )

    await confirmation.reply(
        f"تم تسجيل طلب {service['name']} بنجاح.\n"
        f"معرّف الطلب: <code>{escape(str(order_id))}</code>\n"
        "الحالة: قيد الانتظار\n"
        f"الخدمة: {escape(str(service['name']))}\n"
        f"الكمية: {quantity}",
        parse_mode=enums.ParseMode.HTML,
        reply_markup=HOME_BACK,
    )
