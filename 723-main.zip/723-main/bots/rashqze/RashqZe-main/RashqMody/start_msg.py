from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import time
import pyrogram.errors
from kvsqlite.sync import Client as xxx
from  pyrogram.enums import ChatMemberStatus
from kvsqlite.sync import Client as mody
from .agents import is_active_agent
from .bot_channel import get_bot_channel_url
from .text_templates import get_template, render_template
db = mody("data.sqlite", 'fuck')

@app.on_message(filters.private & filters.regex("^/start$"), group=5)
async def startm(app, msg):
    user_id = msg.from_user.id
    if db.get("ban_list") is None:
        db.set('ban_list', [])
        pass
    if user_id in db.get("ban_list"):
        return
    if is_active_agent(user_id) and not db.exists(f"user_{user_id}"):
        db.set(
            f"user_{user_id}",
            {
                "coins": 0,
                "id": user_id,
                "premium": False,
                "admin": False,
                "phone": [],
                "users": [],
                "date": str(time.time()),
            },
        )
    if db.exists(f"user_{user_id}"):
        coin = float(db.get(f'user_{user_id}')['coins'])
        start_template = get_template("start")
        start_text = render_template("start", user_id, user=msg.from_user)
        if "[id]" not in start_template.lower():
            start_text += (
                f"\n⌁︙الايدي الخاص بك ↫⤈\n"
                f"ID : {user_id}"
            )
        keys = mk(
        [
            [btn(text=f' رصيدك : {coin} $ ', callback_data='lol')],
            [btn(text=' طلب رشق اعضاء ', callback_data='member')],
            [
                btn(text='المشاهدات والتفاعلات', callback_data='engagement_home'),
                btn(text=' تجميع النقاط ', callback_data='collect_points'),
            ],
            [btn(text='معلومات حسابك', callback_data='account'), btn(text=' تحويل رصيد ', callback_data='tran')],
            [
                btn(text='معلومات الطلب', callback_data='id_requests'),
                (
                    btn(text='قناة البوت', url=get_bot_channel_url())
                    if get_bot_channel_url()
                    else btn(text='قناة البوت', callback_data='bot_channel_missing')
                ),
            ],
        ]
    )
        if is_active_agent(user_id):
            keys.inline_keyboard.append(
                [btn(text="لوحة تحكم الوكيل 🛡️", callback_data="agent_panel")]
            )
        await app.send_message(
            user_id,
            start_text,
            reply_markup=keys,
            parse_mode=enums.ParseMode.HTML,
        )
    else:
        keys = mk(
        [
            [btn(text='اضغط هنا للتحقق', callback_data='send_code')], 
        ]
    )
        rk =f'''︎• **مرحبا بك {msg.from_user.mention} في بوت رشق الفراعنة**

• **بما انك عضو جديد في البوت ينبغي التحقق من انك لست روبوت ، رجاء اضغط علي الزر بالاسفل'''
        await app.send_message(msg.from_user.id,rk, reply_markup=keys)

@app.on_callback_query(filters.regex("^back_invite$"))
async def back_to_verification(client, query):
    await query.edit_message_text(
        "ارجع إلى خطوة التحقق، واضغط الزر للبدء من جديد.",
        reply_markup=mk([[btn(text="التحقق", callback_data="send_code")]]),
    )
