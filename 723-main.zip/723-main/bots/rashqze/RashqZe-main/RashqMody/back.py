from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import time
from kvsqlite.sync import Client as mody
from .bot_channel import get_bot_channel_url
from .text_templates import get_template, render_template
db = mody("data.sqlite", 'fuck')

@app.on_callback_query(filters.regex("^back$"))
async def dailygiftt(app,query):
    user_id = query.from_user.id
    coin = float(db.get(f'user_{user_id}')['coins'])
    start_template = get_template("start")
    start_text = render_template("start", user_id, user=query.from_user)
    if "[id]" not in start_template.lower():
        start_text += f"\n⌁︙الايدي الخاص بك ↫⤈\nID : {user_id}"
    keys = mk(
        [
            [btn(text=f' رصيدك : {coin} $ ', callback_data='lol')],
            [btn(text=' طلب رشق اعضاء ', callback_data='member')],
            [
                btn(text='المشاهدات والتفاعلات', callback_data='engagement_home'),
                btn(text=' تجميع النقاط ', callback_data='collect_points'),
            ],
            [btn(text='معلومات حسابك', callback_data='account'), btn(text=' تحويل رصيد ', callback_data='tran')],
            [
                btn(text='معلومات الطلب', callback_data='id_requests'),
                (
                    btn(text='قناة البوت', url=get_bot_channel_url())
                    if get_bot_channel_url()
                    else btn(text='قناة البوت', callback_data='bot_channel_missing')
                ),
            ],
        ]
    )
    await query.edit_message_text(
        start_text,
        reply_markup=keys,
        parse_mode=enums.ParseMode.HTML,
    )
