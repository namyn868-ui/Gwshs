import asyncio

from pyrogram import Client as app, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pyromod.types import ListenerTypes


async def clear_section_message(query):
    """Remove the current menu before a section starts a message-based flow."""
    await query.answer()
    if query.message is not None:
        await query.message.delete()


async def ask_with_back(client, chat_id, text, back_callback, filters=None, **kwargs):
    """Wait for a message while providing an inline button that cancels the wait."""
    prompt = await client.send_message(
        chat_id,
        text,
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("رجوع", callback_data="nav_back")]]
        ),
        **kwargs,
    )

    message_task = asyncio.create_task(
        client.listen(
            filters=filters,
            listener_type=ListenerTypes.MESSAGE,
            chat_id=chat_id,
            user_id=chat_id,
        )
    )
    back_task = asyncio.create_task(prompt.wait_for_click(from_user_id=chat_id))
    try:
        done, _ = await asyncio.wait(
            {message_task, back_task},
            return_when=asyncio.FIRST_COMPLETED,
        )

        if back_task in done and message_task not in done:
            callback = back_task.result()
            await callback.answer("تم إلغاء الإدخال.")
            await prompt.edit_text(
                "تم إلغاء الإدخال. اضغط زر الرجوع للمتابعة.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("رجوع", callback_data=back_callback)]]
                ),
            )
            return None

        answer = message_task.result()
        if not answer:
            return None

        answer.sent_message = prompt
        if answer.text and answer.text.strip().lower() in {"رجوع", "/cancel"}:
            await prompt.edit_text(
                "تم إلغاء الإدخال. اضغط زر الرجوع للمتابعة.",
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("رجوع", callback_data=back_callback)]]
                ),
            )
            try:
                await answer.delete()
            except Exception:
                pass
            return None

        await prompt.edit_reply_markup(None)
        return answer
    finally:
        for task in (message_task, back_task):
            if not task.done():
                task.cancel()
        await asyncio.gather(message_task, back_task, return_exceptions=True)


@app.on_callback_query(filters.regex(r"^nav_back$"))
async def expired_inline_back(client, query):
    await query.answer(
        "انتهى الإدخال. استخدم زر الرجوع الظاهر في الرسالة.",
        show_alert=True,
    )
