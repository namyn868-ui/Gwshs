import logging
import re
import sqlite3
import time
from datetime import datetime
from decimal import Decimal, InvalidOperation
from html import escape
from pathlib import Path
from zoneinfo import ZoneInfo

from kvsqlite import PickleEncoder
from kvsqlite.sync import Client as Database
from pyrogram import Client as app, filters
from pyrogram.enums import ChatMemberStatus, ChatType
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from config import Config
from .navigation import ask_with_back, clear_section_message
from .order_lock import ORDER_LOCK


logger = logging.getLogger(__name__)
db = Database("data.sqlite", "fuck")
DATABASE_PATH = Path(__file__).resolve().parents[1] / "data.sqlite"
ENCODER = PickleEncoder()
MAX_POINTS = Decimal("1000000000")
LOCAL_TIMEZONE = ZoneInfo("Asia/Baghdad")
AGENT_KEY = "agent_registry"
DAILY_KEY = "agent_daily_stats"
LOG_CHAT_KEY = "agent_audit_chat_id"
LOG_CHANNEL_USERNAME_KEY = "agent_audit_channel_username"


def _get_agents():
    value = db.get(AGENT_KEY)
    return value if isinstance(value, dict) else {}


def is_active_agent(user_id):
    record = _get_agents().get(str(user_id))
    return isinstance(record, dict) and record.get("status") == "active"


def _format_amount(value):
    return format(Decimal(str(value)).normalize(), "f")


def _parse_user_id(text):
    value = (text or "").strip()
    if not re.fullmatch(r"\d{1,20}", value) or int(value) < 1:
        raise ValueError("أرسل آيدي مستخدم رقمي صحيح.")
    return int(value)


def _parse_channel_username(text):
    value = (text or "").strip()
    value = re.sub(
        r"^(?:https?://)?(?:www\.)?t\.me/",
        "",
        value,
        flags=re.IGNORECASE,
    ).strip("/")
    value = value.removeprefix("@")
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{4,31}", value):
        raise ValueError("أرسل يوزر قناة صحيحاً مثل @mychannel.")
    return value


def _parse_amount(text, allow_zero=False):
    value = (text or "").strip()
    if not re.fullmatch(r"\d{1,10}(?:\.\d{1,4})?", value):
        raise ValueError("أرسل كمية موجبة، ويمكن استخدام حتى 4 منازل عشرية.")
    try:
        amount = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError("الكمية غير صحيحة.") from exc
    if amount < 0 or (amount == 0 and not allow_zero) or amount > MAX_POINTS:
        raise ValueError("الكمية خارج الحدود المسموحة.")
    return amount


def _open_transaction():
    connection = sqlite3.connect(str(DATABASE_PATH), timeout=15, isolation_level=None)
    connection.execute("PRAGMA busy_timeout = 15000")
    connection.execute(
        'CREATE TABLE IF NOT EXISTS "fuck" '
        "(k VARCHAR(4096) PRIMARY KEY, v BLOB, expire_time INTEGER DEFAULT NULL) "
        "WITHOUT ROWID"
    )
    connection.execute("BEGIN IMMEDIATE")
    return connection


def _read_value(connection, key):
    row = connection.execute(
        'SELECT v FROM "fuck" WHERE k = ? '
        "AND (expire_time IS NULL OR expire_time > ?) LIMIT 1",
        (key, time.time()),
    ).fetchone()
    return ENCODER.decode(row[0]) if row else None


def _write_value(connection, key, value):
    connection.execute(
        'REPLACE INTO "fuck" (k, v, expire_time) VALUES (?, ?, NULL)',
        (key, ENCODER.encode(value)),
    )


def _active_agent(agents, user_id):
    record = agents.get(str(user_id))
    if not isinstance(record, dict) or record.get("status") != "active":
        return None
    return record


def _agent_keyboard():
    return mk(
        [
            [
                btn("➕ إضافة نقاط", callback_data="agent_add_points"),
                btn("➖ خصم نقاط", callback_data="agent_take_points"),
            ],
            [btn("💼 محفظتي", callback_data="agent_wallet")],
            [btn("↩️ القائمة الرئيسية", callback_data="back")],
        ]
    )


def _owner_keyboard():
    agents = _get_agents()
    visible = [
        record
        for record in agents.values()
        if isinstance(record, dict) and record.get("status") != "archived"
    ]
    log_chat_id = db.get(LOG_CHAT_KEY)
    log_username = db.get(LOG_CHANNEL_USERNAME_KEY)
    if log_chat_id:
        log_status = (
            f"مضبوطة (@{log_username})"
            if log_username
            else f"مضبوطة ({log_chat_id})"
        )
    else:
        log_status = "غير مضبوطة"
    return (
        "إدارة الوكلاء\n\n"
        f"الوكلاء المسجلون: {len(visible)}\n"
        f"قناة السجلات: {log_status}\n"
        "يجب ضبط قناة السجلات ومنح البوت صلاحية النشر قبل إجراء تحويلات."
    ), mk(
        [
            [btn("➕ إضافة وكيل", callback_data="agent_add")],
            [
                btn("💰 شحن محفظة", callback_data="agent_wallet_topup"),
                btn("✏️ تعيين الرصيد", callback_data="agent_wallet_set"),
            ],
            [
                btn("📋 قائمة الوكلاء", callback_data="agent_list:0"),
                btn("🧾 قناة السجلات", callback_data="agent_log_config"),
            ],
            [btn("↩️ رجوع للإعدادات", callback_data="setting_bot")],
        ]
    )


async def _show_owner_panel(query):
    text, keyboard = _owner_keyboard()
    await query.edit_message_text(text, reply_markup=keyboard)


async def _require_agent(query):
    if is_active_agent(query.from_user.id):
        return True
    await query.answer("هذا القسم مخصص للوكلاء الفعّالين فقط.", show_alert=True)
    return False


async def _require_owner(query):
    if query.from_user.id == Config.OWNER_ID:
        return True
    await query.answer("إدارة الوكلاء مخصصة للمالك الأساسي فقط.", show_alert=True)
    return False


async def _ask_value(client, user_id, prompt, parser, error_message):
    current_prompt = prompt
    while True:
        answer = await ask_with_back(
            client,
            user_id,
            current_prompt,
            "agent_owner" if user_id == Config.OWNER_ID else "agent_panel",
            filters=filters.user(user_id),
        )
        if not answer:
            return None
        try:
            value = parser(answer.text or "")
        except ValueError:
            for message in (getattr(answer, "sent_message", None), answer):
                if message is not None:
                    try:
                        await message.delete()
                    except Exception:
                        pass
            current_prompt = f"{prompt}\n\n{error_message}"
            continue

        for message in (getattr(answer, "sent_message", None), answer):
            if message is not None:
                try:
                    await message.delete()
                except Exception:
                    pass
        return value


def _today_key():
    return datetime.now(LOCAL_TIMEZONE).date().isoformat()


async def _transfer_points(client, agent_id, target_id, amount, add_points):
    log_chat_id = db.get(LOG_CHAT_KEY)
    if not log_chat_id:
        return "log_missing", None

    async with ORDER_LOCK:
        connection = None
        audit_sent = False
        try:
            connection = _open_transaction()
            agents = _read_value(connection, AGENT_KEY) or {}
            agent = _active_agent(agents, agent_id)
            if not agent:
                connection.rollback()
                return "not_agent", None

            user_key = f"user_{target_id}"
            user_info = _read_value(connection, user_key)
            if not isinstance(user_info, dict):
                connection.rollback()
                return "no_user", None

            wallet = Decimal(str(agent.get("wallet", "0")))
            target_balance = Decimal(str(user_info.get("coins", 0)))
            if add_points and wallet < amount:
                connection.rollback()
                return "insufficient", None
            if not add_points and target_balance < amount:
                connection.rollback()
                return "target_insufficient", None

            wallet_after = wallet - amount if add_points else wallet
            target_after = target_balance + amount if add_points else target_balance - amount
            if target_after > MAX_POINTS:
                connection.rollback()
                return "target_limit", None
            today = _today_key()
            daily = _read_value(connection, DAILY_KEY) or {}
            stats = daily.get(str(agent_id), {})
            count = int(stats.get("count", 0)) + 1 if stats.get("date") == today else 1
            operation = "إضافة نقاط" if add_points else "خصم نقاط"
            audit_text = (
                "سجل عملية وكيل\n"
                f"العملية: {operation}\n"
                f"الوكيل: {agent_id}\n"
                f"المستخدم: {target_id}\n"
                f"الكمية: {_format_amount(amount)} نقطة\n"
                f"رصيد محفظة الوكيل بعد العملية: {_format_amount(wallet_after)}"
            )

            try:
                await client.send_message(log_chat_id, audit_text)
                audit_sent = True
            except Exception:
                logger.exception("Could not send agent transaction audit")
                connection.rollback()
                return "audit_failed", None

            agent["wallet"] = _format_amount(wallet_after)
            user_info["coins"] = float(target_after)
            daily[str(agent_id)] = {"date": today, "count": count}
            _write_value(connection, AGENT_KEY, agents)
            _write_value(connection, user_key, user_info)
            _write_value(connection, DAILY_KEY, daily)
            connection.commit()
            return "ok", {
                "wallet": wallet_after,
                "target_balance": target_after,
                "operation": operation,
            }
        except Exception:
            if connection is not None:
                connection.rollback()
            logger.exception("Agent points transaction failed")
            if audit_sent:
                try:
                    await client.send_message(
                        log_chat_id,
                        f"تنبيه تصحيح: تعذر حفظ عملية الوكيل {agent_id} للمستخدم "
                        f"{target_id}. راجع قاعدة البيانات قبل أي تسوية.",
                    )
                except Exception:
                    logger.exception("Could not send agent transaction correction")
            return "error", None
        finally:
            if connection is not None:
                connection.close()


async def _change_agent_wallet(client, actor_id, agent_id, amount, mode):
    log_chat_id = db.get(LOG_CHAT_KEY)
    if not log_chat_id:
        return "log_missing", None

    async with ORDER_LOCK:
        connection = None
        try:
            connection = _open_transaction()
            agents = _read_value(connection, AGENT_KEY) or {}
            record = agents.get(str(agent_id))
            if not isinstance(record, dict) or record.get("status") == "archived":
                connection.rollback()
                return "no_agent", None

            before = Decimal(str(record.get("wallet", "0")))
            after = before + amount if mode == "topup" else amount
            if after > MAX_POINTS:
                connection.rollback()
                return "wallet_limit", None
            action = "شحن محفظة" if mode == "topup" else "تعديل رصيد المحفظة"
            audit_text = (
                "سجل تعديل محفظة وكيل\n"
                f"المنفذ: {actor_id}\n"
                f"الوكيل: {agent_id}\n"
                f"العملية: {action}\n"
                f"الرصيد السابق: {_format_amount(before)}\n"
                f"الرصيد الجديد: {_format_amount(after)}"
            )
            try:
                await client.send_message(log_chat_id, audit_text)
            except Exception:
                logger.exception("Could not send agent wallet adjustment audit")
                connection.rollback()
                return "audit_failed", None

            record["wallet"] = _format_amount(after)
            _write_value(connection, AGENT_KEY, agents)
            connection.commit()
            return "ok", after
        except Exception:
            if connection is not None:
                connection.rollback()
            logger.exception("Agent wallet adjustment failed")
            return "error", None
        finally:
            if connection is not None:
                connection.close()


async def _finish(client, chat_id, text, owner=False):
    callback = "agent_owner" if owner else "agent_panel"
    await client.send_message(
        chat_id,
        text,
        reply_markup=mk([[btn("رجوع", callback_data=callback)]]),
    )


@app.on_callback_query(filters.regex(r"^agent_panel$"))
async def agent_panel(client, query):
    if not await _require_agent(query):
        return
    await query.answer()
    await query.edit_message_text(
        "لوحة تحكم الوكيل 🛡️\n\nاختر العملية التي تريد تنفيذها.",
        reply_markup=_agent_keyboard(),
    )


@app.on_callback_query(filters.regex(r"^agent_wallet$"))
async def agent_wallet(client, query):
    if not await _require_agent(query):
        return
    agents = _get_agents()
    record = _active_agent(agents, query.from_user.id)
    daily = db.get(DAILY_KEY) or {}
    stats = daily.get(str(query.from_user.id), {})
    count = int(stats.get("count", 0)) if stats.get("date") == _today_key() else 0
    await query.answer()
    await query.edit_message_text(
        "معلومات محفظتي\n\n"
        f"رصيد النقاط: {_format_amount(record.get('wallet', '0'))}\n"
        f"العمليات اليوم: {count}",
        reply_markup=mk([[btn("رجوع للوحة الوكيل", callback_data="agent_panel")]]),
    )


async def _agent_transfer_flow(client, query, add_points):
    if not await _require_agent(query):
        return
    user_id = query.from_user.id
    await clear_section_message(query)
    target_id = await _ask_value(
        client,
        user_id,
        "أرسل آيدي المستخدم الذي تريد التعامل معه.",
        _parse_user_id,
        "الآيدي غير صحيح. أرسل أرقام الآيدي فقط.",
    )
    if target_id is None:
        return
    amount = await _ask_value(
        client,
        user_id,
        "أرسل كمية النقاط.",
        _parse_amount,
        "الكمية غير صحيحة. أرسل رقماً موجباً حتى 4 منازل عشرية.",
    )
    if amount is None:
        return

    status, result = await _transfer_points(
        client, user_id, target_id, amount, add_points
    )
    messages = {
        "log_missing": "لم تُضبط قناة السجلات بعد. يرجى مراجعة المالك.",
        "audit_failed": "تعذر تسجيل العملية في قناة الرقابة؛ لم تُنفذ أي حركة.",
        "not_agent": "حساب الوكيل غير فعّال.",
        "no_user": "لا يوجد حساب لهذا المستخدم. يجب أن يبدأ البوت أولاً عبر /start.",
        "insufficient": "رصيدك غير كافي، يرجى مراجعة المطور لشحن المحفظة.",
        "target_insufficient": "رصيد المستخدم غير كافٍ للخصم المطلوب.",
        "target_limit": "الرصيد الناتج يتجاوز الحد الأعلى المسموح.",
        "error": "تعذر إتمام العملية بأمان. لم يتم تأكيدها؛ راجع المالك.",
    }
    if status != "ok":
        await _finish(client, user_id, messages.get(status, messages["error"]))
        return

    verb = "أُضيفت" if add_points else "خُصمت"
    receipt = (
        f"تمت العملية: {verb} {_format_amount(amount)} نقطة "
        f"{'للمستخدم' if add_points else 'من المستخدم'} {target_id}.\n"
        f"رصيد المستخدم: {_format_amount(result['target_balance'])}\n"
        f"رصيد محفظتك: {_format_amount(result['wallet'])}"
    )
    await _finish(client, user_id, receipt)
    try:
        action = "إضافة" if add_points else "خصم"
        await client.send_message(
            target_id,
            f"تمت {action} {_format_amount(amount)} نقطة إلى حسابك بواسطة وكيل.\n"
            f"رصيدك الحالي: {_format_amount(result['target_balance'])}",
        )
    except Exception:
        logger.info("Could not notify the user about an agent points transaction")


@app.on_callback_query(filters.regex(r"^agent_add_points$"))
async def agent_add_points(client, query):
    await _agent_transfer_flow(client, query, True)


@app.on_callback_query(filters.regex(r"^agent_take_points$"))
async def agent_take_points(client, query):
    await _agent_transfer_flow(client, query, False)


@app.on_callback_query(filters.regex(r"^agent_owner$"))
async def agent_owner(client, query):
    if not await _require_owner(query):
        return
    await query.answer()
    await _show_owner_panel(query)


@app.on_callback_query(filters.regex(r"^agent_add$"))
async def agent_add(client, query):
    if not await _require_owner(query):
        return
    await clear_section_message(query)
    agent_id = await _ask_value(
        client,
        query.from_user.id,
        "أرسل آيدي المستخدم الذي تريد إضافته وكيلاً.",
        _parse_user_id,
        "أرسل آيدي رقمي صحيح.",
    )
    if agent_id is None:
        return
    amount = await _ask_value(
        client,
        query.from_user.id,
        "أرسل رصيد المحفظة الابتدائي.",
        lambda value: _parse_amount(value, allow_zero=True),
        "أرسل رصيداً من صفر إلى 1,000,000,000.",
    )
    if amount is None:
        return

    log_chat_id = db.get(LOG_CHAT_KEY)
    if not log_chat_id:
        await _finish(
            client,
            query.from_user.id,
            "اضبط قناة السجلات أولاً ثم أعد إضافة الوكيل.",
            owner=True,
        )
        return

    async with ORDER_LOCK:
        connection = None
        try:
            connection = _open_transaction()
            agents = _read_value(connection, AGENT_KEY) or {}
            existing = agents.get(str(agent_id))
            if isinstance(existing, dict) and existing.get("status") != "archived":
                connection.rollback()
                await _finish(client, query.from_user.id, "هذا المستخدم مسجل كوكيل بالفعل.", True)
                return
            audit = (
                "إضافة وكيل\n"
                f"المالك: {query.from_user.id}\n"
                f"الوكيل: {agent_id}\n"
                f"رصيد المحفظة الابتدائي: {_format_amount(amount)}"
            )
            try:
                await client.send_message(log_chat_id, audit)
            except Exception:
                logger.exception("Could not send agent creation audit")
                connection.rollback()
                await _finish(
                    client,
                    query.from_user.id,
                    "تعذر التسجيل في قناة السجلات؛ لم تتم إضافة الوكيل.",
                    owner=True,
                )
                return
            agents[str(agent_id)] = {
                "status": "active",
                "wallet": _format_amount(amount),
                "created_at": int(time.time()),
                "created_by": query.from_user.id,
            }
            _write_value(connection, AGENT_KEY, agents)
            connection.commit()
        except Exception:
            if connection is not None:
                connection.rollback()
            logger.exception("Could not add agent")
            await _finish(
                client, query.from_user.id, "تعذر إضافة الوكيل بأمان.", owner=True
            )
            return
        finally:
            if connection is not None:
                connection.close()

    await _finish(
        client,
        query.from_user.id,
        f"تمت إضافة الوكيل {agent_id} برصيد {_format_amount(amount)} نقطة.",
        owner=True,
    )


@app.on_callback_query(filters.regex(r"^agent_wallet_(topup|set)$"))
async def agent_owner_wallet_change(client, query):
    if not await _require_owner(query):
        return
    mode = query.data.rsplit("_", 1)[-1]
    await clear_section_message(query)
    agent_id = await _ask_value(
        client,
        query.from_user.id,
        "أرسل آيدي الوكيل.",
        _parse_user_id,
        "أرسل آيدي رقمي صحيح.",
    )
    if agent_id is None:
        return
    amount = await _ask_value(
        client,
        query.from_user.id,
        "أرسل كمية الشحن." if mode == "topup" else "أرسل الرصيد الجديد للمحفظة.",
        lambda value: _parse_amount(value, allow_zero=mode == "set"),
        "الكمية غير صحيحة. أرسل رقماً من صفر إلى 1,000,000,000.",
    )
    if amount is None:
        return
    status, after = await _change_agent_wallet(
        client, query.from_user.id, agent_id, amount, mode
    )
    if status == "ok":
        text = f"تم تحديث محفظة الوكيل {agent_id}. الرصيد الجديد: {_format_amount(after)} نقطة."
    elif status == "log_missing":
        text = "اضبط قناة السجلات أولاً."
    elif status == "audit_failed":
        text = "تعذر تسجيل التعديل؛ لم يتغير رصيد المحفظة."
    elif status == "no_agent":
        text = "الوكيل غير موجود أو مؤرشف."
    elif status == "wallet_limit":
        text = "الرصيد الناتج يتجاوز الحد الأعلى المسموح."
    elif status == "wallet_limit":
        text = "الرصيد الناتج يتجاوز الحد الأعلى المسموح."
    else:
        text = "تعذر تحديث المحفظة بأمان."
    await _finish(client, query.from_user.id, text, owner=True)


def _agent_list_keyboard(agents, page):
    page_size = 8
    active_records = [
        (agent_id, record)
        for agent_id, record in sorted(agents.items(), key=lambda item: int(item[0]))
        if isinstance(record, dict) and record.get("status") != "archived"
    ]
    pages = max(1, (len(active_records) + page_size - 1) // page_size)
    page = min(max(page, 0), pages - 1)
    rows = []
    for agent_id, record in active_records[page * page_size : (page + 1) * page_size]:
        active = record.get("status") == "active"
        status = "فعّال" if active else "متوقف"
        wallet = escape(_format_amount(record.get("wallet", "0")))
        rows.append(
            [
                btn(
                    f"{agent_id} · {status} · {wallet} نقطة",
                    callback_data=f"agent_show:{agent_id}",
                )
            ]
        )
        rows.append(
            [
                btn(
                    "تعطيل" if active else "تفعيل",
                    callback_data=f"agent_status:{agent_id}",
                ),
                btn("أرشفة", callback_data=f"agent_archive:{agent_id}"),
            ]
        )
    navigation = []
    if page > 0:
        navigation.append(btn("السابق", callback_data=f"agent_list:{page - 1}"))
    if page + 1 < pages:
        navigation.append(btn("التالي", callback_data=f"agent_list:{page + 1}"))
    if navigation:
        rows.append(navigation)
    rows.append([btn("رجوع لإدارة الوكلاء", callback_data="agent_owner")])
    return active_records, pages, page, mk(rows)


async def _show_agent_list(query, page):
    agents = _get_agents()
    records, pages, page, keyboard = _agent_list_keyboard(agents, page)
    if records:
        text = (
            f"الوكلاء المسجلون ({len(records)})\n"
            f"الصفحة {page + 1} من {pages}\n"
            "اضغط على اسم الوكيل لعرض التفاصيل."
        )
    else:
        text = "لا يوجد وكلاء مسجلون حالياً."
    await query.edit_message_text(text, reply_markup=keyboard)


@app.on_callback_query(filters.regex(r"^agent_list(?::\d+)?$"))
async def agent_list(client, query):
    if not await _require_owner(query):
        return
    page_match = re.search(r":(\d+)$", query.data)
    await query.answer()
    await _show_agent_list(query, int(page_match.group(1)) if page_match else 0)


@app.on_callback_query(filters.regex(r"^agent_show:(\d+)$"))
async def agent_show(client, query):
    if not await _require_owner(query):
        return
    agent_id = query.data.split(":", 1)[1]
    record = _get_agents().get(agent_id)
    if not isinstance(record, dict) or record.get("status") == "archived":
        await query.answer("الوكيل غير موجود.", show_alert=True)
        return
    await query.answer()
    await query.edit_message_text(
        f"معلومات الوكيل {agent_id}\n"
        f"الحالة: {'فعّال' if record.get('status') == 'active' else 'متوقف'}\n"
        f"رصيد المحفظة: {_format_amount(record.get('wallet', '0'))} نقطة",
        reply_markup=mk(
            [
                [btn("شحن المحفظة", callback_data="agent_wallet_topup")],
                [btn("رجوع للقائمة", callback_data="agent_list:0")],
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"^agent_status:(\d+)$"))
async def agent_toggle_status(client, query):
    if not await _require_owner(query):
        return
    agent_id = query.data.split(":", 1)[1]
    agents = _get_agents()
    record = agents.get(agent_id)
    if not isinstance(record, dict) or record.get("status") == "archived":
        await query.answer("الوكيل غير موجود.", show_alert=True)
        return
    async with ORDER_LOCK:
        agents = _get_agents()
        record = agents.get(agent_id)
        if not isinstance(record, dict) or record.get("status") == "archived":
            await query.answer("الوكيل غير موجود.", show_alert=True)
            return
        record["status"] = (
            "disabled" if record.get("status") == "active" else "active"
        )
        agents[agent_id] = record
        db.set(AGENT_KEY, agents)
    await query.answer("تم تحديث حالة الوكيل.")
    await _show_agent_list(query, 0)


@app.on_callback_query(filters.regex(r"^agent_archive:(\d+)$"))
async def agent_archive(client, query):
    if not await _require_owner(query):
        return
    agent_id = query.data.split(":", 1)[1]
    agents = _get_agents()
    record = agents.get(agent_id)
    if not isinstance(record, dict) or record.get("status") == "archived":
        await query.answer("الوكيل غير موجود.", show_alert=True)
        return
    async with ORDER_LOCK:
        agents = _get_agents()
        record = agents.get(agent_id)
        if not isinstance(record, dict) or record.get("status") == "archived":
            await query.answer("الوكيل غير موجود.", show_alert=True)
            return
        record["status"] = "archived"
        record["archived_at"] = int(time.time())
        record["archived_by"] = query.from_user.id
        agents[agent_id] = record
        db.set(AGENT_KEY, agents)
    await query.answer("تمت أرشفة الوكيل مع الاحتفاظ بسجل محفظته.")
    await _show_agent_list(query, 0)


@app.on_callback_query(filters.regex(r"^agent_log_config$"))
async def agent_log_config(client, query):
    if not await _require_owner(query):
        return
    await clear_section_message(query)
    channel_username = await _ask_value(
        client,
        query.from_user.id,
        "أرسل يوزر قناة السجلات مثل @mychannel أو رابط t.me الخاص بها.\n"
        "يجب أن يكون للقناة يوزر، وأن يكون البوت مشرفاً بصلاحية النشر.",
        _parse_channel_username,
        "اليوزر غير صحيح. أرسل مثل @mychannel أو https://t.me/mychannel.",
    )
    if not channel_username:
        return
    try:
        chat = await client.get_chat(f"@{channel_username}")
        if chat.type != ChatType.CHANNEL:
            raise ValueError
        bot_user = await client.get_me()
        member = await client.get_chat_member(chat.id, bot_user.id)
        if member.status not in {ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER}:
            raise PermissionError
        if (
            member.status == ChatMemberStatus.ADMINISTRATOR
            and not getattr(
                getattr(member, "privileges", None),
                "can_post_messages",
                False,
            )
        ):
            raise PermissionError
        await client.send_message(
            chat.id,
            "تم تفعيل قناة سجلات الوكلاء. ستظهر هنا التحويلات وتغييرات المحافظ.",
        )
        db.set(LOG_CHAT_KEY, chat.id)
        db.set(LOG_CHANNEL_USERNAME_KEY, chat.username or channel_username)
    except PermissionError:
        await _finish(
            client,
            query.from_user.id,
            "البوت ليس مشرفاً بصلاحية نشر الرسائل في القناة.",
            owner=True,
        )
        return
    except Exception:
        await _finish(
            client,
            query.from_user.id,
            "تعذر الوصول للقناة. تحقق من اليوزر ومن إضافة البوت مشرفاً مع صلاحية النشر.",
            owner=True,
        )
        return

    await _finish(
        client,
        query.from_user.id,
        f"تم إعداد قناة السجلات: @{channel_username}.",
        owner=True,
    )
