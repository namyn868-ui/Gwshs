from decimal import Decimal, InvalidOperation
from html import escape

from kvsqlite.sync import Client as Database
from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from .navigation import ask_with_back, clear_section_message

db = Database("data.sqlite", "fuck")
ADMIN_BACK = mk([[btn("رجوع", callback_data="member_admin")]])
PRICE_KEY = "member_price_per_1000"
MINIMUM_KEY = "member_min_quantity"
MAXIMUM_KEY = "member_max_quantity"
SERVICE_ID_KEY = "member_service_id"
ORDERS_KEY = "member_orders"


def _is_admin(user_id):
    return user_id in (db.get("admin_list") or [])


def _numbers(value):
    return str(value).translate(
        str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
    )


def _price():
    configured = db.get(PRICE_KEY)
    if configured is not None:
        try:
            value = Decimal(str(configured))
            if value.is_finite() and value > 0:
                return value
        except (InvalidOperation, TypeError, ValueError):
            pass
    legacy = db.get("member_price")
    try:
        value = Decimal(str(legacy)) * 1000 if legacy is not None else Decimal("200")
        return value if value.is_finite() and value > 0 else Decimal("200")
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("200")


def _minimum():
    try:
        value = int(db.get(MINIMUM_KEY))
        return value if value > 0 else 500
    except (TypeError, ValueError):
        return 500


def _maximum():
    try:
        value = int(db.get(MAXIMUM_KEY))
        return value if value >= _minimum() else 30000
    except (TypeError, ValueError):
        return 30000


def _service_id():
    return db.get(SERVICE_ID_KEY) or db.get("id_service")


def _service_enabled():
    return db.get("member_service_enabled") not in (False, 0)


def _format(value):
    return format(value.normalize(), "f")


def _panel_text():
    enabled = _service_enabled()
    service_id = _service_id() or "غير محدد"
    status = "مفعّلة" if enabled else "متوقفة"
    orders = db.get(ORDERS_KEY)
    order_count = len(orders) if isinstance(orders, list) else 0
    return (
        "<b>إدارة طلب رشق الأعضاء</b>\n"
        f"الحالة: <b>{status}</b>\n"
        f"الحد الأدنى: <code>{_minimum()}</code>\n"
        f"الحد الأقصى: <code>{_maximum()}</code>\n"
        f"السعر لكل 1000 عضو: <code>{_format(_price())} $</code>\n"
        f"معرّف خدمة المزوّد: <code>{escape(str(service_id))}</code>\n"
        f"عدد الطلبات المسجلة: <code>{order_count}</code>\n"
        "مفتاح API لا يظهر هنا حفاظاً على سريته."
    )


def _panel_keyboard():
    enabled = _service_enabled()
    toggle = "⏸️ إيقاف الخدمة" if enabled else "▶️ تفعيل الخدمة"
    return mk(
        [
            [
                btn("💰 السعر لكل 1000", callback_data="member_admin_set:price"),
                btn("🆔 معرّف المزوّد", callback_data="member_admin_set:service"),
            ],
            [
                btn("⬇️ الحد الأدنى", callback_data="member_admin_set:min"),
                btn("⬆️ الحد الأقصى", callback_data="member_admin_set:max"),
            ],
            [
                btn(toggle, callback_data="member_admin_toggle"),
                btn("📋 آخر الطلبات", callback_data="member_admin_orders"),
            ],
            [
                btn("🔄 تحديث", callback_data="member_admin"),
                btn("↩️ رجوع للإعدادات", callback_data="setting_bot"),
            ],
        ]
    )


async def _show_panel(query):
    await query.edit_message_text(
        _panel_text(),
        reply_markup=_panel_keyboard(),
        parse_mode=enums.ParseMode.HTML,
    )


@app.on_callback_query(filters.regex(r"^member_admin$"))
async def member_admin_panel(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    await _show_panel(query)


@app.on_callback_query(filters.regex(r"^member_admin_toggle$"))
async def toggle_member_service(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    enabled = _service_enabled()
    db.set("member_service_enabled", not enabled)
    await query.answer("تم تحديث حالة الخدمة.")
    await _show_panel(query)


@app.on_callback_query(filters.regex(r"^member_admin_set:(price|min|max|service)$"))
async def set_member_service_value(client, query):
    user_id = query.from_user.id
    if not _is_admin(user_id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    field = query.data.rsplit(":", 1)[1]
    prompts = {
        "price": f"السعر الحالي لكل 1000 عضو: {_format(_price())} $\nأرسل السعر الجديد:",
        "min": f"الحد الأدنى الحالي: {_minimum()}\nأرسل الحد الأدنى الجديد:",
        "max": f"الحد الأقصى الحالي: {_maximum()}\nأرسل الحد الأقصى الجديد:",
        "service": f"معرّف الخدمة الحالي: {_service_id() or 'غير محدد'}\nأرسل معرّف الخدمة الرقمي:",
    }
    await clear_section_message(query)
    answer = await ask_with_back(
        client,
        user_id,
        prompts[field],
        "member_admin",
        filters=filters.user(user_id),
    )
    if not answer or not answer.text:
        return
    raw = _numbers(answer.text.strip().replace("٫", "."))
    if raw.lower() == "/cancel":
        await answer.reply("تم إلغاء التعديل.", reply_markup=ADMIN_BACK)
        return

    if field == "price":
        raw = raw.replace(",", ".")
        try:
            value = Decimal(raw)
        except InvalidOperation:
            value = Decimal("NaN")
        if (
            not value.is_finite()
            or not Decimal("0.000001") <= value <= Decimal("1000000")
        ):
            await answer.reply("أرسل سعراً أكبر من صفر ولا يتجاوز 1,000,000.", reply_markup=ADMIN_BACK)
            return
        db.set(PRICE_KEY, float(value))
        db.set("member_price", float(value / Decimal(1000)))
        label = f"السعر لكل 1000 عضو: {_format(value)} $"
    else:
        raw = raw.replace(",", "").replace("٬", "").replace(" ", "")
        try:
            value = int(raw)
        except ValueError:
            value = 0
        if value <= 0 or value > 100_000_000:
            await answer.reply("أرسل عدداً صحيحاً أكبر من صفر وأقل من 100 مليون.", reply_markup=ADMIN_BACK)
            return
        if field == "min":
            if value > _maximum():
                await answer.reply("الحد الأدنى لا يمكن أن يتجاوز الحد الأقصى الحالي.", reply_markup=ADMIN_BACK)
                return
            db.set(MINIMUM_KEY, value)
            label = f"الحد الأدنى: {value}"
        elif field == "max":
            if value < _minimum():
                await answer.reply("الحد الأقصى لا يمكن أن يكون أقل من الحد الأدنى الحالي.", reply_markup=ADMIN_BACK)
                return
            db.set(MAXIMUM_KEY, value)
            label = f"الحد الأقصى: {value}"
        else:
            db.set(SERVICE_ID_KEY, value)
            db.set("id_service", value)
            label = f"معرّف الخدمة: {value}"

    await answer.reply(f"تم تحديث {label}.", reply_markup=ADMIN_BACK)
    await client.send_message(
        user_id,
        _panel_text(),
        reply_markup=_panel_keyboard(),
        parse_mode=enums.ParseMode.HTML,
    )


@app.on_callback_query(filters.regex(r"^member_admin_orders$"))
async def show_member_orders(client, query):
    if not _is_admin(query.from_user.id):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    orders = db.get(ORDERS_KEY)
    if not isinstance(orders, list):
        orders = []
    recent = list(reversed(orders[-10:]))
    lines = ["<b>آخر طلبات رشق الأعضاء</b>"]
    if not recent:
        lines.append("لا توجد طلبات مسجلة بعد.")
    for order in recent:
        lines.extend(
            [
                "",
                f"الطلب: <code>{escape(str(order.get('order_id', '—')))}</code>",
                f"المستخدم: <code>{escape(str(order.get('user_id', '—')))}</code>",
                f"القناة: @{escape(str(order.get('channel_username', '—')))}",
                f"الحالة: <b>{escape(str(order.get('status', 'قيد الانتظار')))}</b>",
                f"العدد: <code>{escape(str(order.get('quantity', '—')))}</code> | "
                f"التكلفة: <code>{escape(str(order.get('cost', '—')))} $</code>",
            ]
        )
    unresolved = []
    for key in db.keys():
        key_name = str(key[0])
        if not key_name.startswith("member_pending_"):
            continue
        target_id = key_name.removeprefix("member_pending_")
        if not target_id.isdigit():
            continue
        pending = db.get(key_name)
        if isinstance(pending, dict) and pending.get("status") in {
            "submitting",
            "unknown",
        }:
            unresolved.append((int(target_id), pending))
    lines.extend(["", "<b>طلبات تحتاج مراجعة يدوية</b>"])
    if not unresolved:
        lines.append("لا توجد طلبات عالقة.")
    for user_id, pending in unresolved:
        lines.extend(
            [
                "",
                f"المستخدم: <code>{user_id}</code>",
                f"الحالة: <b>{'نتيجة غير مؤكدة' if pending.get('status') == 'unknown' else 'قيد الإرسال'}</b>",
                f"القناة: @{escape(str(pending.get('channel_username', '—')))}",
                f"العدد: <code>{escape(str(pending.get('quantity', '—')))}</code> | "
                f"التكلفة: <code>{escape(str(pending.get('cost', '—')))} $</code>",
            ]
        )
    await query.edit_message_text(
        "\n".join(lines),
        parse_mode=enums.ParseMode.HTML,
        reply_markup=mk(
            [
                [btn("تحديث", callback_data="member_admin_orders")],
                [btn("رجوع", callback_data="member_admin")],
            ]
        ),
    )
