import random
import time
from decimal import Decimal, InvalidOperation

from pyrogram import Client as app, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from .navigation import ask_with_back, clear_section_message
from .order_lock import ORDER_LOCK
from .points_core import (
    collection_keyboard,
    db,
    format_points,
    get_active_coupon,
    get_gift_config,
)


def _read_balance(user_info):
    try:
        return Decimal(str(user_info.get("coins", 0)))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("0")


def _return_keyboard():
    return mk([[btn("العودة إلى تجميع النقاط", callback_data="collect_points")]])


def _format_remaining(seconds):
    minutes = max(1, (int(seconds) + 59) // 60)
    hours, minutes = divmod(minutes, 60)
    if hours and minutes:
        return f"{hours} ساعة و{minutes} دقيقة"
    if hours:
        return f"{hours} ساعة"
    return f"{minutes} دقيقة"


@app.on_callback_query(filters.regex(r"^collect_points$"))
async def show_points_collection(client, query):
    await query.answer()
    await query.edit_message_text(
        "اختر طريقة تجميع النقاط:",
        reply_markup=collection_keyboard(),
    )


@app.on_callback_query(filters.regex(r"^daily_gift$"))
async def claim_daily_gift(client, query):
    user_id = query.from_user.id
    user_key = f"user_{user_id}"
    user_info = db.get(user_key)
    if not isinstance(user_info, dict):
        await query.answer("ابدأ البوت أولاً عبر /start.", show_alert=True)
        return

    reward = None
    remaining = 0
    interval_hours = 0
    balance = Decimal("0")

    async with ORDER_LOCK:
        now = time.time()
        user_info = db.get(user_key)
        if not isinstance(user_info, dict):
            await query.answer("ابدأ البوت أولاً عبر /start.", show_alert=True)
            return

        config = get_gift_config()
        interval_hours = config["interval_hours"]
        last_claim = float(user_info.get("points_gift_last_claim", 0) or 0)
        wait_seconds = interval_hours * 3600
        remaining = wait_seconds - (now - last_claim)
        if remaining <= 0:
            reward = random.randint(config["min_points"], config["max_points"])
            balance = _read_balance(user_info) + Decimal(reward)
            user_info["coins"] = float(balance)
            user_info["points_gift_last_claim"] = now
            db.set(user_key, user_info)

    if reward is None:
        await query.answer("لم يحن موعد الهدية بعد.", show_alert=False)
        await query.edit_message_text(
            f"لقد أخذت هديتك بالفعل 🎁\n"
            f"يمكنك أخذ هدية جديدة بعد: {_format_remaining(remaining)}.",
            reply_markup=_return_keyboard(),
        )
        return

    await query.answer("تمت إضافة الهدية إلى رصيدك ✅")
    await query.edit_message_text(
        f"مبروك! حصلت على {reward} نقطة عشوائية 🎁\n"
        f"رصيدك الحالي: {format_points(balance)} نقطة\n"
        f"يمكنك أخذ هدية جديدة بعد {interval_hours} ساعة.",
        reply_markup=_return_keyboard(),
    )


@app.on_callback_query(filters.regex(r"^coupon_redeem$"))
async def redeem_coupon_prompt(client, query):
    user_id = query.from_user.id
    if not isinstance(db.get(f"user_{user_id}"), dict):
        await query.answer("ابدأ البوت أولاً عبر /start.", show_alert=True)
        return

    await clear_section_message(query)
    answer = await ask_with_back(
        client,
        user_id,
        "أرسل كود كوبون الهدية 🎟️",
        "collect_points",
        filters=filters.user(user_id),
    )
    if not answer:
        return

    code = (answer.text or "").strip()
    outcome = "الكود غير صحيح أو غير متاح."
    balance = None
    reward = None
    now = time.time()

    async with ORDER_LOCK:
        coupon = get_active_coupon()
        user_key = f"user_{user_id}"
        user_info = db.get(user_key)

        if not isinstance(user_info, dict):
            outcome = "تعذر العثور على حسابك. أرسل /start أولاً."
        elif not coupon or not coupon.get("active", True):
            outcome = "لا يوجد كوبون هدية فعّال حالياً."
        elif now >= float(coupon.get("expires_at", 0)):
            outcome = "انتهت صلاحية هذا الكوبون."
        elif code.casefold() != str(coupon.get("code", "")).casefold():
            outcome = "الكود غير صحيح أو غير متاح."
        else:
            used_by = list(coupon.get("users") or [])
            if str(user_id) in {str(used_id) for used_id in used_by}:
                outcome = "استخدمت هذا الكوبون مسبقاً."
            elif len(used_by) >= int(coupon.get("max_uses", 0)):
                outcome = "اكتمل عدد مستخدمي هذا الكوبون."
            else:
                reward = int(coupon["reward_points"])
                balance = _read_balance(user_info) + Decimal(reward)
                user_info["coins"] = float(balance)
                used_by.append(user_id)
                coupon["users"] = used_by
                coupon["uses"] = len(used_by)
                db.set(user_key, user_info)
                db.set("points_active_coupon", coupon)
                outcome = (
                    f"تم تفعيل الكوبون بنجاح ✅\n"
                    f"أُضيف إلى رصيدك {reward} نقطة.\n"
                    f"رصيدك الحالي: {format_points(balance)} نقطة."
                )

    await answer.reply(outcome, reply_markup=_return_keyboard())
