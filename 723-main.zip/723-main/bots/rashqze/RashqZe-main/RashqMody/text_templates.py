import re
from decimal import Decimal, InvalidOperation
from html import escape

from kvsqlite.sync import Client as Database


db = Database("data.sqlite", "fuck")

TEXT_TEMPLATES = {
    "start": {
        "title": "كليشة البداية /start",
        "db_key": "start_msg",
        "default": (
            "مرحباً [name] في بوت رشق الفراعنة\n\n"
            "⌁︙الايدي الخاص بك ↫⤈\n"
            "ID : [id]"
        ),
    },
    "force": {
        "title": "كليشة الاشتراك الإجباري",
        "db_key": "force_msg",
        "default": "عذراً [name]، يجب الاشتراك في القنوات التالية أولاً.",
    },
    "member": {
        "title": "كليشة قسم رشق الأعضاء",
        "db_key": "member_order_msg",
        "default": (
            "طلب رشق الأعضاء\n"
            "الحد الأدنى: [min_quantity] عضو\n"
            "الحد الأقصى: [max_quantity] عضو\n"
            "أرسل العدد المطلوب أو اضغط «رجوع»."
        ),
    },
    "account": {
        "title": "كليشة معلومات الحساب",
        "db_key": "account_info_msg",
        "default": (
            "⌁︙معلومات حسابك في بوت زد إي ↫⤈\n"
            "⌁︙الاسم ↫ [name]\n"
            "⌁︙الايدي ↫ [id]\n"
            "⌁︙رصيد حسابك الحالي ↫ [balance] $\n"
            "⌁︙عدد مشاركاتك لرابط الدعوة ↫ [referrals]\n"
            "⌁︙عدد الطلبات التي قمت بطلبها ↫ [orders]\n"
            "⌁︙عدد تحويلاتك ↫ [transfers]"
        ),
    },
}

_TOKEN = re.compile(r"\[([A-Za-z_]+)\]")


def get_template(template_id):
    template = TEXT_TEMPLATES[template_id]
    current = db.get(template["db_key"])
    if current is None or not str(current).strip():
        return template["default"]
    return str(current)


def _display_balance(value):
    try:
        amount = Decimal(str(value or 0))
        if amount.is_finite():
            return format(amount.normalize(), "f")
    except (InvalidOperation, TypeError, ValueError):
        pass
    return "0"


def render_template(template_id, user_id, user=None, **extra_values):
    """Render a stored template as safe HTML text for Pyrogram's HTML parser."""
    template = get_template(template_id)
    user_info = db.get(f"user_{user_id}") or {}
    first_name = str(getattr(user, "first_name", "") or "")
    last_name = str(getattr(user, "last_name", "") or "")
    name = " ".join(part for part in (first_name, last_name) if part).strip()
    values = {
        "name": name,
        "first_name": first_name,
        "id": user_id,
        "balance": _display_balance(user_info.get("coins", 0)),
    }
    values.update(extra_values)

    parts = []
    cursor = 0
    for match in _TOKEN.finditer(template):
        parts.append(escape(template[cursor:match.start()], quote=False))
        token_name = match.group(1).lower()
        if token_name in values:
            parts.append(escape(str(values[token_name]), quote=False))
        else:
            parts.append(escape(match.group(0), quote=False))
        cursor = match.end()
    parts.append(escape(template[cursor:], quote=False))
    return "".join(parts)
