import asyncio
import logging
import re
import time
import uuid
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from html import escape

import requests
from kvsqlite.sync import Client as Database
from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk

from .navigation import ask_with_back, clear_section_message
from .order_lock import ORDER_LOCK
from .order_status import register_provider_order
from .text_templates import render_template

db = Database("data.sqlite", "fuck")
logger = logging.getLogger(__name__)
HOME_BACK = mk([[btn("رجوع", callback_data="back")]])
MIN_QUANTITY_KEY = "member_min_quantity"
MAX_QUANTITY_KEY = "member_max_quantity"
PRICE_KEY = "member_price_per_1000"
SERVICE_ID_KEY = "member_service_id"
ORDERS_KEY = "member_orders"
PENDING_TTL_SECONDS = 15 * 60


def _digits_to_ascii(value):
    return str(value).translate(
        str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")
    )


def _minimum():
    try:
        value = int(db.get(MIN_QUANTITY_KEY))
        return value if value > 0 else 500
    except (TypeError, ValueError):
        return 500


def _maximum():
    try:
        value = int(db.get(MAX_QUANTITY_KEY))
        return value if value >= _minimum() else 30000
    except (TypeError, ValueError):
        return 30000


def _price_per_1000():
    value = db.get(PRICE_KEY)
    if value is not None:
        try:
            price = Decimal(str(value))
            if price.is_finite() and price > 0:
                return price
        except (InvalidOperation, TypeError, ValueError):
            pass

    # Keep the existing configured per-member price meaningful during migration.
    legacy_price = db.get("member_price")
    if legacy_price is not None:
        try:
            price = Decimal(str(legacy_price)) * Decimal(1000)
            if price.is_finite() and price > 0:
                return price
        except (InvalidOperation, TypeError, ValueError):
            pass
    return Decimal("200")


def _service_id():
    return db.get(SERVICE_ID_KEY) or db.get("id_service")


def _service_enabled():
    return db.get("member_service_enabled") not in (False, 0)


def _format_money(value):
    return format(value.normalize(), "f")


def _calculate_cost(quantity, price_per_1000):
    return (price_per_1000 * Decimal(quantity) / Decimal(1000)).quantize(
        Decimal("0.000001"),
        rounding=ROUND_HALF_UP,
    )


def _parse_channel_username(value):
    raw = (value or "").strip()
    if "/" in raw or "t.me" in raw.lower() or "telegram.me" in raw.lower():
        return None
    match = re.fullmatch(r"@?([A-Za-z][A-Za-z0-9_]{4,31})", raw)
    return match.group(1).lower() if match else None


def _provider_url_and_settings():
    domain = str(db.get("set_domain") or "").strip()
    domain = domain.removeprefix("https://").removeprefix("http://").strip("/")
    if not domain or "/" in domain or "@" in domain:
        raise ValueError("provider_not_configured")
    return f"https://{domain}/api/v2", {
        "key": str(db.get("api_key") or "").strip(),
    }


async def _place_member_order(quantity, channel_username, service_id):
    endpoint, credentials = _provider_url_and_settings()
    if not credentials["key"] or not service_id:
        raise ValueError("provider_not_configured")

    response = await asyncio.to_thread(
        requests.get,
        endpoint,
        params={
            **credentials,
            "action": "add",
            "service": str(service_id),
            "quantity": quantity,
            "link": f"https://t.me/{channel_username}",
        },
        timeout=30,
    )
    response.raise_for_status()
    result = response.json()
    if not isinstance(result, dict):
        raise ValueError("provider_rejected_order")
    if result.get("error") or not result.get("order"):
        raise ValueError("provider_rejected_order")
    return str(result["order"])


async def _ask_channel_username(client, user_id):
    for attempt in range(3):
        prompt = (
            "أرسل يوزر القناة العامة فقط، مثل @mychannel، بدون رابط t.me "
            "أو رابط منشور."
        )
        if attempt:
            prompt += f"\nالمحاولة {attempt + 1} من 3."
        message = await ask_with_back(
            client,
            user_id,
            prompt,
            "back",
            filters=filters.user(user_id),
        )
        if not message or not message.text:
            return None
        username = _parse_channel_username(message.text)
        if not username:
            await message.reply(
                "صيغة اليوزر غير صحيحة. أرسل @username فقط، ولا ترسل رابط القناة.",
                reply_markup=HOME_BACK,
            )
            continue

        try:
            chat = await client.get_chat(f"@{username}")
            if chat.type != enums.ChatType.CHANNEL or not chat.username:
                raise ValueError("not_public_channel")
            return username
        except Exception:
            await message.reply(
                "لم أتمكن من العثور على قناة عامة بهذا اليوزر. "
                "تأكد من كتابته ثم أرسله مثل @mychannel.",
                reply_markup=HOME_BACK,
            )

    return None


@app.on_callback_query(filters.regex(r"^member$"))
async def member_order_menu(client, query):
    user_id = query.from_user.id
    if not _service_enabled():
        await query.edit_message_text(
            "خدمة رشق الأعضاء متوقفة حالياً. حاول لاحقاً.",
            reply_markup=HOME_BACK,
        )
        return
    if not (db.get("set_domain") and db.get("api_key") and _service_id()):
        await query.edit_message_text(
            "خدمة رشق الأعضاء غير مهيأة حالياً. يرجى المحاولة لاحقاً.",
            reply_markup=HOME_BACK,
        )
        return
    if not db.exists(f"user_{user_id}"):
        await query.edit_message_text(
            "أرسل /start أولاً لإنشاء حسابك.",
            reply_markup=HOME_BACK,
        )
        return

    minimum = _minimum()
    maximum = _maximum()
    price = _price_per_1000()
    prompt = render_template(
        "member",
        user_id,
        user=query.from_user,
        min_quantity=f"{minimum:,}",
        max_quantity=f"{maximum:,}",
    )
    await clear_section_message(query)
    quantity_message = await ask_with_back(
        client,
        user_id,
        prompt,
        "back",
        filters=filters.user(user_id),
        parse_mode=enums.ParseMode.HTML,
    )
    if not quantity_message or not quantity_message.text:
        return

    raw_quantity = _digits_to_ascii(quantity_message.text.strip())
    if raw_quantity.lower() == "/cancel":
        await quantity_message.reply("تم إلغاء الطلب.", reply_markup=HOME_BACK)
        return
    try:
        quantity = int(raw_quantity.replace(",", "").replace("٬", "").replace(" ", ""))
    except ValueError:
        await quantity_message.reply(
            "أرسل عدداً صحيحاً فقط، مثل 500 أو 1000.",
            reply_markup=HOME_BACK,
        )
        return
    if not minimum <= quantity <= maximum:
        await quantity_message.reply(
            f"العدد يجب أن يكون بين {minimum:,} و{maximum:,}.",
            reply_markup=HOME_BACK,
        )
        return

    cost = _calculate_cost(quantity, price)
    user_info = db.get(f"user_{user_id}") or {}
    try:
        balance = Decimal(str(user_info.get("coins", 0)))
    except (InvalidOperation, TypeError, ValueError):
        balance = Decimal("0")
    if balance < cost:
        await quantity_message.reply(
            "رصيدك الحالي غير كافي لإتمام هذا الطلب.",
            reply_markup=HOME_BACK,
        )
        return

    channel_username = await _ask_channel_username(client, user_id)
    if not channel_username:
        return

    # Re-read the balance before showing the final confirmation.
    user_info = db.get(f"user_{user_id}") or {}
    try:
        balance = Decimal(str(user_info.get("coins", 0)))
    except (InvalidOperation, TypeError, ValueError):
        balance = Decimal("0")
    if balance < cost:
        await client.send_message(
            user_id,
            "رصيدك الحالي غير كافي لإتمام هذا الطلب.",
            reply_markup=HOME_BACK,
        )
        return

    token = uuid.uuid4().hex[:16]
    pending = {
        "token": token,
        "user_id": user_id,
        "channel_username": channel_username,
        "quantity": quantity,
        "cost": str(cost),
        "created_at": time.time(),
        "status": "pending",
    }
    db.set(f"member_pending_{user_id}", pending)
    summary = (
        "تأكيد طلبك\n"
        "الخدمة: رشق أعضاء\n"
        f"القناة: @{escape(channel_username)}\n"
        f"العدد: {quantity:,}\n"
        f"رصيدك الحالي: {_format_money(balance)} $"
    )
    await client.send_message(
        user_id,
        summary,
        reply_markup=mk(
            [
                [
                    btn("تأكيد الطلب ✅", callback_data=f"member_confirm:{token}"),
                    btn("إلغاء ❌", callback_data=f"member_cancel:{token}"),
                ]
            ]
        ),
    )


@app.on_callback_query(filters.regex(r"^member_cancel:([a-f0-9]{16})$"))
async def cancel_member_order(client, query):
    user_id = query.from_user.id
    token = query.data.rsplit(":", 1)[1]
    async with ORDER_LOCK:
        pending = db.get(f"member_pending_{user_id}")
        if not isinstance(pending, dict) or pending.get("token") != token:
            await query.answer("انتهت صلاحية هذا الطلب.", show_alert=True)
            return
        if pending.get("status") in {"submitting", "unknown"}:
            await query.answer(
                "الطلب قيد المراجعة؛ لا تلغه ولا ترسل طلباً مكرراً، وتواصل مع الأدمن.",
                show_alert=True,
            )
            return
        db.delete(f"member_pending_{user_id}")
        await query.edit_message_text("تم إلغاء الطلب.", reply_markup=HOME_BACK)
        await query.answer()


@app.on_callback_query(filters.regex(r"^member_confirm:([a-f0-9]{16})$"))
async def confirm_member_order(client, query):
    user_id = query.from_user.id
    token = query.data.rsplit(":", 1)[1]

    async with ORDER_LOCK:
        pending = db.get(f"member_pending_{user_id}")
        if (
            not isinstance(pending, dict)
            or pending.get("token") != token
            or pending.get("user_id") != user_id
        ):
            await query.answer("انتهت صلاحية هذا الطلب.", show_alert=True)
            return
        if pending.get("status") == "unknown":
            await query.answer(
                "تعذر تأكيد نتيجة الطلب من المزوّد. لا ترسل طلباً جديداً قبل مراجعة الأدمن.",
                show_alert=True,
            )
            return
        if pending.get("status") == "submitting":
            await query.answer("الطلب قيد الإرسال؛ انتظر نتيجة العملية.", show_alert=True)
            return
        if time.time() - float(pending.get("created_at", 0)) > PENDING_TTL_SECONDS:
            db.delete(f"member_pending_{user_id}")
            await query.edit_message_text(
                "انتهت صلاحية الطلب. ابدأ طلباً جديداً.",
                reply_markup=HOME_BACK,
            )
            await query.answer()
            return
        if not _service_enabled():
            db.delete(f"member_pending_{user_id}")
            await query.edit_message_text(
                "تم إيقاف الخدمة قبل تأكيد الطلب.",
                reply_markup=HOME_BACK,
            )
            await query.answer()
            return

        user_info = db.get(f"user_{user_id}") or {}
        try:
            balance = Decimal(str(user_info.get("coins", 0)))
            cost = Decimal(str(pending["cost"]))
        except (InvalidOperation, KeyError, TypeError, ValueError):
            balance = Decimal("0")
            cost = Decimal("0")
        if balance < cost:
            db.delete(f"member_pending_{user_id}")
            await query.edit_message_text(
                "رصيدك الحالي غير كافي لإتمام هذا الطلب.",
                reply_markup=HOME_BACK,
            )
            await query.answer()
            return

        service_id = _service_id()
        if not service_id:
            await query.answer("الخدمة غير مهيأة؛ لم يتم خصم الرصيد.", show_alert=True)
            return

        pending["status"] = "submitting"
        db.set(f"member_pending_{user_id}", pending)
        try:
            order_id = await _place_member_order(
                int(pending["quantity"]),
                pending["channel_username"],
                service_id,
            )
        except Exception as error:
            logger.warning(
                "Member service provider request failed (%s)",
                type(error).__name__,
            )
            pending["status"] = "unknown"
            pending["unknown_at"] = time.time()
            pending["provider_error_type"] = type(error).__name__
            db.set(f"member_pending_{user_id}", pending)
            await query.answer(
                "تعذر تأكيد نتيجة الطلب من المزوّد. قد يكون الطلب قد وصل إليه؛ "
                "لا تعاود الإرسال وتواصل مع الأدمن للمراجعة. لم يتم خصم نقاط.",
                show_alert=True,
            )
            return

        user_info["coins"] = float(balance - cost)
        db.set(f"user_{user_id}", user_info)
        buys_key = f"user_{user_id}_buys"
        db.set(buys_key, int(db.get(buys_key) or 0) + 1)

        orders = db.get(ORDERS_KEY)
        if not isinstance(orders, list):
            orders = []
        record = {
            "order_id": order_id,
            "user_id": user_id,
            "username": query.from_user.username or "",
            "channel_username": pending["channel_username"],
            "quantity": int(pending["quantity"]),
            "cost": str(cost),
            "created_at": time.time(),
            "status": "قيد الانتظار",
        }
        orders.append(record)
        db.set(ORDERS_KEY, orders[-200:])
        register_provider_order(
            order_id,
            user_id,
            "رشق أعضاء",
            quantity=record["quantity"],
            target=record["channel_username"],
        )
        db.delete(f"member_pending_{user_id}")

    await query.edit_message_text(
        "تم تسجيل الطلب بنجاح ✅\n"
        f"معرّف الطلب: <code>{escape(order_id)}</code>\n"
        "الحالة: قيد الانتظار\n"
        "الخدمة: رشق أعضاء\n"
        f"القناة: @{escape(record['channel_username'])}\n"
        f"العدد: {record['quantity']:,}\n"
        f"رصيدك بعد الطلب: {_format_money(balance - cost)} $",
        parse_mode=enums.ParseMode.HTML,
        reply_markup=HOME_BACK,
    )
    await query.answer()

    for admin_id in db.get("admin_list") or []:
        try:
            await client.send_message(
                admin_id,
                "طلب رشق أعضاء جديد\n"
                f"الطلب: <code>{escape(order_id)}</code>\n"
                f"المستخدم: <code>{user_id}</code>\n"
                f"القناة: @{escape(record['channel_username'])}\n"
                f"العدد: {record['quantity']:,} | التكلفة: {_format_money(cost)} $",
                parse_mode=enums.ParseMode.HTML,
            )
        except Exception:
            pass
