import asyncio


# Share one balance/order lock across all services that charge user credits.
ORDER_LOCK = asyncio.Lock()
