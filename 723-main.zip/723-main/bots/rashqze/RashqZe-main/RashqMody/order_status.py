import asyncio
import time
from html import escape

import requests
from pyrogram import enums
from kvsqlite.sync import Client as Database

from .order_lock import ORDER_LOCK

db = Database("data.sqlite", "fuck")
TRACKED_ORDERS_KEY = "tracked_provider_orders"
POLL_INTERVAL_SECONDS = 60
MAX_ORDERS_PER_CYCLE = 25
NOTIFICATION_RETRY_SECONDS = 600
TERMINAL_STATUSES = {"مكتمل", "مكتمل جزئياً", "ملغي", "مسترجع"}


def normalize_provider_status(data):
    if not isinstance(data, dict) or data.get("error"):
        return None
    raw = str(data.get("status") or "").strip()
    key = " ".join(raw.casefold().replace("_", " ").replace("-", " ").split())
    if key in {"completed", "complete", "finished", "done"}:
        return "مكتمل"
    if key in {"partial", "partially completed", "partially complete"}:
        return "مكتمل جزئياً"
    if key in {"canceled", "cancelled"}:
        return "ملغي"
    if key in {"refunded"}:
        return "مسترجع"
    if key in {
        "pending",
        "in progress",
        "inprogress",
        "processing",
        "queued",
        "waiting",
        "",
    }:
        return "قيد الانتظار"
    return "قيد الانتظار"


def tracked_orders():
    orders = db.get(TRACKED_ORDERS_KEY)
    if not isinstance(orders, list):
        return []
    return [dict(order) for order in orders if isinstance(order, dict)]


def get_tracked_order(order_id):
    target = str(order_id)
    return next(
        (order for order in reversed(tracked_orders()) if str(order.get("order_id")) == target),
        None,
    )


def register_provider_order(
    order_id,
    user_id,
    service_name,
    quantity=None,
    target=None,
):
    orders = tracked_orders()
    order_id = str(order_id)
    existing = next(
        (order for order in orders if str(order.get("order_id")) == order_id),
        None,
    )
    if existing:
        return

    order = {
        "order_id": order_id,
        "user_id": int(user_id),
        "service_name": str(service_name or "الخدمة"),
        "quantity": quantity,
        "target": target,
        "status": "قيد الانتظار",
        "completion_notified": False,
        "notification_attempted_at": 0,
        "created_at": time.time(),
    }
    orders.append(order)
    db.set(TRACKED_ORDERS_KEY, orders[-1000:])


def _provider_endpoint():
    domain = str(db.get("set_domain") or "").strip()
    domain = domain.removeprefix("https://").removeprefix("http://").strip("/")
    api_key = str(db.get("api_key") or "").strip()
    if not domain or "/" in domain or "@" in domain or not api_key:
        raise ValueError("provider_not_configured")
    return f"https://{domain}/api/v2", api_key


async def _fetch_order_status(order_id):
    endpoint, api_key = _provider_endpoint()
    response = await asyncio.to_thread(
        requests.get,
        endpoint,
        params={
            "key": api_key,
            "action": "status",
            "order": str(order_id),
        },
        timeout=20,
    )
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict) or data.get("error"):
        raise ValueError("provider_status_unavailable")
    return data


async def _save_status(order_id, status):
    target = str(order_id)
    async with ORDER_LOCK:
        orders = db.get(TRACKED_ORDERS_KEY)
        if not isinstance(orders, list):
            return None
        updated = None
        for order in orders:
            if isinstance(order, dict) and str(order.get("order_id")) == target:
                order["status"] = status
                updated = dict(order)
                break
        if updated is None:
            return None
        db.set(TRACKED_ORDERS_KEY, orders)

        member_orders = db.get("member_orders")
        if isinstance(member_orders, list):
            changed = False
            for order in member_orders:
                if isinstance(order, dict) and str(order.get("order_id")) == target:
                    order["status"] = status
                    changed = True
            if changed:
                db.set("member_orders", member_orders)
        return updated


async def _mark_notification_attempt(order_id):
    target = str(order_id)
    async with ORDER_LOCK:
        orders = db.get(TRACKED_ORDERS_KEY)
        if not isinstance(orders, list):
            return None
        for order in orders:
            if isinstance(order, dict) and str(order.get("order_id")) == target:
                if order.get("completion_notified"):
                    return None
                last_attempt = float(order.get("notification_attempted_at") or 0)
                if time.time() - last_attempt < NOTIFICATION_RETRY_SECONDS:
                    return None
                order["notification_attempted_at"] = time.time()
                db.set(TRACKED_ORDERS_KEY, orders)
                return dict(order)
    return None


async def _mark_notification_sent(order_id):
    target = str(order_id)
    async with ORDER_LOCK:
        orders = db.get(TRACKED_ORDERS_KEY)
        if not isinstance(orders, list):
            return
        for order in orders:
            if isinstance(order, dict) and str(order.get("order_id")) == target:
                order["completion_notified"] = True
                db.set(TRACKED_ORDERS_KEY, orders)
                return


async def _notify_completion(client, order):
    if order.get("status") != "مكتمل" or order.get("completion_notified"):
        return
    current = await _mark_notification_attempt(order["order_id"])
    if not current:
        return
    try:
        await client.send_message(
            int(current["user_id"]),
            "تم اكتمال طلبك بنجاح ✅\n"
            f"معرف الطلب : {escape(str(current['order_id']))}\n"
            f"الخدمة : {escape(str(current.get('service_name') or 'الخدمة'))}",
            parse_mode=enums.ParseMode.HTML,
        )
    except Exception:
        return
    await _mark_notification_sent(current["order_id"])


async def monitor_provider_orders(client):
    cursor = 0
    while True:
        try:
            orders = tracked_orders()
            active = [
                order
                for order in orders
                if order.get("status") not in TERMINAL_STATUSES
                or (
                    order.get("status") == "مكتمل"
                    and not order.get("completion_notified")
                )
            ]

            if active:
                start = cursor % len(active)
                batch = (active + active)[start : start + MAX_ORDERS_PER_CYCLE]
                cursor = (start + len(batch)) % len(active)
                for order in batch:
                    if order.get("status") == "مكتمل":
                        await _notify_completion(client, order)
                        continue
                    try:
                        data = await _fetch_order_status(order["order_id"])
                    except Exception:
                        continue
                    status = normalize_provider_status(data)
                    if status is None:
                        continue
                    updated = await _save_status(order["order_id"], status)
                    if updated and status == "مكتمل":
                        await _notify_completion(client, updated)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            print(f"Provider order status monitor error: {type(error).__name__}")

        await asyncio.sleep(POLL_INTERVAL_SECONDS)
