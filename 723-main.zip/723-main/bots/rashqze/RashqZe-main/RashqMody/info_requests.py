import asyncio
from html import escape

from pyrogram import Client as app, filters
from pyrogram import enums
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import requests
from kvsqlite.sync import Client as mody
from .navigation import ask_with_back, clear_section_message
from .order_status import get_tracked_order, normalize_provider_status

db = mody("data.sqlite", 'fuck')
HOME_BACK = mk([[btn("رجوع", callback_data="back")]])


def _format_order_status(order_id, data):
    if not isinstance(data, dict):
        raise ValueError("استجابة مزوّد الخدمة غير مفهومة")
    if data.get("error"):
        raise LookupError(str(data["error"]))

    provider_status = normalize_provider_status(data)
    status = provider_status or "قيد الانتظار"
    tracked_order = get_tracked_order(order_id)
    lines = [
        f"<b>تفاصيل الطلب #{escape(str(order_id))}</b>",
        f"الحالة: <b>{escape(status)}</b>",
    ]
    if tracked_order and tracked_order.get("service_name"):
        lines.append(f"الخدمة: <b>{escape(str(tracked_order['service_name']))}</b>")
    optional_fields = (
        ("quantity", "الكمية المطلوبة"),
        ("start_count", "العدد عند بدء الطلب"),
        ("remains", "الكمية المتبقية"),
    )
    for key, label in optional_fields:
        value = data.get(key)
        if value is not None and str(value).strip():
            lines.append(f"{label}: {escape(str(value))}")

    return "\n".join(lines)


@app.on_callback_query(filters.regex("^id_requests$"))
async def dailygiftt(app,query):
    user_id = query.from_user.id
    if not all(db.get(key) for key in ("set_domain", "api_key")):
        return await query.edit_message_text(
            "خدمة الطلبات غير مهيأة حالياً. يرجى المحاولة لاحقاً.",
            reply_markup=HOME_BACK,
        )
    domain = str(db.get("set_domain") or "").strip()
    domain = domain.removeprefix("https://").removeprefix("http://").strip("/")
    api_key = str(db.get("api_key") or "").strip()
    await clear_section_message(query)
    ask = await ask_with_back(
        app,
        user_id,
        "أرسل معرّف الطلب لمعرفة حالته، أو /cancel للإلغاء.",
        "back",
        filters=filters.user(user_id),
    )
    if not ask or not ask.text:
        return
    raw_order_id = ask.text.strip()
    if raw_order_id.lower() == "/cancel":
        await ask.reply("تم إلغاء الاستعلام.", reply_markup=HOME_BACK)
        return
    if not raw_order_id.isdigit():
        await ask.reply("أرسل معرّف الطلب بالأرقام فقط.", reply_markup=HOME_BACK)
        return

    tracked_order = get_tracked_order(raw_order_id)
    try:
        order_owner = int(tracked_order.get("user_id")) if tracked_order else None
    except (TypeError, ValueError):
        order_owner = None
    if order_owner != user_id:
        await ask.reply(
            "لم يتم العثور على طلب بهذا المعرّف ضمن طلبات حسابك.",
            reply_markup=HOME_BACK,
        )
        return

    try:
        response = await asyncio.to_thread(
            requests.get,
            f"https://{domain}/api/v2",
            params={
                "key": api_key,
                "action": "status",
                "order": raw_order_id,
            },
            timeout=20,
        )
        response.raise_for_status()
        data = response.json()
        message = _format_order_status(raw_order_id, data)
    except LookupError:
        message = "لم يتم العثور على طلب بهذا المعرّف. تأكد من الرقم وحاول مجدداً."
    except (requests.RequestException, ValueError):
        message = "تعذّر جلب حالة الطلب حالياً. حاول مرة أخرى بعد قليل."
    except Exception:
        message = "حدث خطأ أثناء جلب حالة الطلب. حاول مرة أخرى بعد قليل."

    await ask.reply(
        message,
        parse_mode=enums.ParseMode.HTML,
        reply_markup=HOME_BACK,
    )