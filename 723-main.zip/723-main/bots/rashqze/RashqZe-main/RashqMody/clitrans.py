import logging
import re
from decimal import Decimal, InvalidOperation

from pyrogram import Client as app, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
from kvsqlite.sync import Client as Database

from .navigation import ask_with_back, clear_section_message
from .order_lock import ORDER_LOCK
from .points_core import open_transaction, read_value, write_value

db = Database("data.sqlite", "fuck")
logger = logging.getLogger(__name__)
MAX_POINTS = Decimal("1000000000")
BACK = mk([[btn("رجوع", callback_data="back")]])


def _parse_transfer_amount(text):
    value = (text or "").strip()
    if not re.fullmatch(r"\d{1,10}(?:\.\d{1,4})?", value):
        raise ValueError("أرسل كمية موجبة حتى 4 منازل عشرية.")
    try:
        amount = Decimal(value)
    except InvalidOperation as error:
        raise ValueError("الكمية غير صحيحة.") from error
    if not amount.is_finite() or amount <= 0 or amount > MAX_POINTS:
        raise ValueError("الكمية خارج الحدود المسموحة.")
    return amount


def _format_amount(amount):
    return format(amount.normalize(), "f")


async def _apply_transfer(sender_id, recipient_id, amount):
    if sender_id == recipient_id:
        return False, "لا يمكنك تحويل النقاط إلى حسابك."

    async with ORDER_LOCK:
        connection = open_transaction()
        try:
            sender = read_value(connection, f"user_{sender_id}")
            recipient = read_value(connection, f"user_{recipient_id}")
            if not isinstance(sender, dict) or not isinstance(recipient, dict):
                connection.rollback()
                return False, "أحد الحسابين غير موجود في البوت."

            try:
                sender_balance = Decimal(str(sender.get("coins")))
                recipient_balance = Decimal(str(recipient.get("coins")))
            except (InvalidOperation, TypeError, ValueError):
                connection.rollback()
                return False, "تعذر قراءة رصيد أحد الحسابين."
            if (
                not sender_balance.is_finite()
                or not recipient_balance.is_finite()
                or sender_balance < 0
                or recipient_balance < 0
                or sender_balance > MAX_POINTS
                or recipient_balance > MAX_POINTS
            ):
                connection.rollback()
                return False, "رصيد أحد الحسابين خارج الحدود المسموحة."
            if amount >= sender_balance:
                connection.rollback()
                return False, "للاسف نقاطك غير كافية لتحويل هذا المبلغ."
            if recipient_balance + amount > MAX_POINTS:
                connection.rollback()
                return False, "الرصيد الناتج للمستلم يتجاوز الحد المسموح."

            sender_balance -= amount
            recipient_balance += amount
            sender["coins"] = float(sender_balance)
            recipient["coins"] = float(recipient_balance)
            write_value(connection, f"user_{sender_id}", sender)
            write_value(connection, f"user_{recipient_id}", recipient)

            try:
                transfer_count = int(read_value(connection, f"user_{sender_id}_trans") or 0)
            except (TypeError, ValueError):
                transfer_count = 0
            write_value(connection, f"user_{sender_id}_trans", transfer_count + 1)
            connection.commit()
            return True, sender_balance
        except Exception:
            if connection.in_transaction:
                connection.rollback()
            raise
        finally:
            connection.close()


@app.on_callback_query(filters.regex("^tran$"))
async def dailygiftt(client, query):
    user_id = query.from_user.id
    try:
        transfer_minimum = int(db.get("transfer")) if db.exists("transfer") else 1
    except (TypeError, ValueError):
        await query.answer("تعذر قراءة الحد الأدنى للتحويل حالياً.", show_alert=True)
        return
    if transfer_minimum < 1:
        await query.answer("خدمة التحويل غير مهيأة حالياً.", show_alert=True)
        return

    await clear_section_message(query)
    ask1 = await ask_with_back(client, user_id, "ارسل ايدي الشخص 🆔 ", "back")
    if not ask1:
        return
    try:
        recipient_id = int((ask1.text or "").strip())
        if recipient_id < 1:
            raise ValueError("invalid user id")
    except ValueError:
        await ask1.reply("برجاء ارسال رقم صحيح، اعد المحاولة مره اخري", reply_markup=BACK)
        return
    if not db.exists(f"user_{recipient_id}"):
        await ask1.reply("عذراً الشخص غير موجود فالبوت ❌", reply_markup=BACK)
        return

    ask2 = await ask_with_back(
        client,
        user_id,
        "حسنا الان ارسل عدد النقاط اللي تريد ترسلها ",
        "back",
        filters=filters.user(user_id),
    )
    if not ask2:
        return
    try:
        amount = _parse_transfer_amount(ask2.text)
    except ValueError as error:
        await ask2.reply(str(error), reply_markup=BACK)
        return
    if amount < transfer_minimum:
        await ask2.reply(
            f"المبلغ جدا صغير ، اقل مبلغ يمكن تحويله هو {transfer_minimum}",
            reply_markup=BACK,
        )
        return

    try:
        succeeded, result = await _apply_transfer(user_id, recipient_id, amount)
    except Exception as error:
        logger.error("Point transfer failed (%s)", type(error).__name__)
        await ask2.reply("تعذر إكمال التحويل حالياً، لم يتم تأكيد العملية.", reply_markup=BACK)
        return
    if not succeeded:
        await ask2.reply(result, reply_markup=BACK)
        return

    coin_message = str(db.get("coin_msg") or "")
    amount_text = _format_amount(amount)
    notification_failed = False
    try:
        await client.send_message(
            chat_id=recipient_id,
            text=(
                "• تم اضافة نقاط الي حسابك ✅\n"
                f"المبلغ : {amount_text} {coin_message} .\n"
                f"• من : `{query.from_user.mention}`"
            ),
            reply_markup=BACK,
        )
    except Exception as error:
        notification_failed = True
        logger.warning("Transfer notification failed (%s)", type(error).__name__)

    confirmation = f"تمت عملية التحويل بنجاح ✅\nالى : {recipient_id}"
    if notification_failed:
        confirmation += "\nتعذر إشعار المستلم، لكن الرصيد تم تحديثه."
    await ask2.reply(confirmation, reply_markup=BACK)

    admin_ids = sorted(
        {
            admin_id
            for admin_id in (db.get("admin_list") or [])
            if isinstance(admin_id, int)
        }
    )
    for admin_id in admin_ids:
        try:
            await client.send_message(
                admin_id,
                "**• عزيزي الادمن** : \n\n"
                "**• تمت عملية تحويل نقاط جديده ♻️**\n"
                f"• المبلغ : {amount_text}\n"
                f"• من: {query.from_user.mention}\n"
                f"• ايديه : `{user_id}`\n\n"
                f"• الى : `{recipient_id}`\n"
                f"• رصيد الشخص الذي قام بالتحويل الان : `{_format_amount(result)}`",
            )
        except Exception as error:
            logger.warning("Transfer audit notification failed (%s)", type(error).__name__)