from pyrogram import Client as app, enums, filters
from pyrogram.types import InlineKeyboardButton as btn, InlineKeyboardMarkup as mk
import time
from kvsqlite.sync import Client as mody
from config import Config
from .bot_controls import admin_dashboard_keyboard
db = mody("data.sqlite", 'fuck')

@app.on_callback_query(filters.regex("^back_admin$"))
async def dailygiftt(app,query):
    user_id = query.from_user.id
    if user_id not in (db.get("admin_list") or []):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return
    keys = admin_dashboard_keyboard()
    
    rk = f"""**• اهلا بك في لوحه الأدمن الخاصه بالبوت 🤖**

- يمكنك التحكم في البوت الخاص بك من هنا \n\n==================="""
    await query.edit_message_text(rk, reply_markup=keys)

@app.on_callback_query(filters.regex("^admins_bot$"))
async def admins_panel(app, query):
    if query.from_user.id not in (db.get("admin_list") or []):
        await query.answer("هذا القسم مخصص للأدمن فقط.", show_alert=True)
        return

    admin_ids = db.get("admin_list") or []
    text = "إدارة الأدمنية\n\n"
    text += "\n".join(f"• <code>{admin_id}</code>" for admin_id in admin_ids)
    rows = []
    if query.from_user.id == Config.OWNER_ID:
        rows.append(
            [
                btn("➕ إضافة أدمن", "add_admin"),
                btn("➖ حذف أدمن", "delete_admin"),
            ]
        )
    rows.append([btn("↩️ رجوع للوحة الأدمن", "back_admin")])
    await query.edit_message_text(
        text,
        reply_markup=mk(rows),
        parse_mode=enums.ParseMode.HTML,
    )
