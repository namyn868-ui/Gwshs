---
name: Patch hunk matching
description: Work around repeated patch matching failures on unchanged legacy lines.
---

When a multi-line patch is rejected even though the target lines appear unchanged, confirm the exact current text once, then make a smaller edit anchored on a unique neighboring line rather than repeating the same hunk.

**Why:** Repeating broad hunks without changing the anchor can waste retries and obscure the actual mismatch.

**How to apply:** Use this only after verifying the source text; prefer a narrow, unique anchor or a clearly bounded replacement.
