---
name: Telegram workflow secrets
description: Troubleshooting Telegram bot startup when secrets exist but are missing from the running process.
---

If the Telegram bot reports a required environment variable as missing even though the secret is registered, do not change bot code or print secret values. Ask the user to re-save the affected secrets through the secure secret form, then restart the workflow.

**Why:** The bot workflow failed to receive registered secrets until the user reconfirmed them securely; after that, it started without code changes.

**How to apply:** Check only secret presence and environment-variable names. If the process still lacks them, refresh the secrets securely and restart the workflow.
