---
name: Telegram session collisions
description: Handling Pyrogram AUTH_KEY_DUPLICATED errors without disrupting an external bot instance.
---

If Pyrogram reports `AUTH_KEY_DUPLICATED`, first check whether another bot process is running in this workspace. If none is found, ask the user to stop the other instance before retrying. Do not delete or replace the session file without explicit user approval; resetting it requires bot re-authentication and may disrupt the other instance.

**Why:** A workflow restart produced this error while no second local bot process was present, indicating the same session may be active outside the workspace.

**How to apply:** Check managed workflows and local processes, then coordinate stopping the external copy. Only offer a session reset after explaining the re-authentication consequence.

If the user has stopped the known external copy but the next startup still reports `AUTH_KEY_DUPLICATED`, stop repeating restarts. After explaining the impact and receiving explicit approval, remove only the local Pyrogram session file and restart with the saved bot token; do not touch the bot database.

**Why:** A retry after the user stopped the known copy still failed; resetting only the local Pyrogram session allowed the bot workflow to start.

**How to apply:** Confirm no local bot process is running, get explicit consent, reset only the `.session` file, then verify the workflow logs before reporting success.
