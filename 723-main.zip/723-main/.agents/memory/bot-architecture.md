---
name: Bot architecture constraint
description: The user's standing constraint for future development of the current Telegram bot.
---

For future development of the current bot, first inspect the project files and identify its language, libraries, and versions. Preserve the current language, project structure, architecture, dependencies, and operating approach. Do not convert languages, rebuild from scratch, or delete or replace existing files or features unless necessary. Integrate new features into the existing code and verify any new dependency is compatible.

**Why:** The user explicitly asked to preserve the bot's current implementation and structure.

**How to apply:** Before each future feature or change, inspect the relevant project context and make incremental changes in the existing stack.

For section navigation, reuse the current Telegram message when possible. Before a section starts a message-based input flow, remove or update the old menu so stale section screens do not accumulate. Every back action must be an inline keyboard button, including active input prompts; pressing it must cancel the pending input listener and leave a working return action.

**Why:** The user asked to keep the bot screen clean, avoid scrolling past old section messages, and make every return button an inline keyboard button.

**How to apply:** When adding callback-driven sections, edit the existing screen or clear it before prompting. During message-based input, use a Pyromod callback listener to cancel the active message listener when the inline back button is pressed, then show a working return action; put inline return buttons on results and section menus.

For paid provider orders, recheck the user's balance at confirmation, submit to the provider before deducting, and serialize all balance-charging services with the same order lock.

**Why:** The user should not be charged for provider-rejected requests, and overlapping orders must not spend the same balance twice.

**How to apply:** Any new paid-order flow should share the lock used by existing order services and deduct only after a successful provider response.

Persist admin-controlled bot and entry-notification switches in the bot database. Default both to enabled to preserve existing behavior; when the bot is paused, block regular users but keep admin access so an admin can resume it.

**Why:** The user asked to activate these controls. The Telegram process must remain available for admins to turn the bot back on.

**How to apply:** Keep the bot process running, gate regular users' private messages and callbacks on the bot switch, and check the notification switch before sending new-entry alerts.

The points collection section has three paths: preserve the existing referral-share flow, offer a per-user cooldown gift with an admin-configured random range, and allow one active coupon with configurable reward, expiry, and usage cap. Coupon codes may be a single Arabic/Unicode letter, and each user may redeem the active code once. Serialize gift and coupon balance updates with the shared order lock.

**Why:** The user requested these three collection methods and configurable limits; concurrent rewards must not overwrite order-related balance changes.

**How to apply:** Persist each user's last gift claim and coupon use data, check coupon expiry and total/per-user use before awarding points, and coordinate every new balance update with `ORDER_LOCK`.

Keep provider prices and charges out of user-facing order menus, confirmations, results, and status lookups; admin-only accounting may still show them.

**Why:** The user explicitly asked that order costs not be shown to bot users.

**How to apply:** Check every user-facing path for an order, including shared order-status screens, when changing price or order messages.

Persist each new provider order with its owner and service name, and start the status monitor with the bot so completion notifications resume after restarts.

**Why:** Users should receive one completion notice with the correct service name even if the bot restarts while the order is pending.

**How to apply:** Register provider orders as soon as accepted and keep the startup monitor connected to the same persistent order records.

Agent-issued points must be funded from the agent's own wallet. Require a successful private audit-channel notification before committing agent transfers or owner wallet adjustments; reject the action if logging is unavailable.

**Why:** The user requires agents to be unable to create points from nothing and wants every wallet-affecting action monitored by the owner.

**How to apply:** Keep transfer, wallet, and audit delivery in one guarded flow; do not weaken the insufficient-balance check or silently proceed when audit delivery fails.

Pyrogram exposes channel administrator rights through `ChatMember.privileges`; `can_post_messages` is not a direct `ChatMember` field.

**Why:** Reading the permission from the wrong object made an administrator with posting rights appear unauthorized.

**How to apply:** Check `member.privileges.can_post_messages` for channel admins, and handle owner status separately.

Define daily active users as registered users who interact with the bot in a private message or button callback on the current Baghdad calendar day. Count successful service operations from the persistent per-user purchase counters.

**Why:** Telegram does not expose a reliable online-presence signal, so the dashboard needs a measurable activity definition and a durable source for completed operations.

**How to apply:** Keep activity markers tied to Baghdad dates and use successful-order counters rather than initiated or pending requests.
